import React from 'react';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';

class StlUploader extends React.Component {

    state = {
        stlToUpload: [...this.props.filesToShow]
    }

    handleChange = (event) => {
        this.setState({ stlToUpload: [...event.target.files] })
        this.props.partdataHandler({ 'filesToUpload': [...event.target.files] });
    }

    openInputForImages = () => {
        //using ref to click input button on add button click
        this.inputElement.click();
    }

    render() {
        return (
            <React.Fragment>
                <input id="inputImages" type="file" onChange={this.handleChange} ref={input => this.inputElement = input} accept='.stl,.obj,.sldprt,.sldasm,.3ds,.fbx' style={{ display: "none" }} />
                <Button variant="contained" color="primary" onClick={this.openInputForImages} style={{ width: "20%", margin: "auto", marginBottom: "40px" }} >
                    Upload 3D file
                </Button>
                <br />
                {this.state.stlToUpload.length > 0 &&
                    this.state.stlToUpload.map(ele => (
                        < TextField
                            id="outlined-bare"
                            defaultValue="Bare"
                            margin="normal"
                            variant="outlined"
                            disabled
                            style={{ margin: '20px', width: '80%' }}
                            value={`${ele.name ? ele.name : this.state.stlToUpload.length} is selected`}
                            inputProps={{ 'aria-label': 'bare' }}
                        />
                    ))
                }

            </React.Fragment>
        )
    }
}

export default StlUploader;