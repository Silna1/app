import React, { Component, Fragment } from 'react';

import Card from "@material-ui/core/Card";
import CardContent from "@material-ui/core/CardContent";
import Table from "@material-ui/core/Table";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import Divider from "@material-ui/core/Divider";
import Avatar from "@material-ui/core/Avatar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import Grid from '@material-ui/core/Grid';
import InputBase from '@material-ui/core/InputBase'
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import Modal from './pd-dialog';
import cloneDeepWith from 'lodash/cloneDeepWith'
import { config } from '../config'

import { updatePrinter, deletePrinter } from '../store/actions/printer_action';

let id = 0;

class PrinterCard extends Component {

    constructor(props) {
        super(props);
        this.printer = React.createRef();
        this.state = {
            isEditable: false,
            printerNewData: cloneDeepWith(props.printerData),
        }
        this.isPrinterDataModified = false;
        this.partData = cloneDeepWith(props.printerData);
    }

    createData = (name, value) => {
        id += 1;
        return { id, name, value };
    }

    handleEdit = () => {
        this.setState({ isEditable: true });
    }

    handleSave = () => {
        this.setState({ isEditable: false });
        if (this.isPrinterDataModified) {
            this.isPrinterDataModified = false;
            this.setState({ printerNewData: cloneDeepWith(this.partData) });
            console.log("handlesave printer update",this.partData);
            this.props.updatePrinter_action(this.partData);
        }
    }

    handleCancel = () => {
        this.setState({ isEditable: false });
        if (this.isPrinterDataModified) {
            this.isPrinterDataModified = false;
            this.setState({ printerNewData: cloneDeepWith(this.state.printerNewData) });
        }
    }

    handleDelete = () => {
        this.printer.current.handleClose();
        this.props.deletePrinter_action({ ...this.state.printerNewData });
    }

    onHandleChange = (event) => {
        if (!this.isPrinterDataModified)
            this.isPrinterDataModified = true;

        let key = Object.keys(event)[0];
        let objValue = Object.values(event)[0];
        if (key === 'length' || key === 'breadth' || key === 'height') {
            this.partData.size[key] = objValue.target.value;
        }
        else
            this.partData[key] = objValue.target.value;
    }

    rows = () => {
        let arr = [];
        let data = this.state.printerNewData;
        for (const key in data) {
            if (key === 'size') {
                let sizeObj = data[key];
                for (const param in sizeObj) {
                    arr.push(this.createData(param, sizeObj[param]));
                }
                continue;
            }

            if (key === 'name' || key === 'id')
                continue;

            arr.push(this.createData(key, data[key]));
        }
        return arr;
    }

    render() {
        const { printerData, privilege, userOrganization } = this.props;
        console.log("Printerdata",printerData);
        return (
            <div style={{ paddingTop: '8%' }}>
                <Card className={"MuiProjectCard--01"} >
                    <div className={"MuiCard__head"}>
                        <Avatar
                            className={"MuiAvatar-root"}
                            src="./images/printer.png"
                            style={{ width: '30%', height: '30%' }}
                        />
                        <Typography
                            className={"MuiTypography--heading"}
                            variant={"h5"}
                            gutterBottom
                        >
                            {printerData.name}
                        </Typography>
                    </div>
                    <Divider className={"MuiDivider-root"} light />
                    <CardContent className={"MuiCardContent-root"}>
                        <div className={"MuiCardContent-inner"}>
                            <Table>
                                <TableHead>
                                    <TableRow>
                                        <TableCell>Property</TableCell>
                                        <TableCell align="right">Value</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {this.rows().map(row => (
                                        <TableRow key={row.id}>
                                            <TableCell component="th" scope="row">
                                                {/* {Below code makes first letter capital of word} */}
                                                {row.name.charAt(0).toUpperCase() + row.name.slice(1)}
                                            </TableCell>
                                            <TableCell align="right">
                                                {this.state.isEditable ? (
                                                    <InputBase
                                                        classes={{
                                                            root: "BootstrapInput-root",
                                                            input: "BootstrapInput-input"
                                                        }}
                                                        defaultValue={row.value}
                                                        onChange={(obj) => {
                                                            let data = {}; data[row.name] = obj;
                                                            this.onHandleChange(data)
                                                        }} />) :
                                                    (row.value)
                                                }
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </div>
                        <Grid container spacing={2}>
                            {privilege && privilege.editPrinter && userOrganization === config.ProductOwner &&
                                (this.state.isEditable ?
                                    (<Fragment>
                                        <Grid style={{ paddingTop: '5%' }} item xs={6} >
                                            <Button className={"MuiButton--readMore"} onClick={this.handleSave}>Save</Button>
                                        </Grid>
                                        <Grid style={{ paddingTop: '5%' }} item xs={6}>
                                            <Button className={"MuiButton--readMore"} onClick={this.handleCancel}>Cancel</Button>
                                        </Grid> </Fragment>) :
                                    (<Fragment>
                                        <Grid style={{ paddingTop: '5%' }} item xs={6} >
                                            <Button style={{backgroundImage: "linear-gradient(1deg, #43609C 0%, #43609C 2%)",paddingRight: 24,paddingLeft: 24,color:"#FFF",borderRadius: 10,}} onClick={this.handleEdit}>Edit</Button>
                                        </Grid>
                                        <Grid style={{ paddingTop: '5%' }} item xs={6}>
                                            <Button style={{backgroundImage: "linear-gradient(1deg, #000 0%, #FF0000 2%)",paddingRight: 24,paddingLeft: 24,color:"#FFF",borderRadius: 10,}} onClick={() => { this.printer.current.handleClickOpen() }}>Delete
                                        </Button>
                                        </Grid>
                                    </Fragment>)
                                )
                            }
                        </Grid>
                    </CardContent>
                </Card >
                <Modal obj={this.handleDelete} title="Printer Delete" ref={this.printer}>
                    <h4>Are you sure you want to delete ?</h4>
                </Modal>
            </div>
        )
    }
}

PrinterCard.propTypes = {
    privilege: PropTypes.object,
    printerData: PropTypes.any,
    updatePrinter_action: PropTypes.func,
    deletePrinter_action: PropTypes.func,
}

const mapStateToProps = (state) => {
    return {
        privilege: state.auth.user ? state.auth.user.access : undefined,
        userOrganization: state.auth && state.auth.user ? state.auth.user.organization : undefined
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        updatePrinter_action: (printerData) => dispatch(updatePrinter(printerData)),
        deletePrinter_action: (printerData) => dispatch(deletePrinter(printerData)),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(PrinterCard);