import React, { Component } from 'react';
import { connect } from 'react-redux';
import UserProfileView from "./pd-user-view";
import Grid from '@material-ui/core/Grid';
import { getUsersdata, createUser, updateUser,createGroup } from '../store/actions/user_action';
import { clientList, processInProgress ,setSelectedClient} from '../store/actions/misc_action';
import TextField from '@material-ui/core/TextField';
import Tooltip from '@material-ui/core/Tooltip';
import Fab from '@material-ui/core/Fab';
import PersonAdd from '@material-ui/icons/PersonAdd';
import GroupAddIcon from '@mui/icons-material/GroupAdd';
import Modal from './pd-dialog'
import MenuItem from '@material-ui/core/MenuItem';
import InputBase from '@material-ui/core/InputBase';
import PropTypes from 'prop-types';
import { Button, Paper } from '@material-ui/core';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import FaceIcon from '@mui/icons-material/Face';

class UserSettings extends Component {

    constructor(props) {
        super(props);
        this.userObj = React.createRef();
        this.groupObj = React.createRef();
        this.state = {};
        this.isOrganizationAvailable = false;
        this.state = {
            'isDataValidated': false,
            'isgroup': false
        };
    }

    componentDidMount() {
        this.props.processInProgress_action(true);
    }

    newUserDetails = {};

    handleChange = (key) => (event) => {
        this.setState({ [key]: event.target.value });
        this.props.setSelectedClient_action(event.target.value);
    }

    handleSave = () => {
        if (this.state.editMode && this.isEmpty(this.state.privilege)) {
            this.props.updateUser_action({
                "email": this.state.email, 'name': this.state.name,
                "privilegeToChange": this.state.privilegeToChange, "username": this.state.username,
                "privilege": this.state.privilege, "organization": this.state.organization
            });
            this.userObj.current.handleClose();
            this.setState({ "email": "", "privilege": "", 'editMode': false });
        } else if ((this.isEmpty(this.state.email) && this.isEmpty(this.state.privilege))) {
            this.setState({ isDataValidated: false });
            this.userObj.current.handleClose();
            this.props.addNewUser_action({
                "email": this.state.email, 'name': this.state.name,
                "privilege": this.state.privilege, "organization": this.state.organization
            });
            this.setState({ "email": "", "privilege": "", 'editMode': false });
        } else if(this.state.isgroup){
            this.setState({ isDataValidated: false });
            this.groupObj.current.handleClose();
            this.props.addNewGroup_action({
                "groupName": this.state.groupName, 'description': this.state.description
            });
            this.setState({ "groupName": "", "description": "", 'editMode': false });
        }
        else
        {
            this.setState({ isDataValidated: true });
        }
    }

    isEmpty = (data) => {
        if (data === "" || data === undefined || data === null)
            return false;

        return true;
    }

    fabStyles = {
        position: 'fixed',
        bottom: '48px',
        right: '48px',
        zIndex: 1
    }

    actionHandler = (data) => {
        this.userObj.current.handleClickOpen();
        this.setState({
            "email": data.email, 'name': data.name, "privilegeToChange": data.privilege,
            "username": data.username, "privilege": data.privilege, 'editMode': true,
            'title': "Edit User"
        });
    }

    render() {
        const { usersData, privilege, organization,selectedClient,setSelectedClient_action,clientList,clients,client,groupData } = this.props;

        if (organization !== undefined && !this.isOrganizationAvailable) {
            this.props.getUserdata_action(organization);
            this.isOrganizationAvailable = true;
        }

        //sorts userData array of objects by email property value, to show user tiles alphabetically
        if (usersData)
            usersData.sort((a, b) => (a.email.toLowerCase() > b.email.toLowerCase()) ? 1 : ((b.email.toLowerCase() > a.email.toLowerCase()) ? -1 : 0));

        return (
            <React.Fragment>
               <Grid container spacing={4} style={{ marginTop: 75, textAlign: 'center' }}>

               <Stack direction="row" spacing={1}>
                    <Chip icon={<PersonAdd />} label="Add User"  onClick={() => {
                            this.setState({ "email": "", "privilege": "", "name": "","organization":"", 'editMode': false, 'title': 'Add User', isDataValidated: false });
                            this.userObj.current.handleClickOpen();
                        }}/>
                    <Chip icon={<GroupAddIcon />} label="Add Group" variant="outlined" onClick={() => {
                            this.setState({ "group": "", "description": "", 'title': 'Add Group', isDataValidated: false, isgroup: true });
                            this.groupObj.current.handleClickOpen();
                        }} />
               </Stack>



               {/*     {usersData && usersData.map((user, index) => (
                        // eslint-disable-next-line no-unused-expressions
                        <Grid item xs={12} sm={6} lg={3} key={index}>
                            <UserProfileView userData={user} action={this.actionHandler}></UserProfileView>
                        </Grid>
                    ))}*/}
                
                    </Grid> 
                
                <Modal title={this.state.title} obj={this.handleSave} ref={this.userObj}>
                    <TextField fullWidth label="Name" type="string" name="name" autoComplete="email" value={this.state.name} onChange={this.handleChange('name')} style={{ padding: "5px" }} required />
                    <TextField fullWidth label="Email" type="email" name="email" autoComplete="email" value={this.state.email} disabled={this.state.editMode} onChange={this.handleChange('email')} style={{ padding: "5px" }} required />
                    <TextField fullWidth select label="Privilege" value={this.state.privilege} onChange={this.handleChange('privilege')} style={{ padding: "5px" }} required>
                        {["Admin", "Engineer", "Technician"].map(option => (
                            <MenuItem key={option} value={option}>
                                {option}
                            </MenuItem>
                        ))}
                    </TextField>
                    <TextField fullWidth select label="Group" value={this.state.organization} onChange={this.handleChange('organization')} style={{ padding: "5px" }} required>
                            {clientList?.map((option) => (
                            <MenuItem key={option} value={option}>
                            {option}
                            </MenuItem>
                        ))}
                    </TextField>
                    <InputBase
                        value={"*All fields are necessary"}
                        inputProps={{ 'aria-label': 'naked' }}
                        disabled
                        color="#ff0000"
                        style={{ display: this.state.isDataValidated ? 'block' : 'none', color: "#ff0000" }}
                    />
                </Modal>
                <Modal title={this.state.title} obj={this.handleSave} ref={this.groupObj}>
                    <TextField fullWidth label="GroupName" type="string" name="groupName" autoComplete="email" value={this.state.groupName} onChange={this.handleChange('groupName')} style={{ padding: "5px" }} required />
                    <TextField fullWidth label="Description" type="text" name="description" autoComplete="email" value={this.state.description} onChange={this.handleChange('description')} style={{ padding: "5px" }} required />
                   
                    <InputBase
                        value={"*All fields are necessary"}
                        inputProps={{ 'aria-label': 'naked' }}
                        disabled
                        color="#ff0000"
                        style={{ display: this.state.isDataValidated ? 'block' : 'none', color: "#ff0000" }}
                    />
                </Modal>
            </React.Fragment>
        );
    }
}

UserSettings.propTypes = {
    usersData: PropTypes.object,
    privilege: PropTypes.any,
    organization: PropTypes.string,
    processInProgress_action: PropTypes.func,
    updateUser_action: PropTypes.func,
    addNewUser_action: PropTypes.func,
    getUserdata_action: PropTypes.func,
    clientList: PropTypes.any,
    setSelectedClient_action: PropTypes.func,
    selectedClient: PropTypes.string,
    groupData: PropTypes.object,
    addNewGroup_action: PropTypes.func
}


const mapStateToProps = (state) => {
    return {
        usersData: state.users.usersdata,
        privilege: state.auth.user ? state.auth.user.access : undefined,
        organization: state.auth.user ? state.auth.user.organization : undefined,
        clientList: state.misc.clients,
        selectedClient: state.misc.selectedClient
      ? state.misc.selectedClient
      : undefined,
      groupData: state.users.groupdata
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        getUserdata_action: (organization) => dispatch(getUsersdata(organization)),
        addNewUser_action: (userData) => dispatch(createUser(userData)),
        updateUser_action: (userData) => dispatch(updateUser(userData)),
        processInProgress_action: (status) => dispatch(processInProgress(status)),
        setSelectedClient_action: (client) => dispatch(setSelectedClient(client)),
        addNewGroup_action: (groupData) => dispatch(createGroup(groupData))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(UserSettings);