import React, { Component, Fragment } from "react";
import InputBase from "@material-ui/core/InputBase";
import Button from "@material-ui/core/Button";
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import CloudUpload from "@material-ui/icons/CloudUpload";
import DeleteIcon from "@material-ui/icons/Delete";
import Tooltip from "@material-ui/core/Tooltip";
import Paper from "@material-ui/core/Paper";
import Divider from "@material-ui/core/Divider";
import IconButton from "@material-ui/core/IconButton";
import ProgressBar from "./progress-bar";
import { progressVal,updateProgressVal } from "../store/actions/progress-action";
import { useStyles } from "../Styles/batchUploadLayout_styles";

class BatchUpload extends Component {
  constructor() {
    super();
    this.state = {
      fileSelected: "Add zip file to import parts data...",
      isFileSelected: false,
    };
  }

  handleChange = (event) => {
    console.log(event.target.files);
    this.setState({ zipToUpload: [...event.target.files] });
    this.setState({
      fileSelected: event.target.files[0].name,
    });
    this.setState({ isFileSelected: true });
  };

  emptyFile = () => {
    this.setState({ zipToUpload: [] });
    this.setState({ fileSelected: "Add zip file to import parts data..." });
    this.setState({ isFileSelected: false });
  };

  openInputForZipFile = () => {
    //using ref to click input button on add button click
    this.inputElement.click();
  };

  importFile = () => {
    this.props.updateProgressVal('0')
    const formData = new FormData();
    formData.append("ExcelFile", this.state.zipToUpload[0]);
    this.props.progressVal_action(formData);
    console.log("props-test",formData);
  };

  render() {
    const { classes } = this.props;
    return (
      <Fragment>
        <h2>Import Parts</h2>
        <p>
          Please read rules
          <a
            style={{ margin: "6px" }}
            href="https://docs.google.com/document/d/1ri2_rgpFuMmHlfrNkLGEdMZZQFFtCYnQ7bIuFTfVBpM/edit?usp=sharing"
          >
            here
          </a>
          first to start uploading parts.
        </p>
        <div className="App">
          <div style={{ width: "80%", alignSelf: "center" }}>
            <ProgressBar bgcolor={"#19b4dd"}  completed={this.props.progressVal} />
          </div>
        </div>
        <Paper className={classes.root}>
          <input
            id="inputFile"
            type="file"
            onChange={this.handleChange}
            ref={(input) => (this.inputElement = input)}
            accept=".zip"
            style={{ display: "none" }}
          />
          <Tooltip title="Select file to upload">
            <IconButton
              color="primary"
              className={classes.iconButton}
              onClick={this.openInputForZipFile}
              aria-label="menu"
            >
              <CloudUpload />
            </IconButton>
          </Tooltip>
          <Divider className={classes.divider} />
          <InputBase
            className={classes.input}
            value={this.state.fileSelected}
            disabled
          />
          {this.state.isFileSelected && (
            <Tooltip title="Delete file">
              <IconButton
                className={classes.iconButton}
                onClick={this.emptyFile}
              >
                <DeleteIcon />
              </IconButton>
            </Tooltip>
          )}
        </Paper>
        <div className={classes.uploadButton}>
          <Button
            variant="contained"
            color="primary"
            disabled={!this.state.isFileSelected}
            onClick={this.importFile}
          >
            Upload
          </Button>
        </div>
      </Fragment>
    );
  }
}
// const mapDispatchToProps = (dispatch) => {
//   return {
//     importParts_action: (formData) => dispatch(importParts(formData)),
//     progressVal_action: (formData) => dispatch(progressVal(formData)),
//   };
// };
const mapStateToProps=({progress})=>{
  console.log('progress.progressVal',progress.progressVal)
  return {
    progressVal:progress.progressVal
  };
}
export default connect(
  mapStateToProps,
  {progressVal_action:progressVal,updateProgressVal}
)(withStyles(useStyles)(BatchUpload));
