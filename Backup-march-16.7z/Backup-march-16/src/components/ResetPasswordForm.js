import React, { useState, useEffect } from "react";
import { Link, useHistory, useLocation } from "react-router-dom";
import { connect } from "react-redux";
import Button from '@material-ui/core/Button';
import { Auth } from "aws-amplify";
import { login } from '../store/actions/authentication_action';
import { useStyles } from '../Styles/signIn_styles';
import { signIn } from '../store/actions/auth_action'

const ResetPassword = (props) => {
    const {cognitoUser, auth_action} = props;
    const history = useHistory();
    const location = useLocation();

    const [values, setValues] = useState({
        password: '',
        confirmPassword: '',
        oldPassword: '',
        username: '',
        cognitoUser: '',
    });

    useEffect(() => {
        if(location.state) {
            const {username, password, cognitoUser} = location.state;
            setValues({...values, username, oldPassword: password, cognitoUser });
        } else {
            history.push('/signin');
        }
    }, [location])

    const handleSubmit = () => {
        console.log('cognitoUser', cognitoUser);
        if(cognitoUser) {
            Auth.completeNewPassword(
                cognitoUser,               // the Cognito User Object
                values.password,    // the new password
            ).then(user => {
                // at this time the user is logged in if no MFA required
                console.log('user', user);
                auth_action(user.signInUserSession.idToken.payload)
            }).catch(e => {
                console.log(e);
            });
        }
        // Auth.signIn(values.username, values.oldPassword)
        // .then(user => {
        //     console.log('useruseruser', user)
        //     if (user.challengeName === 'NEW_PASSWORD_REQUIRED') {
        //         const { requiredAttributes } = user.challengeParam; // the array of required attributes, e.g ['email', 'phone_number']
        //         Auth.completeNewPassword(
        //             user,               // the Cognito User Object
        //             values.password,       // the new password
        //         ).then(user => {
        //             // at this time the user is logged in if no MFA required
        //             console.log('user', user);
        //         }).catch(e => {
        //             console.log(e);
        //         });
        //     } else {
        //         // other situations
        //     }
        // }).catch(e => {
        //     console.log(e);
        // });
    }

    const handleChange = (event) => {
        setValues({...values, [event.target.name]: event.target.value})
    }

    return (
        <div className="formCenter">
        <form className="formFields" onSubmit={handleSubmit}>
          <div className="formField">
            <label className="formFieldLabel" htmlFor="password">
              Password
            </label>
            <input
              type="password"
              id="password"
              className="formFieldInput"
              placeholder="Enter new password"
              name="password"
              value={values.password}
              onChange={handleChange}
            />
          </div>

          <div className="formField">
            <label className="formFieldLabel" htmlFor="password">
              Confirm Password
            </label>
            <input
              type="password"
              id="confirmpassword"
              className="formFieldInput"
              placeholder="Re-enter password"
              name="confirmPassword"
              value={values.confirmPassword}
              onChange={handleChange}
            />
          </div>

          <div className="formField">
            <button onClick={handleSubmit} className="formFieldButton">Reset Password</button>{" "}
           
          </div>

        
        </form>
      </div>
    )
}

const mapStateToProps = (state) => {
    return {
      cognitoUser: state.auth.cognitoUser,
    };
  };
  
const mapDispatchToProps = (dispatch) => {
    return {
        auth_action: (payload) => dispatch(login(payload)),
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(ResetPassword);