import React,{Component,Fragment,useState, useEffect} from 'react';
import {Doughnut,Pie,Bar} from 'react-chartjs-2';
import ReactApexChart from 'react-apexcharts';
import { getMaterialsParts,getChartsDatax,getPyrmidData } from '../../store/actions/part_action';
import { processInProgress } from '../../store/actions/misc_action'
import { connect } from 'react-redux';
import { Tooltip } from '@material-ui/core';
import ScatterChart from './cost-vs-printability';

import {
    Grid,
    Card,
    CardHeader,
    CardContent,
    Divider,
    withStyles
  } from '@material-ui/core';

  import {
    Chart,
    ChartTitle,
    ChartLegend,
    ChartTooltip,
    ChartSeries,
    ChartSeriesItem,
    ChartSeriesLabels
  } from '@progress/kendo-react-charts';
  import data from './funnel-data.json';
  
  


class TopAnalytics extends Component
{

  constructor(props)
  {
    super(props)
    this.state = {
      loading : true,
      options:{labels:["A","B","C","D"]},
      
      dataLabels: {
        enabled: true
      },
      fill: {
        type: "gradient"
      },
      
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 100,
              height:100,
            }
        
          }
        }
      ]


    }
  }

  componentDidMount(){
    this.props.getMaterialsParts_action(this.props.organization);
    this.props.getDashboardCharDatax_action(this.props.organization);
    this.props.getPyrmidData_action();
  }
  
  render(){
    setTimeout(() =>  this.setState({loading : false}), 3000);
    
    return(

    <Fragment>
           <>
    {this.state.loading === false ? (
 <div>
    <br />
    <br />
    <br />

      
  

    <Grid container spacing={4}>
              <Grid item lg={12} md={10} xl={12}  xs={11} >

               
              <Card >
        <CardHeader title="Parts Materials vs Total Parts"/>
        <Divider />
        <CardContent>
<Bar data={{labels:this.props.parts[0].names,datasets:[ {label: 'Materials',data:this.props.parts[0].data,backgroundColor:"DodgerBlue"}]}} options={{
          tooltips:{
            label:function(tooltipItem,data)
            {
              let value = data.datasets[0].data[tooltipItem.index]
              return value;
            },
            title:function(tooltipItem,data){
              return data.labels[tooltipItem[0].index]
            },
            bodyFontSize:16
          }
        }} height='100%'/>
        </CardContent>
      </Card>
              </Grid>


<Grid item lg={6} md={6} xl={6}  xs={11} >      
<Card >
<CardHeader title="Printability Score Pyramid"/>
<Divider />
<CardContent>
<div>
        <Chart style={{ margin: '0 auto', width: 450}} >
          <ChartSeries>
            <ChartSeriesItem type="funnel" data={this.props.Pyramid} categoryField="stat" field="count" colorField="color" neckRatio="10">
            <ChartSeriesLabels color="white" background="none" format="N0" />
            </ChartSeriesItem>
          </ChartSeries>
         
          <ChartLegend visible={true} />
        </Chart>
      </div>
</CardContent>
</Card>
</Grid>


<Grid item lg={6} md={6} xl={6}  xs={11} >      
<div>
<ScatterChart dashboardChartData={this.props.partsData.Items}/>
      </div>
</Grid>



</Grid>
</div>
      ) : (

        <div>
        <br />
        <br />
        <br /> 
        <br />
        <br />
        <br /> 
        <div class="container" width="100%" style={{color:"#FFF"},{textAlign:"center"}}>
        <img src={process.env.PUBLIC_URL + '/loading_.gif'} width="10%"/> 
        </div>
  </div>
      )}
      </>
   </Fragment>


    
      
    );
  }
}

const mapStateToProps = (state) => {
  return {
    parts: state.parts.MaterialsParts,
    partsData:state.parts ? state.parts : undefined,
    organization: state.auth && state.auth.user ? state.auth.user.organization : undefined,
    Pyramid:state.parts.PyramidData
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    getMaterialsParts_action: (organization) => { dispatch(getMaterialsParts(organization)) },
    processInProgress_action: (status) => dispatch(processInProgress(status)),
    getDashboardCharDatax_action: (organization) => { dispatch(getChartsDatax(organization)) },
    getPyrmidData_action: (organization) => { dispatch(getPyrmidData()) },
   }
}

export default connect(mapStateToProps, mapDispatchToProps)((TopAnalytics));


