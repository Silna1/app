import React, { Component } from 'react';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import ArrowRightIcon from '@material-ui/icons/ArrowRight';
import Scrollbar from 'react-scrollbar';
import { Link } from 'react-router-dom';
import InputIcon from '@material-ui/icons/Input'
import { IconButton } from '@material-ui/core'
import {
  Card,
  CardActions,
  CardHeader,
  CardContent,
  Button,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
} from '@material-ui/core';

const useStyles = theme => ({
  root: {},
  content: {
    padding: 0
  },
  inner: {
    minWidth: 350,
    overflow: 'auto',
    height: 350,
  },
  statusContainer: {
    display: 'flex',
    alignItems: 'center'
  },
  status: {
    marginRight: theme.spacing(1)
  },
  actions: {
    justifyContent: 'flex-end'
  }
});

class DataPartList extends Component {

  render() {
    const { className, classes, parts, ...rest } = this.props;
    return (
      <Card
        {...rest}
        className={clsx(classes.root, className)}
      >
        <CardHeader
          action={
            <Button
              color="primary"
              size="small"
              variant="outlined"
              component={Link} to="/partadd"
            >
              Add Part
          </Button>
          }
          title="Part List"
        />
        <Divider />
        <CardContent className={classes.content}>
          <Scrollbar>
            <div className={classes.inner}>
              <Table>
              <TableHead>
                  <TableRow>
                    <TableCell >Name</TableCell>
                    <TableCell >Category</TableCell>
                    <TableCell >Material</TableCell>
                    <TableCell>Complexity</TableCell>
                    <TableCell>View Part</TableCell>
                  </TableRow>
                </TableHead>
                {parts &&
                  <TableBody >
                    {parts.map(part => (
                      <TableRow
                        hover
                        key={part.id}
                      >
                        <TableCell>{part.name}</TableCell>
                        <TableCell>{part.category}</TableCell>
                        <TableCell>{part.material}</TableCell>
                        <TableCell>{part.complexity}</TableCell>
                        <TableCell><IconButton component={Link} to={`/${part.id}/partprofileview`}><InputIcon /></IconButton></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                }
              </Table>
            </div>
          </Scrollbar>
        </CardContent>
        <Divider />
        <CardActions className={classes.actions}>
          <Button
            color="primary"
            size="small"
            variant="text"
            component={Link} to='/'
          >
            View all <ArrowRightIcon />
          </Button>
        </CardActions>
      </Card >
    );
  }
}

DataPartList.propTypes = {
  className: PropTypes.string,
  classes: PropTypes.any,
  parts: PropTypes.object,
};


export default withStyles(useStyles)(DataPartList);
