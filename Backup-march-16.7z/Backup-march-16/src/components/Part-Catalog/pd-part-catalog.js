import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { Card, Grid, withStyles } from '@material-ui/core';
import PropTypes from 'prop-types';

import CostVsPrintability from './cost-vs-printability';
import CostVsSellingPrice from './cost-vs-sellingprice';
import PartList from './pd-part-list';
import { getChartsData } from '../../store/actions/part_action';
import { processInProgress } from '../../store/actions/misc_action'

const useStyles = (theme) => ({
  root: {
    padding: theme.spacing(4),
  }
})

class PartCatalog extends Component {
state={
  numofcats:[],
}
  componentDidMount() {
    //this.props.getAllCategoriesList_action(this.props.organization);
    if (this.props.dashboardChartData === undefined) {
      
      
      this.props.getDashboardCharData_action(this.props.organization);
    }
  }

  componentWillReceiveProps(props) {}

  render() {
    const { classes, parts } = this.props;
  

    return (
      <div className={classes.root} style={{marginTop:25}}>
        {parts && parts.Items2 &&
          <Fragment>

          { <Grid>
              <Grid item lg={12} md={12} xl={12} xs={12} >
                <CostVsSellingPrice dashboardChartData={parts.Items2}/>
              </Grid>
          </Grid>}
          {console.log("Parts partcatalog",parts.Items)}
            <Grid container spacing={4} >
              <Grid item lg={12} md={12} xl={12} xs={12} >
                <PartList parts={parts.Items} />
              </Grid>
            </Grid>
            
          </Fragment>
        }
      </div >
    );
  }
}

PartCatalog.propTypes = {
  parts: PropTypes.object,
  organization: PropTypes.string,
  classes: PropTypes.any,
  getDashboardCharData_action: PropTypes.func,
  processInProgress_action: PropTypes.func,
 
}

const mapStateToProps = (state) => {
  return {
    parts: state.parts ? state.parts : undefined,
    //parts : state.parts.newParts2,
    organization: state.auth && state.auth.user ? state.auth.user.organization : undefined,
  
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    getDashboardCharData_action: (organization) => { dispatch(getChartsData(organization)) },
    processInProgress_action: (status) => dispatch(processInProgress(status)),
   }
}

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(useStyles)(PartCatalog));
