import React from 'react';
import ReactApexChart from 'react-apexcharts';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import {
  Card,
  CardHeader,
  CardContent,
  Divider,
  withStyles
} from '@material-ui/core';
import { ContinuousColorLegend } from 'react-vis';
import Avatar from '@material-ui/core/Avatar';
import { deepOrange, deepPurple } from '@material-ui/core/colors';
import Chip from '@material-ui/core/Chip';
import FaceIcon from '@material-ui/icons/Face';
import DoneIcon from '@material-ui/icons/Done';
const useStyles = theme => ({
  root: {
    height: '100%'
  },
  chartContainer: {
    position: 'relative',
    //height: '300px',
    marginTop: theme.spacing(4),
    width: "100%"
  },
});


class LineChart extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      loading : true,

      series: [44, 55, 41, 17, 15],
      chart: {
        width: 350,
        height:100,
        type: "donut"
      },
      dataLabels: {
        enabled: true
      
      },
      fill: {
        type: "gradient"
      },
      legend: {
        formatter: function(val, opts) {
          return val + " - " + opts.w.globals.series[opts.seriesIndex];
        }
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 100,
              height:100

            },
            legend: {
              position: "bottom"
            }
          }
        }
      ]
    
    };
  }


  removeDuplicate = (array, key) =>
  {
    let check = {};
    let res = [];
    for(let i=0; i<array.length; i++) {
        if(!check[array[i][key]]){
            check[array[i][key]] = true;
            res.push(array[i].category);
        }
    }
    return res;
}

  render() {
    setTimeout(() =>  this.setState({loading : false}), 2000);
    const {className, classes, ...rest } = this.props;
    let seriesText = [];
    let seriesData = [];
  
    if (this.props.dashboardChartData !== undefined)
    {
      
      this.props.dashboardChartData.forEach(currentCategory => {

        seriesText.push(currentCategory.category);
        seriesData.push(Number(currentCategory.counts));
     
      
      })
    }

    var labelsUpdate = {...this.state.options}
    labelsUpdate.labels = seriesText;
    seriesText = labelsUpdate;

    return (
<div>
      {this.state.loading === false ? (
        <div>
          

      <Card >
        <CardHeader title="Parts Categories % of Total Parts"/>
        <Divider />
        <CardContent>
          <div className={classes.chartContainer}>
            <ReactApexChart options={seriesText}  series={seriesData} type="donut" height="450px"/>
          </div>
        </CardContent>
      </Card>
     </div>
      ) : (
        <div>
        <br />
        <br />
        <br /> 
  
        <div class="container" width="100%" style={{color:"#FFF"},{textAlign:"center"}}>
        <img src={process.env.PUBLIC_URL + '/loading_.gif'} width="10%"/> 
        </div>
  </div>
      )}
      </div>
    );
  }
}

LineChart.propTypes = {
  className: PropTypes.string,
  piechartdate: PropTypes.array
};

export default withStyles(useStyles)(LineChart);