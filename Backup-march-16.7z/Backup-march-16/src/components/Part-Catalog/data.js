export const dataSource = [
    { count: 75, level: 'Junior Engineer' },
    { count: 95, level: 'Mid-Level Engineer' },
    { count: 53, level: 'Senior Engineer' },
    { count: 23, level: 'Lead Engineer' },
    { count: 18, level: 'Architect' }
  ];