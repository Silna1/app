import React,{Component,Fragment,useState, useEffect} from 'react';
import {Doughnut,Pie} from 'react-chartjs-2';
import ReactApexChart from 'react-apexcharts';
import { Card, Grid, withStyles,Divider } from '@material-ui/core';
import { getChartsDataTop } from '../../store/actions/part_action';
import { processInProgress } from '../../store/actions/misc_action'
import { connect } from 'react-redux';
import { Tooltip } from '@material-ui/core';
import { borderRadius } from '@mui/system';


class TopCats extends Component
{

  constructor(props)
  {
    super(props)
    this.state = {
    loading : true,
    xr : [
      {data:[50,70,30,60,30,70],backgroundColor:['#ffff5c',"#ffbb3d",'#e4d1b9','#C0C0C0','#c0955d','#c2c200'],names:["Racks","Nozzels","Valves","Caps","Pumps","Hydrulic Pumbs"],follow:"Racks"},
      {data:[50,70,30,60,30,70],backgroundColor:['#ffff5c',"#ffbb3d",'#e00000','#240000','#c0955d','#616100'],names:["Racks","Nozzels","Valves","Caps","Pumps","Hydrulic Pumbs"],follow:"Racks"},
      {data:[50,70,30,60,30,70],backgroundColor:['#ffff5c',"#ffbb3d",'#e00000','#240000','#c0955d','#616100'],names:["Racks","Nozzels","Valves","Caps","Pumps","Hydrulic Pumbs"],follow:"Racks"},
      {data:[50,70,30,60,30,70],backgroundColor:['#ffff5c',"#ffbb3d",'#e00000','#240000','#c0955d','#616100'],names:["Racks","Nozzels","Valves","Caps","Pumps","Hydrulic Pumbs"],follow:"Racks"},
 
  ],
  chart: {
    width: 350,
    height:100,
    type: "donut"
  },
  options:{labels:["A","B","C","D"]},
  dataLabels: {
    enabled: true
  },
  fill: {
    type: "gradient"
  },
  legend: {
    formatter: function(val, opts) {
      return val + " - " + opts.w.globals.series[opts.seriesIndex];
    }
  },
  responsive: [
    {
      breakpoint: 480,
      options: {
        chart: {
          width: 100,
          height:100,
        },
        legend: {
          display:false,
          position: "bottom"
        }
      }
    }
  ]

    }
  }
   
  componentDidMount(){
    console.log("Started");
    this.props.getDashboardCharDataTop_action(this.props.organization);
    
    console.log(this.state.xr[0].data);
    if(this.props.parts != undefined)
    {
      console.log("Yes");
      var x = 
      this.setState({xr:1})
      console.log(this.state.xr);
    }
    else
    {
      console.log("No");
    }


    
    
      
  }
  render(){
    setTimeout(() =>  this.setState({loading : false}), 2000);
    

  
    return(

       <Fragment>
    
       <>
    {this.state.loading === false ? (
 <div>
       <br />
       <br />
       <br /> 
       <Grid container spacing={4}>  

       
 {this.props.parts?.map((part, Index ) => (
   <Grid item xs={12} sm={6} lg={6} key={Index}>
          <Card>
          <h4 style={{marginLeft:22,marginTop:10,marginBottom:10}}>{part.follow}</h4>
          
          <Divider/>
          <Pie data={{labels:part.names,datasets:[{data:part.data,backgroundColor:part.backgroundColor}]}} options={{
          tooltips:{
            label:function(tooltipItem,data)
            {
              let value = data.datasets[0].data[tooltipItem.index]
              return value;
            },
            title:function(tooltipItem,data){
              return data.labels[tooltipItem[0].index]
            },
            bodyFontSize:16
          }
        }} height='100%'/>

        </Card>
 </Grid>
 ))}
 
 </Grid>
 </div>
      ) : (
        <div>
        <br />
        <br />
        <br /> 
        <br />
        <br />
        <br /> 
        <div class="container" width="100%" style={{color:"#FFF"},{textAlign:"center"}}>
        <img src={process.env.PUBLIC_URL + '/loading_.gif'} width="10%"/> 
        </div>
  </div>
      )}
      </>
</Fragment>


    
      
    );
  }
}

const mapStateToProps = (state) => {
  return {
    parts: state.parts.GraphItems,
    organization: state.auth && state.auth.user ? state.auth.user.organization : undefined,
  
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    getDashboardCharDataTop_action: (organization) => { dispatch(getChartsDataTop(organization)) },
    processInProgress_action: (status) => dispatch(processInProgress(status)),
   }
}

export default connect(mapStateToProps, mapDispatchToProps)((TopCats));


