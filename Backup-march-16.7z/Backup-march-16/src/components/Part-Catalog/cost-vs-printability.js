import React from 'react'
import clsx from 'clsx';
import PropTypes from 'prop-types';
import ReactApexChart from 'react-apexcharts';
import ApexCharts from 'apexcharts'
import {
  Card,
  CardHeader,
  CardContent,
  Divider,
  withStyles
} from '@material-ui/core';

const useStyles = theme => ({
  root: {
    height: '100%'
  },
  chartContainer: {
    position: 'relative',
    //height: '300px',
    marginTop: theme.spacing(4),
    width: "100%"
  },
  actions: {
    justifyContent: 'flex-end'
  }
});

let _self;
class ScatterChart extends React.Component {

  constructor(props) {
    super(props);
    this.partNameArr = [];
    this.maxYValue = 0;
    this.maxXValue = 0;
    _self = this;

    if (this.props.dashboardChartData !== undefined) {
      this.props.dashboardChartData.forEach(part => {
        if (_self.maxYValue < part.costPrice)
          _self.maxYValue = parseInt(part.costPrice);
        if (_self.maxXValue < part.printabilityScore)
          _self.maxXValue = parseInt(part.printabilityScore);
      });
    }

    _self.maxYValue += 10;
    _self.maxXValue += 10;

    this.state = {
      options: {
        chart: {
          zoom: {
            enabled: true,
            type: 'x'
          },
          events: {
            zoomed: function (chartContext, { xaxis, yaxisArray }) {
              if (!xaxis || xaxis.min === undefined) {
                xaxis.min = 0;
                xaxis.max = _self.maxXValue;
              }

              if (xaxis.min >= 0) {
                let xmin = xaxis.min;
                let xmid = (xaxis.min + xaxis.max) * 0.5;
                let xmax = xaxis.max;

                xmin = Math.round(xmin * 255 / 100);
                xmid = Math.round(xmid * 255 / 100);
                xmax = Math.round(xmax * 255 / 100);

                /*const xminRow = _self.rgbToHex(255 - xmin, 255 - xmin, 255);
                const xmidRow = _self.rgbToHex(255 - xmid, 255 - xmid, 255);
                const xmaxRow = _self.rgbToHex(255 - xmax, 255 - xmax, 255);*/
                const xminRow = _self.rgbToHex(255,255,255);
                const xmidRow = _self.rgbToHex(30, 144, 255);
                const xmaxRow = _self.rgbToHex(255 ,255, 255);

                // For Columns -
                let yaxis = null;
                if (!yaxisArray) {
                  yaxis = { min: 0, max: _self.maxYValue };
                }
                else {
                  yaxis = { min: yaxisArray[0].min, max: yaxisArray[0].max };
                }

                let ymin = yaxis.min;
                let ymid = (yaxis.min + yaxis.max) * 0.5;
                let ymax = yaxis.max;

                ymin = Math.round(ymin * 255 / (_self.maxYValue + 1));
                ymid = Math.round(ymid * 255 / (_self.maxYValue + 1));
                ymax = Math.round(ymax * 255 / (_self.maxYValue + 1));

                const yminCol = _self.rgbToHex(0, 0, 0);
                const ymidCol = _self.rgbToHex(30, 144, 255);
                const ymaxCol = _self.rgbToHex(0, 0, 0);

                _self.setState({
                  ..._self.state,
                  options: {
                    ..._self.state.options,
                    grid: {
                      ..._self.state.options.grid,
                      column: {
                        ..._self.state.options.grid.column,
                        colors: [xminRow, xmidRow, xmaxRow]
                      },
                      row: {
                        ..._self.state.options.grid.row,
                        colors: [yminCol, ymidCol, ymaxCol]
                      }
                    },
                    xaxis: {
                      ..._self.state.options.xaxis,
                      min: xaxis.min,
                      max: xaxis.max
                    },
                    yaxis: {
                      ..._self.state.options.yaxis,
                      min: yaxis.min,
                      max: yaxis.max
                    },
                  }
                })
              }
            },
           
          }
        },
        colors: ['#000'],
        markers: {
          size: 5,
          hover: {
            size: 6
          }
        },
        xaxis: {
          tickAmount: 2,
          labels: {
            formatter: function (val) {
              return parseFloat(val).toFixed(1)
            }
          },
          title: {
            text: 'Printability Score',
            style: {
              fontSize: '14px'
            }
          },
          min: 0,
          max: _self.maxXValue,
        },
        yaxis: {
          tickAmount: 3,
          title: {
            text: 'Complexity',
            style: {
              fontSize: '14px'
            }
          },
          min: 0,
          max: _self.maxYValue,
        },
        tooltip: {
          x: {
            formatter: function (val, opts) {
              if (_self.partNameArr !== undefined)
                return _self.partNameArr[opts.dataPointIndex]
              else
                return val;
            }
          }
        },
        grid: {
          show: true,
          borderColor: '#F3B415',
          strokeDashArray: 0,
          position: 'back',
          xaxis: {
            lines: {
              show: false
            }
          },
          yaxis: {
            lines: {
              show: false
            }
          },
          row: {
            //colors: ['#41abfc', '#9ad6fd', '#c6ecfe'],//["#F3B415", "#F27036", "#663F59", "#6A6E94"],
            colors: ['#FFFFFF', 'DodgerBlue', '#FFFFFF'],//["#F3B415", "#F27036", "#663F59", "#6A6E94"],
            opacity: 0.5
          },
          column: {
            colors: ['#FFFFFF', 'DodgerBlue', '#FFFFFF'],//["#F3B415", "#F27036", "#663F59", "#6A6E94"],
            opacity: 0.5
          },
          padding: {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
          },
        },
      }
    }
  }

  // reset scale to original value on reset button click.
  resetZoom(chartevent) {
    if (chartevent.target.title === "Reset Zoom") {
      ApexCharts.exec('printabilityChart', 'updateOptions', {
        xaxis: {
          min: 0,
          max: _self.maxXValue
        }
      }, false, true);
    }
  }

  rgbToHex(r, g, b) {
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }

  render() {
    const { className, classes, ...rest } = this.props;

    //prepare series data
    let seriesData = [];
    let cpPrintabilityScoreData = [];
    if (this.props.dashboardChartData !== undefined) {
      this.props.dashboardChartData.forEach(part => {
        if (_self.maxYValue < part.complexity)
          _self.maxYValue = parseInt(part.complexity);
        if (_self.maxXValue < part.printabilityScore)
          _self.maxXValue = parseInt(part.printabilityScore);
        cpPrintabilityScoreData.push([part.printabilityScore, part.complexity]);
        this.partNameArr.push(part.name);
      });
      seriesData.push({ 'name': 'Complexity', type: 'scatter', 'data': cpPrintabilityScoreData });
    }
    return (
      <Card
        {...rest}
        className={clsx(classes.root, className)}
      >
        <CardHeader
          title="Complexity Vs Printability Score"
        />
        <Divider />
        <CardContent>
          <div className={classes.chartContainer}>
            <ReactApexChart options={this.state.options} series={seriesData} type="scatter" height="350" />
          </div>
        </CardContent>
      </Card>
    );
  }
}

ScatterChart.propTypes = {
  className: PropTypes.string,
  dashboardChartData: PropTypes.array
};

export default withStyles(useStyles)(ScatterChart);
