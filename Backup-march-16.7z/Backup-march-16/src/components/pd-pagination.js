import React from 'react'
import PropTypes from 'prop-types';

// ********material ui imports**************
//import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
//import LastPageIcon from '@material-ui/icons/LastPage';
import IconButton from '@material-ui/core/IconButton';

// ********Component imports**************
import { connect } from 'react-redux'
import { useTheme } from '@material-ui/core/styles';
import { useStyles1 } from '../Styles/dahboardLayout_styles'
import { getPartsData } from '../store/actions/part_action'


function TablePaginationActions(props) {
    const classes = useStyles1();
    const theme = useTheme();
    const { count, page, rowsPerPage, onChangePage, parts, selectedClient, /*searchStatus, organization,*/ lastEvaluatedKey } = props;

    /* last page button commented no need for now*/
    // function handleFirstPageButtonClick(event) {
    //     onChangePage(event, 0);
    // }

    function handleBackButtonClick(event) {
        onChangePage(event, page - 1);
    }

    function handleNextButtonClick(event) {
        onChangePage(event, page + 1);
        //page number start from 0, when you click on next page button here you get previous page number
        let valuePerPage = (page + 2) * rowsPerPage;
        //checks next part count is greater than or equal to fetched parts and it is less than or equal to total part count
        // for serch product is already in memory so no need to update store.
        if (!parts.searchStatus) {
            if (valuePerPage >= parts.Items.length && valuePerPage <= parts.totalPartsCount) {
                props.getParts_action(lastEvaluatedKey.id, selectedClient);
            }
        }
    }

    /* last page button commented no need for now*/

    // function handleLastPageButtonClick(event) {
    //     onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
    //     if (!searchStatus)
    //         props.getParts_action(lastEvaluatedKey.id, organization);
    // }

    return (
        <div className={classes.root}>
            {parts.Count !== undefined ?
                (
                    <React.Fragment>
                        {/* <IconButton
                            onClick={handleFirstPageButtonClick}
                            disabled={page === 0}
                            aria-label="First Page"
                        >
                            {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
                        </IconButton> */}
                        <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="Previous Page"  style={{color:'#000'}}>
                            {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
                        </IconButton>
                        <IconButton
                            onClick={handleNextButtonClick}
                            disabled={page >= Math.ceil(count / rowsPerPage) - 1}
                            aria-label="Next Page"
                            style={{color:'#000'}}
                        >
                            {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
                        </IconButton>
                        {/* <IconButton
                            onClick={handleLastPageButtonClick}
                            disabled={page >= Math.ceil(count / rowsPerPage) - 1}
                            aria-label="Last Page"
                        >
                            {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
                        </IconButton> */}
                        {/* <label style={{ float: 'left', padding: "17px" }}>Total Parts : {totalParts}</label> */}
                    </React.Fragment>) : null}
        </div>
    );
}

TablePaginationActions.propTypes = {
    count: PropTypes.number.isRequired,
    onChangePage: PropTypes.func.isRequired,
    page: PropTypes.number.isRequired,
    rowsPerPage: PropTypes.number.isRequired,
    organization: PropTypes.string,
    lastEvaluatedKey: PropTypes.object,
    getParts_action: PropTypes.func,
    parts: PropTypes.any,
    searchStatus: PropTypes.any
};

const mapStateToProps = (state) => {
    return {
        lastEvaluatedKey: state.parts.LastEvaluatedKey,
        searchStatus: state.parts.searchStatus,
        parts: state.parts,
        selectedClient: state.misc.selectedClient,
        organization: state.auth.user.organization,
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        getParts_action: (lastEvaluatedKey, organization) => dispatch(getPartsData({ 'lastEvaluatedKey': lastEvaluatedKey, 'organization': organization })),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(TablePaginationActions);