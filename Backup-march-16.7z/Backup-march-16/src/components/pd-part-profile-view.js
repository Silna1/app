import React, { Component } from "react";
import Postcard from "./pd-postcard";
import { connect } from 'react-redux';
import { processInProgress } from '../store/actions/misc_action';

class PartProfileView extends Component {
    constructor(props) {
        super(props)
        this.state = { matchId: "" }
    }

    componentDidMount() {
        this.props.processInProgress_action(true);
        if (this.props.match) {
            this.setState({ matchId: this.props.match.params.id })
        } else {
            this.setState({ matchId: this.props.partId })
        }
    }

    render() {
        return (
            this.state.matchId &&
            <Postcard matchId={this.state.matchId} />
        )
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        processInProgress_action: (status) => dispatch(processInProgress(status)),
    }
}

export default connect(null,mapDispatchToProps)(PartProfileView);