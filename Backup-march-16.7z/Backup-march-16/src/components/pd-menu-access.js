// ********Main imports**************
import React, { useEffect } from "react";
import PropTypes from "prop-types";

// ********Material ui imports**************

import TablePagination from "@material-ui/core/TablePagination";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Divider from "@material-ui/core/Divider";
import Fab from "@material-ui/core/Fab";
import cloneDeepWith from "lodash/cloneDeepWith";
import Container from '@material-ui/core/Container';
import { styled } from '@mui/material/styles';
import clsx from 'clsx';
import PerfectScrollbar from 'react-perfect-scrollbar';
import {
  Avatar,
  Box,
  Checkbox,
  Typography
} from '@mui/material';
import { getInitials } from './utils/get-initials';



// ********Component imports**************
import { connect } from "react-redux";
import TablePaginationActions from "./pd-pagination";
import { useStyles2 } from "../Styles/dahboardLayout_styles";
import {
  fetchProject
} from "../store/actions/project_action";
import {
    fetchLocation
} from "../store/actions/location_action"
import {
  searchInProgress,
  getPartsData,
  getTotalPartsCount,
  totalPartsCount,
} from "../store/actions/part_action";
import { getUsersdata } from '../store/actions/user_action';
import {
  processInProgress,
  setSelectedClient,
  clients
} from "../store/actions/misc_action";
import color from "@material-ui/core/colors/amber";
import { Button,Modal,Form,Spinner,Alert } from 'react-bootstrap';
import {
  Card,
  CardActions,
  CardHeader,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableRow,
} from '@material-ui/core';
import TextField from '@mui/material/TextField';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';
import TableHead from '@mui/material/TableHead';
import ArrowRightIcon from '@material-ui/icons/ArrowRight';
import Scrollbar from 'react-scrollbar';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { format } from 'date-fns';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import {NavbarData} from './navbarData';
import {
    fetchMenuAccess,
    update_MenuAccess,
    fetchall_MenuAccess
} from "../store/actions/menuaccess_action"
const axios = require("axios");

const CustomSelect = styled(Select)(() => ({
    width: '100%',
    marginBottom: '16px',
}))

const useStyles = theme => ({
  root: {},
  content: {
    padding: 0,
    marginTop:'100px'
  },
  inner: {
    minWidth: 350,
    overflow: 'auto',
    height: 350,
  },
  statusContainer: {
    display: 'flex',
    alignItems: 'center'
  },
  status: {
    marginRight: theme.spacing(1)
  },
  actions: {
    justifyContent: 'flex-end'
  }
});

function MenuAccess(props) {
  const {
    clientsarray,
    fetchClients_action,
    privilege,
    selectedClient,
    client,
    clientList,
    className, 
    project,
    fetchprojects_action,
    fetchLocation_action,
    location,
    usersData,
    organization,
    getUserdata_action,
    fetchMenuAccess_action,
    clients_action,
    update_MenuAccess_action,
    fetchall_MenuAccess_action,
    ...rest
  } = props;


  console.log("pd-menu access ",props);
  const classes = useStyles2();
  const [page, setPage] = React.useState(0);
  const [searchValue, setsearchValue] = React.useState("");

  //
  const [open, setIsOpen] = React.useState("");
  const [show, setshowFile] = React.useState(null);
  const [file, setFile] = React.useState(null);
  const [isButtonHidden, setisButtonHidden] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const [messageText,setmessageText]= React.useState("");
  const [isFile, setisFile] = React.useState(false);
  const [datax, setdatax] = React.useState("...");
  const [previlegeNameValue,setprevilegeNameValue] = React.useState('');
  const [accessData,setAccessData] = React.useState(null);
  const [previlegeList,setPrevilegeList] = React.useState([]);

  const [rowsPerPage, setRowsPerPage] = React.useState(4);
  const [clients, setClients] = React.useState(client);
  //called First time when component mounts and every other time when part add is called


  //create REF to call child function from parent
  const child = React.createRef();
  
  useEffect(()=>{
    fetchall_MenuAccess_action().then((res)=>
    {
        setPrevilegeList(res.Items);
    })
    .catch((error)=>
    {
        console.log("Error",error);
    })
  },[])

  const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    width:'200px',
    height:'200px',
    color: theme.palette.text.secondary,

  }));


  const [selectedCustomerIds, setSelectedCustomerIds] = useState([]);
  const [limit, setLimit] = useState(10);

  const handleSelectAll = (event) => {
    let newSelectedCustomerIds;

    if (event.target.checked) {
      newSelectedCustomerIds = usersData.map((client) => client.email);
    } else {
      newSelectedCustomerIds = [];
    }

    setSelectedCustomerIds(newSelectedCustomerIds);
  };

  const handleSelectOne = (event, id) => {
    const selectedIndex = selectedCustomerIds.indexOf(id);
    let newSelectedCustomerIds = [];

    if (selectedIndex === -1) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds, id);
    } else if (selectedIndex === 0) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds.slice(1));
    } else if (selectedIndex === selectedCustomerIds.length - 1) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(
        selectedCustomerIds.slice(0, selectedIndex),
        selectedCustomerIds.slice(selectedIndex + 1)
      );
    }

    setSelectedCustomerIds(newSelectedCustomerIds);
    console.log("newSelectedCustomerIds ",newSelectedCustomerIds[0],newSelectedCustomerIds.length);
    fetchprojects_action();
    console.log("Organisation",organization);
    getUserdata_action(organization);
  };

  const handleLimitChange = (event) => {
    setLimit(event.target.value);
  };

  const handlePageChange = (event, newPage) => {
    setPage(newPage);
  };

  //Pagination function
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  //Pagination function
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSave = () => {
    console.log("handleSave update ",accessData);
    update_MenuAccess_action(accessData);  
   
   }

   const handleCancel = () => {
    console.log("handleCancel update ",client);  
   
   }

   const handleChange = (event) => {
   event.preventDefault();
   setprevilegeNameValue(event.target.value);
   console.log("fetchMenuAccess_action",event);
   const accessDataProxy = previlegeList.find(item => item.previlegeName === event.target.value)
   setAccessData(accessDataProxy);
//    fetchMenuAccess_action(event.target.value).then((res)=>
//    {
//         console.log("handlechange",res);
//         setAccessData(res.Items[0]);
//    })
//    .catch((error)=>
//    {
//        console.log("error",error);
//    })
   
}

const handleCheckBoxChange = (event)=>
{
    event.preventDefault();
    console.log("handleCheckboxchange",event.target.name);
    setAccessData({...accessData,[event.target.name]: event.target.checked});
}

const renderTableRow = (item) => {
    return(
        <TableRow
        hover
        key={item.name}
        selected={selectedCustomerIds.indexOf(item.name) !== -1}
      >
        <TableCell>
          <Box
            sx={{
              alignItems: 'center',
              display: 'flex'
            }}
          >
          {item.icon? 
          item.icon :  <Avatar
          src={item.icon}
          sx={{ mr: 2 }}
        >
          {getInitials(item.name)}
        </Avatar>

          }
           
            <Typography
              color="textPrimary"
              variant="body1"
            >
              {item.name}
            </Typography>
          </Box>
        </TableCell>
        <TableCell>
        <Checkbox name={`${item.key}View`} onChange={handleCheckBoxChange}  checked={accessData?accessData[`${item.key}View`] : false}/>
        </TableCell>
        <TableCell>
        <Checkbox name={`${item.key}Add`} onChange={handleCheckBoxChange} checked={accessData?accessData[`${item.key}Add`] : false}/>
        </TableCell>
        <TableCell>
        <Checkbox  name={`${item.key}Edit`} onChange={handleCheckBoxChange} checked={accessData?accessData[`${item.key}Edit`] : false}/>
        </TableCell>
        <TableCell>
        <Checkbox name={`${item.key}Delete`} onChange={handleCheckBoxChange} checked={accessData?accessData[`${item.key}Delete`] : false}/>
        </TableCell>
      
      </TableRow>
    );
}

  return (
      <>
       <Box >
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
                marginTop:'50px',
                width:'1250px'
              }}
            >
              <Typography
                sx={{ m: 1,color:'#19b4dd',fontWeight: 600 }}
                variant="h4"
              >
                Menu Access Settings
              </Typography>
              <Box sx={{ m: 1 }}>
               
              <Button onClick={handleSave} style={{color:"#19b4dd",mr: 1}}  variant="outlined" startIcon={<SaveIcon />}>
                        <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                            Save
                        </Typography>
                    </Button>
                    <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" type="submit" onClick={handleCancel} startIcon={<CancelIcon  />}>
                        
                            <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                                Cancel
                            </Typography>
                            
                        </Button>
              </Box>
             
            </Box>
            <Divider/>
            <Grid>
            <InputLabel id="demo-simple-select-label">Menu Access Group</InputLabel>
                        <CustomSelect
                           // value={client.country}
                            label="Group"
                            onChange={handleChange}
                            select
                            label="Client"
                            variant="outlined"
                            value={previlegeNameValue}
                            required
                            size="large"
                            style={{marginLeft:20,width:"70%",marginBottom:20}}
                          >
                            {previlegeList?.map((option) => (
                              <MenuItem key={option} value={option.previlegeName}>
                                {option.previlegeName}
                              </MenuItem>
                            ))}
                        </CustomSelect>
            </Grid>
    <Box
      sx={{
        display: 'flex',
        '& > :not(style)': {
          m: 1,
         
        },
        marginTop:'40px'
      }}
    >
    <Card {...rest} style= {{width:'100%' ,marginTop:'20px'}}>
      <PerfectScrollbar>
        <Box sx={{  }}>
          <Table>
            <TableHead sx={{ backgroundColor: 'whitesmoke' }}>
              <TableRow>
                <TableCell>
                  Menu
                </TableCell>
                <TableCell>
                  View
                </TableCell>
                <TableCell>
                  Add
                </TableCell>
                <TableCell>
                  Edit
                </TableCell>
                <TableCell>
                  Delete
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {NavbarData.slice(0, limit).map((item,i) => 
              <>{item.showMenu &&  renderTableRow(item)}
              {item.subList && item.subList.map((subitem)=>
                {return subitem.showMenu &&  renderTableRow(subitem)}
              )}
              </>

                )}
            </TableBody>
          </Table>
        </Box>
      </PerfectScrollbar>
      <TablePagination
        component="div"
        count={NavbarData?.length}
        onPageChange={handlePageChange}
        onRowsPerPageChange={handleLimitChange}
        page={page}
        rowsPerPage={limit}
        rowsPerPageOptions={[5, 10, 25]}
      />
    </Card>
    </Box>
    </Box>
      </>

  );
}

MenuAccess.propTypes = {
  selectedClient: PropTypes.string,
  client: PropTypes.string,
  clientList: PropTypes.any,
  clientsarray:PropTypes.array,
  fetchClients:PropTypes.func,
  fetchprojects_action:PropTypes.func,
  project: PropTypes.array,
  usersData: PropTypes.object,
  organization: PropTypes.string,
  getUserdata_action: PropTypes.func,
  fetchMenuAccess_action: PropTypes.func,
  update_MenuAccess_action: PropTypes.func,
  fetchall_MenuAccess_action: PropTypes.func
};

const mapStateToProps = (state) => {
  return {
    selectedClient: state.misc.selectedClient
      ? state.misc.selectedClient
      : undefined,
    clientList: state.misc.clients,
    project:state.project.projects,
    location:state.location.locations,
    usersData: state.users.usersdata,
    organization: state.auth.user ? state.auth.user.organization : undefined
   
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    searchProgress_action: (status) => dispatch(searchInProgress(status)),
    processInProgress_action: (status) => dispatch(processInProgress(status)),
    setSelectedClient_action: (client) => dispatch(setSelectedClient(client)),
    fetchprojects_action:()=>dispatch(fetchProject()),
    fetchLocation_action: () => dispatch(fetchLocation()),
    getUserdata_action: (organization) => dispatch(getUsersdata(organization)),
    fetchMenuAccess_action:(previlegeName) => dispatch(fetchMenuAccess(previlegeName)),
    clients_action:()=> dispatch(clients()),
    update_MenuAccess_action:(accessData)=> dispatch(update_MenuAccess(accessData)),
    fetchall_MenuAccess_action:()=> dispatch(fetchall_MenuAccess())
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(MenuAccess);
