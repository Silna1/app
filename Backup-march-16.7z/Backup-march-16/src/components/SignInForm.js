import React, { Component } from "react";
import { Link, withRouter } from "react-router-dom";
import { connect } from "react-redux";
import Button from '@material-ui/core/Button';
import { Auth } from "aws-amplify";
import { login, setCognitoUser } from '../store/actions/authentication_action';
import { useStyles } from '../Styles/signIn_styles';
import { signIn } from '../store/actions/auth_action'
//const classes = useStyles();

class SignInForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      email: "",
      password: ""
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    let target = event.target;
    let value = target.type === "checkbox" ? target.checked : target.value;
    let name = target.name;

    this.setState({
      [name]: value
    });
  }

  handleSubmit(event) {
    event.preventDefault();

    console.log("The form was submitted with the following data:");
    console.log(this.state);
  }

  handleLogin = async (e) => {
    e.preventDefault();
    console.log('email', this.state.email, this.state.password)
    try {
      const response = await Auth.signIn(this.state.email, this.state.password);
      console.log('loggedin', response)
      if(response.signInUserSession) {
        const token = response.signInUserSession.idToken.jwtToken;
        console.log('token', token)
        this.props.auth_action(response.signInUserSession.idToken.payload)
      } else {
        this.props.setCognitoUser_action(response);
        this.props.history.push({
          pathname: '/reset-password',
          state: {username: this.state.email, password: this.state.password}
        })
      }
    } catch (e) {
      alert(e.message);
    }
  }

  render() {
    return (
      <div className="formCenter">
        <form className="formFields" onSubmit={this.handleSubmit}>
          <div className="formField">
            <label className="formFieldLabel" htmlFor="email">
              E-Mail Address
            </label>
            <input
              type="email"
              id="email"
              className="formFieldInput"
              placeholder="Enter your email"
              name="email"
              value={this.state.email}
              onChange={this.handleChange}
            />
          </div>

          <div className="formField">
            <label className="formFieldLabel" htmlFor="password">
              Password
            </label>
            <input
              type="password"
              id="password"
              className="formFieldInput"
              placeholder="Enter your password"
              name="password"
              value={this.state.password}
              onChange={this.handleChange}
            />
          </div>
          <div className="remember">
           
              <div className="forgot">
                  <div className="forgot-password text-end">
                  <Link to="/forgot-password">Forgot password?</Link>
                  </div>
              </div>
           </div>

          <div className="formField">
            <button onClick={this.handleLogin} className="formFieldButton">Sign In</button>{" "}
           
          </div>

        
        </form>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    auth: state.auth.initialized ? state.auth.initialized : undefined,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    auth_action: (payload) => dispatch(login(payload)),
    login_action: () => dispatch(signIn()),
    setCognitoUser_action: (data) => dispatch(setCognitoUser(data)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(SignInForm));
