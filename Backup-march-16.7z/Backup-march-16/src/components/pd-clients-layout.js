// ********Main imports**************
import React, { useEffect } from "react";
import PropTypes from "prop-types";

// ********Material ui imports**************

import TablePagination from "@material-ui/core/TablePagination";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Divider from "@material-ui/core/Divider";
import Fab from "@material-ui/core/Fab";
import cloneDeepWith from "lodash/cloneDeepWith";
import Container from '@material-ui/core/Container';
import { styled } from '@mui/material/styles';
import clsx from 'clsx';
import PerfectScrollbar from 'react-perfect-scrollbar';
import {
  Avatar,
  Box,
  Checkbox,
  Typography
} from '@mui/material';
import { getInitials } from './utils/get-initials';



// ********Component imports**************
import { connect } from "react-redux";
import TablePaginationActions from "./pd-pagination";
import { useStyles2 } from "../Styles/dahboardLayout_styles";
import {
  fetchClients,
  deleteClient,
  addClient,
  updateClient,
} from "../store/actions/client_action";
import {
  searchInProgress,
  getPartsData,
  getTotalPartsCount,
  totalPartsCount,
} from "../store/actions/part_action";
import {
  processInProgress,
  setSelectedClient,
} from "../store/actions/misc_action";
import color from "@material-ui/core/colors/amber";
import { Button,Modal,Form,Spinner,Alert } from 'react-bootstrap';
import {
  Card,
  CardActions,
  CardHeader,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableRow,
} from '@material-ui/core';
import TableHead from '@mui/material/TableHead';
import ArrowRightIcon from '@material-ui/icons/ArrowRight';
import Scrollbar from 'react-scrollbar';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { format } from 'date-fns';
import ButtonGroup from '@mui/material/ButtonGroup';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import VisibilityIcon from '@material-ui/icons/Visibility';
const axios = require("axios");

const useStyles = theme => ({
  root: {},
  content: {
    padding: 0,
    marginTop:'100px'
  },
  inner: {
    minWidth: 350,
    overflow: 'auto',
    height: 350,
  },
  statusContainer: {
    display: 'flex',
    alignItems: 'center'
  },
  status: {
    marginRight: theme.spacing(1)
  },
  actions: {
    justifyContent: 'flex-end'
  }
});

function ClientLayoutList(props) {
  const {
    clientsarray,
    fetchClients_action,
    privilege,
    selectedClient,
    client,
    clientList,
    className, 
    ...rest
  } = props;


  console.log("silna surendran",props);
  const classes = useStyles2();
  const [page, setPage] = React.useState(0);
  const [searchValue, setsearchValue] = React.useState("");

  //
  const [open, setIsOpen] = React.useState("");
  const [show, setshowFile] = React.useState(null);
  const [file, setFile] = React.useState(null);
  const [isButtonHidden, setisButtonHidden] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const [messageText,setmessageText]= React.useState("");
  const [isFile, setisFile] = React.useState(false);
  const [datax, setdatax] = React.useState("...");
  

  const [rowsPerPage, setRowsPerPage] = React.useState(4);
  const [clients, setClients] = React.useState(client);
  //called First time when component mounts and every other time when part add is called


  //create REF to call child function from parent
  const child = React.createRef();

  const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    width:'200px',
    height:'200px',
    color: theme.palette.text.secondary,

  }));

  const [selectedCustomerIds, setSelectedCustomerIds] = useState([]);
  const [limit, setLimit] = useState(10);

  const handleSelectAll = (event) => {
    let newSelectedCustomerIds;

    if (event.target.checked) {
      newSelectedCustomerIds = clientsarray.map((customer) => client.id);
    } else {
      newSelectedCustomerIds = [];
    }

    setSelectedCustomerIds(newSelectedCustomerIds);
  };

  const handleSelectOne = (event, id) => {
    const selectedIndex = selectedCustomerIds.indexOf(id);
    let newSelectedCustomerIds = [];

    if (selectedIndex === -1) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds, id);
    } else if (selectedIndex === 0) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds.slice(1));
    } else if (selectedIndex === selectedCustomerIds.length - 1) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(
        selectedCustomerIds.slice(0, selectedIndex),
        selectedCustomerIds.slice(selectedIndex + 1)
      );
    }

    setSelectedCustomerIds(newSelectedCustomerIds);
  };

  const handleLimitChange = (event) => {
    setLimit(event.target.value);
  };

  const handlePageChange = (event, newPage) => {
    setPage(newPage);
  };

  //Pagination function
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  //Pagination function
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };


  const handleView = (data) => {
   // deleteProject_action(data)
  }

  const handleEdit = (id) => {
   // history.push(`/project/edit/${id}`);
  }

  const handleDelete = (data) => {
   // deleteProject_action(data)
  }

  // {/* Searchbar with camera icon button */}
  return (
    <Card {...rest} style= {{width:'100%' ,marginTop:'20px'}}>
      <PerfectScrollbar>
        <Box sx={{  }}>
          <Table>
            <TableHead sx={{ backgroundColor: 'whitesmoke' }}>
              <TableRow>
                <TableCell>
                  Name
                </TableCell>
                <TableCell>
                  Email
                </TableCell>
                <TableCell>
                  Phone Number
                </TableCell>
                <TableCell>
                  Sector
                </TableCell>
                <TableCell>
                  Client Type
                </TableCell>
                <TableCell>
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {clientsarray.slice(0, limit).map((client) => (
                <TableRow
                  hover
                  key={client.id}
                  selected={selectedCustomerIds.indexOf(client.id) !== -1}
                >
                  <TableCell>
                    <Box
                      sx={{
                        alignItems: 'center',
                        display: 'flex'
                      }}
                    >
                      <Avatar
                        src={client.clientLogo}
                        sx={{ mr: 2 }}
                      >
                        {getInitials(client.clientName)}
                      </Avatar>
                      <Typography
                        color="textPrimary"
                        variant="body1"
                      >
                        {client.clientName}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    {client.email}
                  </TableCell>
                  <TableCell>
                  {client.phoneNumber}
                  </TableCell>
                  <TableCell>
                  {client.sector?.name}
                  </TableCell>
                  <TableCell>
                  {client.clientType}
                  </TableCell>
                  <TableCell>
                  <ButtonGroup variant="outlined" aria-label="outlined primary button group">
                  <VisibilityIcon onClick={() => handleView(client.clienttId)} className={classes.icons} color='inherit'/>
                  <EditIcon onClick={() => handleEdit(client.clientId)} className={classes.icons} color='inherit'/>
                  <DeleteIcon onClick={() => handleDelete(client)} className={classes.icons} color='inherit' />
                  </ButtonGroup>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      </PerfectScrollbar>
      <TablePagination
        component="div"
        count={clientsarray.length}
        onPageChange={handlePageChange}
        onRowsPerPageChange={handleLimitChange}
        page={page}
        rowsPerPage={limit}
        rowsPerPageOptions={[5, 10, 25]}
      />
    </Card>

  );
}

ClientLayoutList.propTypes = {
  selectedClient: PropTypes.string,
  client: PropTypes.string,
  clientList: PropTypes.any,
  clientsarray:PropTypes.array,
  fetchClients:PropTypes.func,
};

const mapStateToProps = (state) => {
  return {
    selectedClient: state.misc.selectedClient
      ? state.misc.selectedClient
      : undefined,
    clientList: state.misc.clients,
   
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    searchProgress_action: (status) => dispatch(searchInProgress(status)),
    processInProgress_action: (status) => dispatch(processInProgress(status)),
    getPartsData_action: (organization) =>
      dispatch(
        getPartsData({ lastEvaluatedKey: null, organization: organization })
      ),
    setSelectedClient_action: (client) => dispatch(setSelectedClient(client)),
    setTotalpartCount_action: (count) => dispatch(totalPartsCount(count)),
    getTotalPartCount_action: (organization) =>
    dispatch(getTotalPartsCount(organization)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ClientLayoutList);
