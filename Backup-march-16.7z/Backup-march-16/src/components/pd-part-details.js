import React, { Component, useEffect } from "react";
import clsx from 'clsx';
import Typography from "@material-ui/core/Typography";
import TextField from '@material-ui/core/TextField';
import { withStyles } from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import Grid from '@material-ui/core/Grid';
import { fetchMaterials,getCategoriesList } from '../store/actions/part_action';
import { connect } from 'react-redux';
import { config } from '../config'
import { FetchAPI } from '../fetch'
import cloneDeepWith from 'lodash/cloneDeepWith' 
import { parse } from "path";
import Autocomplete from '@material-ui/lab/Autocomplete';
import { values } from "lodash";
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import { TheatersOutlined } from "@material-ui/icons";

const useStyles = (theme) => ({
    root: {
        display: 'flex',
        flexGrow: 1,
        flexWrap: 'wrap',
    },
    margin: {
        margin: theme.spacing(1),
    },
    textField: {
        paddingRight: theme.spacing(2),
        flexBasis: 200,
    },
    printabilityScoreTextField: {
        color: 'blue',
        fontSize: 'large'
    }
});

class PartDetails extends Component {

    

    constructor(props) {
        super(props)
        this.complexityValueList = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"];
        
        this.state = {
            newPartData: { ...this.props.partData},  
            newAutoData: [{"category":"Loading..."}],
        
      
  
        }
    }



    componentWillReceiveProps(props) {
        if(props.catsx !== undefined)
        {
            this.setState({newAutoData:props.catsx})
        }
        else
        {
            console.log("Loading Data");
        }   
    }

    

    handleChange = (property) => event => {
        let value = event.target.value;
        if (property === 'length' || property === 'breadth' || property === 'height') {
            let size = this.state.newPartData.size;
            size[property] = value;
            this.setState({ size: size });
            this.props.partdataHandler({ size: size });
        } else {
    
            // newPartData
            let partData = cloneDeepWith(this.state.newPartData);
            partData[property] = value;
            this.setState({ newPartData: partData });
            this.props.partdataHandler({ [property]: value })

         
            
        }
    }

    onInputChange(event,value){
       if(event)
       {
        let partData = cloneDeepWith(this.state.newPartData);
        partData["subcategory"] = value;
        this.setState({ newPartData: partData });
        this.props.partdataHandler({ ["subcategory"]: value })
       }
       
        }


    handleBlur = () => event => {
        if (window.location.pathname.includes('/partedit')) {
            const url = config.HostURL + "/score/getprintabilityScore";
            FetchAPI.postData(url, this.state.newPartData)
                .then(data => {
                    let PartData = this.state.newPartData;
                    PartData["printabilityScore"] = data.Score;
                    this.setState({ newPartData: PartData });
                    this.props.partdataHandler({ "printabilityScore": data.Score })
                })
                .catch(err => {
                    console.log({ "Error": err });
                });
        }
    }

componentDidMount()
{
    this.props.getCategoriesList_action(this.props.organization)   
}





    render() {
        const { partData, classes, partdataHandler, fetchMaterials_action, materials,getCategoriesList_action,catsx } = this.props;
       


        if (this.props.partData && this.props.partData.name !== "" && this.state.newPartData.name === "")
        {
            
            this.setState({ newPartData: this.props.partData});  
        
           
           
            
        }
           
        
        (() => (materials ? [...materials] : fetchMaterials_action()))();
       
        


        let printabilitySection = '';
        if (window.location.pathname.includes('/partedit') || window.location.pathname.includes('/partprofileview')) {
            printabilitySection =
                (<Grid item xs={12} sm={6} lg={5}>
                    <TextField
                        fullWidth
                        label="Printability Score"
                        className={clsx(classes.margin, classes.textField)}
                        type="number"
                        InputProps={{
                            inputProps: { min: 0 },
                            className: classes.printabilityScoreTextField,
                            readOnly: true
                        }}
                        value={this.state.newPartData.printabilityScore}
                        onChange={this.handleChange('printabilityScore')}
                        margin="normal"
                        variant="outlined"
                    />
                </Grid>);
        }
     
        
        return (
            <React.Fragment>
                <Grid container>
                    {!partdataHandler &&
                        <Grid item xs={12} sm={partdataHandler ? 6 : 12} lg={12} margin={3}>
                            {partData.timeStamp &&
                                <p>
                                    {"Part Creation Date : " + partData.timeStamp.split("T")[0] + " " + partData.timeStamp.split("T")[1].split('.')[0]}
                                </p>
                            }
                            <Typography
                                className={"MuiTypography--heading"}
                                variant={"h6"}
                                gutterBottom
                            >
                                {partData.name}
                            </Typography>
                        </Grid>
                    }
                    {partdataHandler &&
                        <Grid item xs={12} sm={10} lg={10} >
                            <TextField
                                fullWidth
                                className={clsx(classes.margin, classes.textField)}
                                variant="outlined"
                                label="Name"
                                value={this.state.newPartData.name}
                                onChange={this.handleChange('name')}
                                required={partdataHandler}
                            />
                        </Grid>
                    }







<Grid item xs={12} sm={partdataHandler ? 10 : 10} lg={partdataHandler ? 10 : 10}>  
<>
{window.location.pathname.includes('/partprofileview')? (


  <TextField disabled fullWidth className={clsx(classes.margin, classes.textField)}  label="Category" value={this.state.newPartData.category}  margin="normal" variant="outlined"  />

    ) : (
<>
<InputLabel htmlFor="grouped-native-select" style={{marginLeft:10}}>Category *</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          margin="normal" 
          variant="outlined" 
          required={partdataHandler}
          value = {window.location.pathname.includes('/partedit')?this.state.newPartData.category:console.log()}
          onChange={this.handleChange('category')}
          disabled={window.location.pathname.includes('/partedit')|| window.location.pathname.includes('/partadd')?false:true}
         style={{width:"99%",marginLeft:6,marginBottom:10}}
         
        >
         
          <MenuItem value="Valves">Valves</MenuItem>
          <MenuItem value="Piping systems">Piping systems</MenuItem>
          <MenuItem value="Pumps">Pumps</MenuItem>
          <MenuItem value="Hydraulic systems">Hydraulic systems</MenuItem>
          <MenuItem value="Sealing technology">Sealing technology</MenuItem>
          <MenuItem value="Nozzles">Nozzles</MenuItem>
          <MenuItem value="Gear housings">Gear housings</MenuItem>
          <MenuItem value="Burners">Burners</MenuItem>
          <MenuItem value="Various Downhole">Various Downhole</MenuItem>
          <MenuItem value="Various Top side">Various Top side</MenuItem>
        </Select>
        </>
     
         )}
         </>
   </Grid>

        <Grid item xs={12} sm={partdataHandler ? 10 : 10} lg={partdataHandler ? 10 : 10}>    
<Autocomplete
        id="free-solo-demo"
        value={this.state.newPartData.subcategory} 
        options={this.state.newAutoData.map((option) => String(option.subcategory))}
        freeSolo
        required={partdataHandler}
        onInputChange={window.location.pathname.includes('/partedit')|| window.location.pathname.includes('/partadd')?(event,value)=>this.onInputChange(event,value):console.log("Part Profile View")}
        
        disabled={!partdataHandler ? true : false}
        renderInput={(params) => (
          <TextField {...params} fullWidth className={clsx(classes.margin, classes.textField)}  label="Sub Category"  margin="normal" variant="outlined"  />
        )}
      />
         
                    </Grid>
                    <Grid item xs={12} sm={10} lg={10}>
                        <TextField
                            fullWidth
                            disabled={!partdataHandler ? true : false}
                            className={clsx(classes.margin, classes.textField)}
                            variant="outlined"
                            label="Number"
                            value={this.state.newPartData.number}
                            onChange={this.handleChange('number')}
                            required={partdataHandler}
                        />
                    </Grid>
                    <Grid item xs={12} sm={12} lg={10}>
                        <TextField
                            disabled={!partdataHandler ? true : false}
                            id="outlined-multiline-static"
                            className={clsx(classes.margin, classes.textField)}
                            fullWidth
                            label="Description"
                            value={this.state.newPartData.description}
                            onChange={this.handleChange('description')}
                            margin="normal"
                            variant="outlined"
                            required={partdataHandler}
                        />
                    </Grid>
                    <Grid item xs={12} sm={4} lg={3}>
                        <TextField
                            fullWidth
                            disabled={!partdataHandler ? true : false}
                            className={clsx(classes.margin, classes.textField)}
                            variant="outlined"
                            label="Length(mm)"
                            type="number"
                            InputProps={{ inputProps: { min: 0 } }}
                            value={this.state.newPartData.size.length}
                            onChange={this.handleChange('length')}
                            onBlur={this.handleBlur()}
                            required={partdataHandler}
                        />
                    </Grid>
                    <Grid item xs={12} sm={4} lg={3}>
                        <TextField
                            fullWidth
                            disabled={!partdataHandler ? true : false}
                            className={clsx(classes.margin, classes.textField)}
                            variant="outlined"
                            label="Breadth(mm)"
                            type="number"
                            InputProps={{ inputProps: { min: 0 } }}
                            value={this.state.newPartData.size.breadth}
                            onChange={this.handleChange('breadth')}
                            onBlur={this.handleBlur()}
                            required={partdataHandler}
                        />
                    </Grid>
                    <Grid item xs={12} sm={4} lg={4}>
                        <TextField
                            fullWidth
                            disabled={!partdataHandler ? true : false}
                            className={clsx(classes.margin, classes.textField)}
                            variant="outlined"
                            label="Height(mm)"
                            type="number"
                            InputProps={{ inputProps: { min: 0 } }}
                            value={this.state.newPartData.size.height}
                            onChange={this.handleChange('height')}
                            onBlur={this.handleBlur()}
                            required={partdataHandler}//added to hide * on part profile view page
                        />
                    </Grid>
                    <Grid item xs={12} sm={6} lg={window.location.pathname.includes('/partedit') || window.location.pathname.includes('/partprofileview') ? 5 : 10}>
                        <TextField
                            className={clsx(classes.margin, classes.textField)}
                            fullWidth
                            disabled={!partdataHandler ? true : false}
                            variant="outlined"
                            label="Notes"
                            value={this.state.newPartData.notes !== "undefined" ? this.state.newPartData.notes : null}
                            onChange={this.handleChange('notes')}
                        />
                    </Grid>
                    {/* printability section */}
                    {printabilitySection}
                    <Grid item xs={12} sm={6} lg={5}>
                        <TextField
                            fullWidth
                            disabled={!partdataHandler ? true : false}
                            select
                            label="Material"
                            className={clsx(classes.margin, classes.textField)}
                            value={this.state.newPartData.material}
                            onChange={this.handleChange('material')}
                            onBlur={this.handleBlur()}
                            SelectProps={{
                                MenuProps: {
                                    className: classes.menu,
                                },
                            }}
                            margin="normal"
                            variant="outlined"
                            required={partdataHandler}
                        >
                            {materials &&
                                (materials.map(option => (
                                    <MenuItem key={option} value={option}>
                                        {option}
                                    </MenuItem>
                                )))}
                        </TextField>
                    </Grid>
                    <Grid item xs={12} sm={6} lg={5}>
                        <TextField
                            fullWidth
                            disabled={!partdataHandler ? true : false}
                            select
                            label="Complexity"
                            className={clsx(classes.margin, classes.textField)}
                            value={this.state.newPartData.complexity}
                            onChange={this.handleChange('complexity')}
                            onBlur={this.handleBlur()}
                            SelectProps={{
                                MenuProps: {
                                    className: classes.menu,
                                },
                            }}
                            margin="normal"
                            variant="outlined"
                        >
                            {this.complexityValueList.map(option => (
                                <MenuItem key={option} value={option}>
                                    {option}
                                </MenuItem>
                            ))}
                        </TextField>
                    </Grid>
                    <Grid item xs={12} sm={6} lg={5}>
                        <TextField
                            fullWidth
                            disabled={!partdataHandler ? true : false}
                            label="Cost Price"
                            className={clsx(classes.margin, classes.textField)}
                            type="number"
                            InputProps={{ inputProps: { min: 0 } }}
                            value={this.state.newPartData.costPrice}
                            onChange={this.handleChange('costPrice')}
                            margin="normal"
                            variant="outlined"
                            required={partdataHandler}
                        />
                    </Grid>
                    <Grid item xs={12} sm={6} lg={5}>
                        <TextField
                            fullWidth
                            disabled={!partdataHandler ? true : false}
                            label="Selling Price"
                            type="number"
                            InputProps={{ inputProps: { min: 0 } }}
                            className={clsx(classes.margin, classes.textField)}
                            value={this.state.newPartData.sellingPrice}
                            onChange={this.handleChange('sellingPrice')}
                            variant="outlined"
                            required={partdataHandler}
                        />
                    </Grid>
                    <br />
                </Grid>
            </React.Fragment>
        )
    }
}




const mapStateToProps = (state) => {
    return {
        materials: state.parts.materials,
        selectedPart: state.parts && state.parts.selectedPart ? state.parts.selectedPart : {},
        organization: state.auth && state.auth.user ? state.auth.user.organization : undefined,
        catsx:state.parts.categories
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        fetchMaterials_action: () => dispatch(fetchMaterials()),
        getCategoriesList_action:(organization) => dispatch(getCategoriesList(organization))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(useStyles)(PartDetails))
