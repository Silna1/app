/* eslint-disable max-len,no-script-url,jsx-a11y/anchor-is-valid */

import React, { Fragment } from "react";

import Button from "@material-ui/core/Button";
import Paper from '@material-ui/core/Paper';
import { connect } from 'react-redux';
import { processInProgress } from '../store/actions/misc_action';
import { Link } from 'react-router-dom';
import { withRouter } from "react-router-dom";
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import PropTypes from 'prop-types';
import CommentGroup from './commnts/CommentGroup'
import { setSelectedClient, deleteClient, fetchClients } from '../store/actions/client_action';
import Carousel from './pd-carousel';
import PartDetails from './pd-part-details';
import Modal from './pd-dialog';

class Clientcard extends React.Component {
    constructor(props) {
        super(props)
        this.clientCardObj = React.createRef();
        this.state = {
            clientsarray: {},
            isViewerVisible: false,
            modalParent: "",
            quantity: "1"
        }
    }

    componentDidMount() {
        if (!this.props.selectedPart.name) {
            this.props.setSelectedPart_action(this.props.matchId);
        }
        this.setState({ partData: { ...this.props.selectedPart } })
    }

    componentWillUnmount() {
        this.setState({ partData: {} })
        //to empty the selected part
        this.props.emptySelectedPart_action();
    }



    handleModalOperations = () => {
        switch (this.state.modalParent) {
            case 'Delete': {
                let deleteAction = async () => await this.props.deletePart_action(this.props.matchId);
                deleteAction()
                    .then(data => {
                        this.props.removePart_action(this.props.matchId, this.props.userData.organization);
                        this.props.history.push("/");
                    })
                this.props.processInProgress_action(true);
                break;
            }
            case 'Print': {
                const printData = new FormData();
                printData.append("fromemail", this.props.userData.email);
                printData.append("username", this.props.userData.fullName);
                printData.append("usertype", this.props.userData.privilege);
                printData.append("partname", this.props.selectedPart.name);
                printData.append("qty", this.state.quantity);
                this.props.sendForPrint_action(printData);
                break;
            }
            default: {
                break;
            }
        }
        this.clientCardObj.current.handleClose();
    }

    modalOpenHandler = (process) => {
        if (process === "Delete") {
            this.setState({ modalParent: "Delete" }, () => {
                this.clientCardObj.current.handleClickOpen();
            })
        } else if (process === "Print") {
            this.setState({ modalParent: "Print", quantity: "1" }, () => {
                this.clientCardObj.current.handleClickOpen();
            })
        }
    }

    buttonStyles = {
        backgroundImage: "linear-gradient(147deg, #313e48 0%, #272f37 74%)",
        boxShadow: "0px 4px 32px rgba(68, 175, 178, 0.4)",
        borderRadius: 100,
        paddingLeft: 24,
        paddingRight: 24,
        color: "#ffffff",
        margin: "10px"
    }

    render() {
        const { privilege, userOrganization } = this.props;
        const partData = this.state.partData.name && !this.props.selectedPart ? { ...this.state.partData } : { ...this.props.selectedPart };
        let cardMedia;
        if (this.state.isViewerVisible && partData.urn !== undefined && partData.urn !== null) {
            cardMedia = <div style={{ minHeight: '600px', height: '60vh', margin: 0, padding: 0, }}><ForgeViewer modelUrn={partData.urn}></ForgeViewer></div>;
        } else {
            cardMedia = <Carousel partImages={partData.signedUrls}></Carousel>;
        }
        if (partData && partData.name)
            this.props.processInProgress_action(false);
        return (
            <Fragment >
                {partData.name &&
                    <Grid container style={{marginTop:"40px"}}>
                        <Grid item xs={12} sm={12} lg={6} style={{}}>
                            <Paper style={{ margin: '15px', position: 'relative' }}>
                                {cardMedia}
                            </Paper>
                        </Grid>
                        <Grid item xs={12} sm={12} lg={6}>
                            <Paper style={{ margin: '15px', padding: '15px', height: 'auto', minHeight: '790px' }}>
                                <PartDetails partData={partData} />
                                {window.location.pathname !== '/' &&
                                    <React.Fragment >
                                        {privilege && privilege.editPart && partData.organization === userOrganization &&
                                            < Button style={this.buttonStyles} component={Link} to={`/${this.props.matchId}/partedit`} onClick={() => (this.props.setSelectedPart_action(this.props.matchId))}>EDIT</Button>
                                        }
                                        {privilege && privilege.deletePart && partData.organization === userOrganization &&
                                            <Button style={this.buttonStyles} id="deletePart" onClick={() => this.modalOpenHandler("Delete")}>Delete</Button>
                                        }
                                        {privilege && privilege.orderPart &&
                                            <Button style={this.buttonStyles} id="printPart" variant="contained" onClick={() => this.modalOpenHandler("Print")}>PRINT NOW</Button>
                                        }
                                       
                                        <Modal title={`${this.state.modalParent} Part`} obj={this.handleModalOperations} ref={this.clientCardObj}>
                                            {this.state.modalParent === "Delete" &&
                                                <h3>Are you sure you want to permanently remove this part ?</h3>
                                            }
                                            {this.state.modalParent === "Print" &&
                                                <React.Fragment>
                                                    <h3>Please select Quantity for printing order</h3>
                                                    <TextField fullWidth select label="Quantity" value={this.state.quantity} onChange={(event) => (this.setState({ quantity: event.target.value }))} style={{ padding: "5px" }} >
                                                        {["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"].map(option => (
                                                            <MenuItem key={option} value={option}>
                                                                {option}
                                                            </MenuItem>
                                                        ))}
                                                    </TextField>
                                                </React.Fragment>
                                            }
                                        </Modal>
                                    </React.Fragment>
                                }
                            </Paper>

                            
                        </Grid>
                        <Grid item xs={12} sm={12} lg={12}>
<Paper style={{ margin: '15px', padding: '15px', height: 'auto', minHeight: '600px' }}>
                                   <CommentGroup PID={this.props.matchId} CID={this.props.userData}/>
                            </Paper>

                        </Grid>
                    </Grid>
                }
            </Fragment>
        );
    }
}

Clientcard.propTypes = {
    selectedPart: PropTypes.object,
    userData: PropTypes.object,
    matchId: PropTypes.any,
    history: PropTypes.any,
    privilege: PropTypes.object,
    sendForPrint_action: PropTypes.func,
    setSelectedPart_action: PropTypes.func,
    deletePart_action: PropTypes.func,
    removePart_action: PropTypes.func,
    processInProgress_action: PropTypes.func,
    emptySelectedPart_action: PropTypes.func,
    getPartsData_action: PropTypes.func
}

const mapStateToProps = (state) => {
    return {
        selectedPart: state.parts && state.parts.selectedPart ? state.parts.selectedPart : {},
        userData: state.auth.user,
        privilege: state.auth.user ? state.auth.user.access : undefined,
        userOrganization: state.auth && state.auth.user ? state.auth.user.organization : undefined
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        setSelectedPart_action: (id) => dispatch(setSelectedPart(id)),
        emptySelectedPart_action: () => { dispatch(emptySelectedPart({})) },
        deletePart_action: (id) => { dispatch(deletePart(id)) },
        removePart_action: (id, organization) => { dispatch(removePartFromList(id, organization)) },
        processInProgress_action: (status) => dispatch(processInProgress(status)),
        sendForPrint_action: (printData) => dispatch(sendForPrint(printData)),
        getPartsData_action: (organization) => dispatch(getPartsData({ 'lastEvaluatedKey': null, 'organization': organization })),
    }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Clientcard));
