import {
    Button,
    Icon,
    Grid,
    Radio,
    RadioGroup,
    ValidatorFormControlLabel,
    Checkbox,
    Box,
    Card,
    Paper,
    Fab,
    Avatar,
    CardContent,
    CardHeader,
  Divider,
  Container,
  CardActions
} from '@mui/material';
import React, { useRef, useState, useEffect } from "react";
import {useHistory } from 'react-router-dom';
import InputLabel from '@mui/material/InputLabel';
import { styled } from '@mui/system'
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { makeStyles, createStyles } from '@material-ui/core/styles';
import AddIcon from '@mui/icons-material/Add';
import DragImage from '../assets/drag.png'
import {
    addClient,
    getSector,
    fetchClients,
    viewClient,
    updateClient,
    deleteClient
  } from "../store/actions/client_action";
  import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { processInProgress } from '../store/actions/misc_action';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import DeleteIcon from '@mui/icons-material/Delete';
import BackspaceIcon from '@mui/icons-material/Backspace';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import {config} from '../config';
import countries from './utils/countries.json';
import CheckIcon from '@mui/icons-material/Check';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import get from 'lodash/get'
import AWS from 'aws-sdk'

const TextInput = styled(TextField)(() => ({
    width: '100%',
    marginBottom: '16px',
}))

const CustomSelect = styled(Select)(() => ({
    width: '100%',
    marginBottom: '16px',
}))

const defaultError = {
    clientName: '',
    email: '',
    phoneNumber: '',
    clientLogo: '',
    clientType:'',
    sector:'',
    address1:'',
    city:'',
    state:'',
    country: '',
    pinCode:''
}

const AWSconfig = {
    bucketName: 'client-logo-dev',
    region: 'ap-south-1',
    accessKeyId: 'AKIARCFG6GEK3DUE3FH5',
    secretAccessKey: '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',
}

AWS.config.update({
    accessKeyId: AWSconfig.accessKeyId,
    secretAccessKey: AWSconfig.secretAccessKey
})

const myBucket = new AWS.S3({
    params: { Bucket: AWSconfig.bucketName},
    region: AWSconfig.region,
})

const fieldRequiredText = 'This field is required';

const useStyles = makeStyles(()=>
    createStyles({
        logo: {
            marginTop:'20px',
            '& img': {
                width: '300px',
                border: 'inset',
                height: '300px'
            }
        }
    })
)



const ClientAdd = (props) => {
    const userEmail = props.email;
    const {getSectorList_action, addClient_action, sector,viewClient_action,updateClient_action,deleteClient_action} = props;
    const defaultClient = {
        clientName: '',
        clientLogo: "",
        phoneNumber: '',
        active: true,
        createDate: new Date().toISOString(),
        email: '',
        lastUpdate: new Date().toISOString(),
        clientType:'',
        sector:{},
        address1:'',
        address2:'',
        city:'',
        state:'',
        country: [],
        pinCode:'',
        createdbyUser:userEmail,
        updatedbyUser:userEmail
    };
    const history = useHistory();
    const classes = useStyles();
    const [errors, setErrors] = useState({...defaultError});
    const [logoImage, setLogoImage] = useState('');
    const [client, setClient] = useState({...defaultClient})
    const [isEdit, setIsEdit] = useState(false);
    const [isEditPage,setIsEditPage] = useState(false);
    const [isModalOpen,setIsModalOpen] = useState(false);
    const fileInputRef = useRef(null);
    const logoImageRef = useRef(null);
    const clientRef = useRef(null);

    const clientTypeList = config.ClientType;
    const countryList = countries;

    useEffect(() => {
        getSectorList_action();
    }, [])

    useEffect(() => {
        const pathData = history.location.pathname.split('/');
        if(pathData[2] === 'edit') {
            setIsEditPage(true);
            viewClient_action(pathData[3])
            .then(res => {
                setClient({...res})
                clientRef.current = {...res}
                if(res.clientLogo)
                {
                    setLogoImage(res.clientLogo);
                }
            })
            .catch(err => {
                console.log(err);
            })
        }
    }, [])

    const handleDelete = () => {

        deleteClient_action(client);
        history.goBack();
    }


    const handleClick = (event) => {
        event.preventDefault();
        fileInputRef.current.click();
    }

    const handleDrop = (e)=>{
        const files = get(e,'dataTransfer.files');
        e.stopPropagation();
        e.preventDefault();
        handleFileData(files);
    }

    const handleDragIn = (e) => {
        e.stopPropagation();
        e.preventDefault();
    }

    const handleFileData = (files) => {
        if(files.length) {
            const fileData = files[0];
            const { isValidFile, errVal } = fileValidator(files);
            if(!isValidFile) {
                if(errVal) {
                    //Handle error message from errVal
                }
                return false
            }
            console.log(fileData);
            logoImageRef.current= fileData;
            setClient({...client, clientLogo: "File Uploaded"});
            setLogoImage(URL.createObjectURL(fileData));
        }
    }

    const handleFile = (e) => {
        const files = e.target.files;
        handleFileData(files);
    }

    const uploadImage = (file,cb) => {
        if(file)
        {
        const timeStamp = new Date().getTime()
        const type = file.type.split('/')[1];
        const params = {
            ACL: 'public-read',
            Body: file,
            Bucket: AWSconfig.bucketName,
            Key: `client-logo-${timeStamp}.${type}`
        };

        myBucket.upload(params)
            .on('httpUploadProgress', (evt) => {
                // handle image upload progress (Percentage = Math.round((evt.loaded / evt.total) * 100))
            })
            .send((err, data) => {
                if (err){
                    console.log(err, err.stack);
                    return;
                }
                const fileUrl = data.Location;
                const fdata = {...client, clientLogo:fileUrl }
                setClient(fdata);
                cb(fdata);
            })
        }
        else{
            cb(client);
        }
    }

    const fileValidator = (files) => {
        const allowedFileFormats = ['image/png', 'image/jpg', 'image/jpeg'];
        const fileSizeMBLimit = 2;
        const fileLimit = 1;
        const { length } = files;
        const { size, type } = files[0];
        let err = false;
        const result = {
            isValidFile: false,
            errVal: err
        };
        if(length === 0) {
            return result;
        } else if(length > fileLimit) {
            err = "Only 1 file is allowed";
        } else if(!allowedFileFormats.includes(type)) {
            err = "Invalid file type";
        } else if(size/1024/1024 > fileSizeMBLimit) {
            err = "File size limit exceeded";
        } else {
            result.isValidFile = true;
        }
        result.errVal = err;
        return result;
    }

    const validateData = (data) => {
        console.log("validate data client",data);
        const errorProxy = {...errors};
        let valid = true;
        Object.keys(defaultError).forEach(itemKey => {
            errorProxy[itemKey] = !data[itemKey] ? fieldRequiredText : '';
        })
        errorProxy.clientName = !data.clientName ? fieldRequiredText : validateName(data.clientName) ? '' : 'Name should be minimum 4 -10 characters';
        errorProxy.email = !data.email ? fieldRequiredText : validateEmail(data.email) ? '' : 'Email id is not valid';
        setErrors(errorProxy);
        Object.values(errorProxy).forEach(item => {
            if(item && valid) {
                valid = false
            }
        })
        return valid;
    }
    const validateEmail = (email) => {
        var re = /\S+@\S+\.\S+/;
        console.log("just checking email",re.test(email));
        return re.test(email);
    }

    const validateName = (clientName) =>
    {
        if(clientName.length< 4 || clientName.length > 15)
            return false;
        else
            return true;
    }

    const handleClear = (event) => {
        event.preventDefault();
        setClient({...defaultClient});
    }

    const handleBack = () => {
        history.goBack();
    }

    const handleCancel = (event) => {
        event.preventDefault();
        history.goBack();
    }

    const  handleEdit = () => {
        setIsEdit(!isEdit);
        if(isEdit) {
            setClient({...clientRef.current});
            setErrors({...defaultError})
        }
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        if (validateData(client)) {
            uploadImage(logoImageRef.current,(data)=>{
                if(isEditPage)
                {
                    const payload =  {...data,lastUpdate:new Date().toISOString(),updatedbyUser:userEmail}
                    updateClient_action(payload).then(()=>{
                        history.goBack();
                    })
                    .catch((error) =>{
                        if(error && error.statusCode === 409)
                    {
                       if(error.statuskey === "Eexist")
                       {
                           setErrors({...errors, email: "Email Id already exist" });
                       }
                       else if(error.statuskey === "PNexist")
                       {
                        setErrors({...errors, phoneNumber: "Phone Number already exist" });
                        }
                    }
                    })

                }
                else{
                    addClient_action(data).then(()=>{
                    history.goBack();
                    setClient({...defaultClient});
                })
                .catch((error) =>{
                    if(error && error.statusCode === 409)
                    {
                       if(error.statuskey === "Eexist")
                       {
                           setErrors({...errors, email: "Email Id already exist" });
                       }
                       else if(error.statuskey === "PNexist")
                       {
                        setErrors({...errors, phoneNumber: "Phone Number already exist" });
                        }
                    }
                })
            }
            });
        }
    }

    const handleChange = (key) => (event) => {
        if(key === 'sector')
        {
            const sectorData = sector.find(item => item.sectorId === event.target.value);
            setClient({...client, [key]:{id:sectorData.sectorId,name:sectorData.name}}) 
        }
        else
        {
            setClient({...client, [key]: event.target.value});
        }
       
    }

    return (
        <div>
            <Box
                sx={{
                    alignItems: 'center',
                    display: 'flex',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    m: -1,
                    marginTop:'50px'
                }}
            >
                <Typography
                    sx={{ m: 1,color:'#19b4dd',fontWeight: 600 }}
                    variant="h4"
                >
                 {!isEditPage? 'Add New Client' : `${isEdit? " Edit" : ""} ${client.clientName}`} 
                </Typography>
                <Button onClick={handleBack} style={{color:"#19b4dd",mr: 1}} variant="outlined" startIcon={<ArrowBackIcon />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Go Back
                    </Typography>
                </Button>
            </Box>
            <Divider/>
            <Box
                sx={{
                    display: 'flex',
                    '& > :not(style)': {
                        m: 1, 
                    },
                    marginTop:'20px'
                }}
            >
            <Box
                component="main"
                sx={{
                    flexGrow: 1,
                    py: 8,
                    m: 1,color:'#19b4dd',fontWeight: 600
                }}
            >
                <Container maxWidth="lg">     
                    <Grid
                        container
                        spacing={3}
                    >
                        <Grid
                            item
                            lg={4}
                            md={6}
                            xs={12}
                        >   
                          {isEditPage && !isEdit ?
                                    <div className={classes.logo} >
                                    <img src={client.clientLogo} alt="logo" />
                                    </div> :   
                            <Card >
                                
                                <CardContent>
                                  
                                    <Box
                                        sx={{
                                        alignItems: 'center',
                                        display: 'flex',
                                        flexDirection: 'column'
                                        }}
                                    >
                                        <div onDrop= {handleDrop} onDragEnter= {handleDragIn} onDragOver= {handleDragIn} onDragLeave={handleDragIn}>
                                            {logoImage ? 
                                                <img style={{maxHeight: 64, maxWidth: 200, minWidth: 64}} src={logoImage} alt="logo" />
                                                :
                                                <>
                                                    <img style={{maxHeight: 64, maxWidth: 200, minWidth: 64}} src={DragImage} alt="logo" />
                                                    <p>Drag the Image/Upload the Image</p>
                                                    {errors.clientLogo && <p style={{color:'red'}} >Please Insert Logo</p>}
                                                </>
                                            }
                                        </div>
                                        <Typography
                                            color="textPrimary"
                                            gutterBottom
                                            variant="h5"
                                        >
                                            {client.clientName}
                                        </Typography>
                                        <Typography
                                        color="textSecondary"
                                        variant="body2"
                                        >
                                        
                                        </Typography>
                                        <Typography
                                        color="textSecondary"
                                        variant="body2"
                                        >
                                            {client.email}
                                        </Typography>
                                    </Box>

                                </CardContent>
                                <Divider />
                                <CardActions>
                                <label htmlFor="upload-photo">
                                    <input
                                        style={{ display: "none" }}
                                        id="upload-photo"
                                        name="upload-photo"
                                        type="file"
                                        ref={fileInputRef}
                                        onChange={handleFile}
                                        error={!!errors.clientLogo}
                                        helperText={errors.clientLogo}
                                    />
                                    <Button
                                        onClick={handleClick}
                                        sx={{color:'#19b4dd',fontWeight: 600,display:'flex',justifyContent:'center',marginLeft:'40px'}}
                                        fullWidth
                                        variant="text"
                                        startIcon={<AddCircleIcon  />}
                                    >
                                        Upload Logo
                                    </Button>
                                </label>
                            </CardActions>
                        </Card>
                    }
                    </Grid>
                    <Grid
                        item
                        lg={8}
                        md={6}
                        xs={12}
                    >
                        <Card>
                            <CardHeader
                                subheader="Add client information"
                                title="Profile"
                            />
        <Divider />
        <CardContent>
          <Grid
            container
            spacing={3}
          >
                        <Grid
                        item
                        md={6}
                        xs={12}
                        >
                        <TextInput
                            type="text"
                            name="clientName"
                            disabled = {isEditPage && !isEdit}
                            onChange={handleChange('clientName')}
                            value={client.clientName}
                            label="ClientName (Min length 4, Max length 15)"
                            error={!!errors.clientName}
                            helperText={errors.clientName}
                        />
                        </Grid>
                        <Grid
                        item
                        md={6}
                        xs={12}
                        >
                        <TextInput
                            label="Address 1"
                            onChange={handleChange('address1')}
                            disabled = {isEditPage && !isEdit}
                            type="text"
                            name="address1"
                            error={!!errors.address1}
                            helperText={errors.address1}
                            value={client.address1}
                        />
                        </Grid>
                        <Grid
                        item
                        md={6}
                        xs={12}
                        >
                        <TextInput
                            label="Address 2"
                            onChange={handleChange('address2')}
                            disabled = {isEditPage && !isEdit}
                            type="text"
                            name="address2"
                            error={!!errors.address2}
                            helperText={errors.address2}
                            value={client.address2}
                        />
                        </Grid>
                        <Grid
                        item
                        md={6}
                        xs={12}
                        >
                        <TextInput
                            label="City"
                            onChange={handleChange('city')}
                            type="text"
                            name="city"
                            disabled = {isEditPage && !isEdit}
                            error={!!errors.city}
                            helperText={errors.city}
                            value={client.city}
                        />
                        </Grid>
                        <Grid
                        item
                        md={6}
                        xs={12}
                        >
                        <TextInput
                            label="State/Province"
                            onChange={handleChange('state')}
                            type="text"
                            disabled = {isEditPage && !isEdit}
                            name="state"
                            error={!!errors.state}
                            helperText={errors.state}
                            value={client.state}
                        />
                        </Grid>
                        <Grid
                        item
                        md={6}
                        xs={12}
                        >
                        <TextInput
                            label="Pin Code"
                            onChange={handleChange('pinCode')}
                            type="number"
                            disabled = {isEditPage && !isEdit}
                            name="pinCode"
                            error={!!errors.pinCode}
                            helperText={errors.pinCode}
                            value={client.pinCode}
                        />
                        </Grid>
                        <Grid
                        item
                        md={6}
                        xs={12}
                        >
                        <TextInput
                            label="Email"
                            onChange={handleChange('email')}
                            type="email"
                            name="email"
                            disabled = {isEditPage && !isEdit}
                            error={!!errors.email}
                            helperText={errors.email}
                            value={client.email}
                        />
                        </Grid>
                            <Grid
                            item
                            md={6}
                            xs={12}
                            >
                        <TextInput
                            label="Mobile Nubmer"
                            onChange={handleChange('phoneNumber')}
                            type="number"
                            name="phoneNumber"
                            disabled = {isEditPage && !isEdit}
                            error={!!errors.phoneNumber}
                            helperText={errors.phoneNumber}
                            value={client.phoneNumber}
                        />
                        </Grid>
                        <Grid
                        item
                        md={6}
                        xs={12}
                        >
                        <InputLabel id="demo-simple-select-label">Client Type</InputLabel>
                        <CustomSelect
                            value={client.clientType}
                            label="Client Type"
                            name='clientType'
                            disabled = {isEditPage && !isEdit}
                            id="demo-simple-select"
                            onChange={handleChange('clientType')}
                        >
                            {clientTypeList.map(item => 
                                <MenuItem value={item}>{item}</MenuItem>
                            )}
                        </CustomSelect>
                        </Grid>
                        <Grid
                        item
                        md={6}
                        xs={12}
                        >
                        <InputLabel id="demo-simple-select-label">Sector</InputLabel>
                        <CustomSelect
                            value={client.sector?.id || ''}
                            name='sector'
                            variant='outlined'
                            disabled = {isEditPage && !isEdit}
                            id="demo-simple-select"
                            onChange={handleChange('sector')}
                        >
                            {sector?.map(item => {
                                return (
                                    <MenuItem key={item.sectorId} value={item.sectorId}>{item.name}</MenuItem>
                                )
                            })}
                        </CustomSelect>
                        </Grid>
                        <Grid
                        item
                        md={6}
                        xs={12}
                        >
                        <InputLabel id="demo-simple-select-label">Country</InputLabel>
                        <CustomSelect
                            value={client.country}
                            label="Country"
                            disabled = {isEditPage && !isEdit}
                            multiple
                            onChange={handleChange('country')}
                        >
                            {countryList.map(item => 
                                <MenuItem value={item.code}>{item.name}</MenuItem>
                            )}
                        </CustomSelect>
                        </Grid>
                            
            </Grid>
            </CardContent>
            <Divider />
                        <Box
                        sx={{
                            display: 'flex',
                            justifyContent: 'flex-end',
                            p: 2
                        }}
                         >
                        {!isEditPage ?
                        <>
                        <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" type="submit" onClick={handleSubmit} startIcon={<AddCircleIcon  />}>
                        
                            <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                                Add
                            </Typography>
                        </Button>
                        <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" type="submit" onClick={handleClear} startIcon={<BackspaceIcon  />}>
                        
                            <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                                Clear
                            </Typography>
                            
                        </Button>
                        <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" type="submit" onClick={handleCancel} startIcon={<CancelIcon  />}>
                        
                            <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                                Cancel
                            </Typography>
                            
                        </Button>
                        </> :
                        <>
                        <Button onClick={handleEdit} style={{color:"#19b4dd",mr: 1}}  variant="outlined" startIcon={!isEdit ? <EditIcon /> : <CancelIcon/>}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        {!isEdit ? "Edit" : "Cancel"}
                    </Typography>
                </Button>
                {isEdit &&
                    <Button onClick={handleSubmit} style={{color:"#19b4dd",mr: 1}}  variant="outlined" startIcon={<SaveIcon />}>
                        <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                            Save
                        </Typography>
                    </Button>
                }
                
                <Button onClick={() => setIsModalOpen(true)} style={{color:"#19b4dd",mr: 1}} variant="outlined" startIcon={<DeleteIcon />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Delete
                    </Typography>
                </Button>
                        </>
                }
                        </Box>
                                </Card>
                            </Grid>
                        </Grid>
                    </Container>
                </Box>
            </Box>
            <Dialog onClose={() => setIsModalOpen(false)} open={isModalOpen}>
              <DialogTitle>Alert</DialogTitle>
              <DialogContent style={{paddingTop: '20px'}}>
                Are you sure ,you want to delete the client?
              </DialogContent>
              <DialogActions>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={handleDelete} startIcon={<CheckIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Confirm
                    </Typography>
                </Button>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={() => setIsModalOpen(false)} startIcon={<CancelIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Cancel
                    </Typography>
                </Button>
              </DialogActions>
            </Dialog>
        </div>
    )
}

ClientAdd.propTypes = {
    selectedClient: PropTypes.string,
    clientsarray: PropTypes.array,
    fetchClients_action: PropTypes.func,
    addClient_action:PropTypes.func,
    getSectorList_action:PropTypes.func,
    processInProgress_action: PropTypes.func,
    email: PropTypes.string,
    viewClient_action: PropTypes.func,
    deleteClient_action: PropTypes.func,
    updateClient_action: PropTypes.func

    
}

const mapStateToProps = (state) => {
    console.log("state of clients",state);
    return {
        privilege: state.auth && state.auth.user ? state.auth.user.access : undefined,
        clientsarray: state.client.value,
        sector: state.client.sector,
        country:state.client.country,
        clientType:state.client.clientType,
        email: state.auth.user ? state.auth.user.email : undefined
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        addClient_action:(clientsarray)=>dispatch(addClient(clientsarray)),
        getSectorList_action:()=>dispatch(getSector()),
        fetchClients_action:()=>dispatch(fetchClients()),
        viewClient_action: (id) => dispatch(viewClient(id)),
        deleteClient_action: (client) => dispatch(deleteClient(client)),
        updateClient_action: (client) => dispatch(updateClient(client)),
        processInProgress_action: (status) => dispatch(processInProgress(status))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ClientAdd);

