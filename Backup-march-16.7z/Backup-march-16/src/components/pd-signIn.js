import React from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import Container from '@material-ui/core/Container';
import Grid from '@material-ui/core/Grid';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import { useStyles } from '../Styles/signIn_styles'
import { AppBar, CssBaseline, Typography, Toolbar } from '@material-ui/core'
import { connect } from 'react-redux'
import { signIn } from '../store/actions/auth_action'

function SignIn({ login_action }) {
    const classes = useStyles();

    return (
        <div className={classes.root}>
            <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,400;0,500;0,600;1,400;1,500;1,600&display=swap" rel="stylesheet"/>
            <Container component="main" maxWidth="xs">
                <CssBaseline />
                <AppBar className={classes.appBar}
                    position="fixed"
                >
                    <Toolbar>
                        <Grid container spacing={3}>
                            <Grid item xs={12} sm={12} style={{ textAlign: "center", }}>
                                <Typography variant="h4" style={{ display: 'inline-block', fontFamily: "'Montserrat', sans-serif" }}>
                                    PARTS
                                </Typography>
                                <Typography variant="h4" style={{ display: 'inline-block', color: 'yellow', fontFamily: "'Montserrat', sans-serif", paddingLeft: "1%" }}>
                                    DIGITIZER
                                </Typography>
                            </Grid>
                        </Grid>
                    </Toolbar>
                </AppBar>
                <div className={classes.paper}>
                    <Avatar className={classes.avatar}>
                        <LockOutlinedIcon />
                    </Avatar>
                    <Typography component="h2" variant="h5">
                        Sign in
                </Typography>
                    <div>
                        You're not authenticated
                </div>
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        color="primary"
                        className={classes.submit}
                        onClick={login_action}
                    >
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Google_%22G%22_Logo.svg/512px-Google_%22G%22_Logo.svg.png" width="25px" className="img-responsive" alt="" />
                        Sign In With Google
            </Button>
                </div>
            </Container>
        </div>
    );
}

const mapDispatchToProps = (dispatch) => {
    return {
        login_action: () => dispatch(signIn()),
    }
}

export default connect(null, mapDispatchToProps)(SignIn);