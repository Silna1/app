import React from 'react';
import { connect } from 'react-redux'

import Button from "@material-ui/core/Button";
import { ListItem, ListItemText } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles'
import List from '@material-ui/core/List';
import ListSubheader from '@material-ui/core/ListSubheader';
import Grid from '@material-ui/core/Grid'

import Modal from './pd-dialog'
import { config } from '../config'
import { FetchAPI } from '../fetch'

import { deletePart, duplicates } from '../store/actions/part_action'
import { getLastModelInfo } from '../store/actions/automl_action'
import { notification } from '../store/actions/misc_action'
import { useStyles } from '../Styles/training_styles'
import store from '../store/store';

class Training extends React.PureComponent {

    constructor(props) {
        super(props);
        this.trainingRef = React.createRef();
        this.state = {
            actionInfo: null,
            status: [],
            dialogStatement: "",
            lastMessage: '',
            duplicates: [],
            buttonClicked: "",
            duplicatePartNames: []
        }
    }

    componentDidMount() {
        if (this.props.duplicatesFound && this.props.duplicatesFound.length > 0) {
            this.setState({ actionInfo: "Multiple duplicates found. Please choose appropriate action to continue." })
        }
        this.props.getLastModelInfo_action();
    }

    _transfertimer = null;
    _trainingtimer = null;

    sendForTransfer = async () => {
        try {
            this.setState({ actionInfo: "Transferring and Training can take some time. Please check back in few minutes for any duplicates found. \n Otherwise relax, the model training will take some time." });

            // dispatch notistack
            let newStatus = [...this.state.status];
            newStatus.unshift("Initializing transfer process");
            this.setState({ status: [...newStatus] });

            const url = config.HostAutomlURL + "/transfer/transferBucket";

            //checking status after every 2 second
            this._transfertimer = setInterval(() => {
                this.getAutomlProcessStatus();
            }, 5000)

            let Result = await FetchAPI.postData(url);
            if (Result) {
                console.log(Result);
            }
        } catch (err) {
            clearInterval(this._transfertimer);
            console.log(err);
        }
    }

    sentForTraining = () => {
        try {
            //this.sendUserDetailsToAutoMLServer();

            const url = config.HostAutomlURL + "/train/processTrainingModule";

            this._trainingtimer = setInterval(() => {
                this.getAutomlProcessStatus();
            }, 5000)

            FetchAPI.postData(url)
                .then(response => {
                    console.log("Response", response);
                }).catch(ex => {
                    console.log(ex);
                    clearInterval(this._trainingtimer);
                })
        } catch (err) {
            console.log(err);
            clearInterval(this._trainingtimer);
        }
    }

    modifyDuplicate() {
        console.log(this.state.duplicates);

        let imagesToModify = [];

        this.state.duplicates.forEach(ele => {
            imagesToModify.push({ "partId": ele.partId1, "imageId": ele.imageId1, "path": ele.path1 });
        })

        const data = {
            path: imagesToModify
        }

        let duplicatePartURL = config.HostURL + "/part/modifyDuplicateImages";

        FetchAPI.postData(duplicatePartURL, data)
            .then(Result => {
                this.props.notification_action({
                    'variant': 'success',
                    'message': "Images modified successfully",
                    'autoHideDuration': 3000
                })
            }).catch(err => {
                console.log(err.message);
                this.props.notification_action({
                    'variant': 'error',
                    'message': "Error in Images modification",
                    'autoHideDuration': 3000
                })
            })

        this.props.duplicates_action([]);
        this.setState({ actionInfo: "Click Transfer & Train Button again to Train new model with unique data." });
    }

    deleteDuplicate() {
        if (this.state.duplicates) {
            let duplicateparts = [];
            this.state.duplicates.forEach(ele => {
                if (duplicateparts.indexOf(ele.partId1) === -1) {
                    duplicateparts.push(ele.partId1);
                }
            })
            console.log("parts consolidated for deleting", duplicateparts);
            duplicateparts.forEach(ele => this.props.deletePart_action(ele));

            this.setState({ actionInfo: "Click Transfer & Train Button again to Train new model with unique data." });
            this.props.duplicates_action([]);
        }
        else {
            alert("Deleting duplicates Issue", this._duplicates);
        }
    }

    async getDuplicatePartNames() {
        if (this.state.duplicates) {
            //enlisting duplicate part ids
            let duplicatePartIds = [];
            this.state.duplicates.forEach(ele => {
                if (duplicatePartIds.indexOf(ele.partId1) === -1) {
                    duplicatePartIds.push(ele.partId1);
                }
                if (duplicatePartIds.indexOf(ele.partId2) === -1) {
                    duplicatePartIds.push(ele.partId2);
                }
            })

            //get part name by calling getpartbyid
            let partNames = [];
            const partURL = config.HostURL + '/part/getpartbyid';
            for (let i = 0; i < duplicatePartIds.length; i++) {
                const id = {
                    'id': duplicatePartIds[i]
                }
                await FetchAPI.postData(partURL, id)
                    .then((response) => {
                        if (response && response.Items) {
                            partNames.push({ "name": response.Items[0].name, "id": response.Items[0].id });
                        }
                    })
                    .catch((err) => {
                        console.log(err);
                    })
            }

            //set duplicate part names in react state
            this.setState({
                duplicatePartNames: partNames
            });
        }
    }

    //sends user details to AutoML server, these details will be used to send email after training completion
    sendUserDetailsToAutoMLServer() {
        const emailId = store.getState().auth.user.email;
        if (emailId !== "") {
            let url = config.HostAutomlURL + "/automl/saveUserDetails";
            const userdata = {
                'usermailid': emailId,
                'sourcemailid': "developer@immensalabs.com"
            }
            FetchAPI.postData(url, userdata)
                .then(result => {
                    console.log(result);
                }).catch(err => {
                    console.log(err);
                })
        }
    }

    getAutomlProcessStatus = async () => {
        try {
            const url = config.HostAutomlURL + "/automl/getStatus";
            let Result = await FetchAPI.postData(url);

            if (Result.log.message !== this.state.lastMessage) {

                this.setState({ lastMessage: Result.log.message });

                if (Result.log.status === "success") {
                    console.log("success", Result.log.message);
                    this.props.notification_action({
                        'variant': 'success',
                        'message': Result.log.message,
                        'autoHideDuration': 3000
                    })
                } else if (Result.log.status === "error") {
                    console.log("error", Result.log.message);
                    this.props.notification_action({
                        'variant': 'error',
                        'message': Result.log.message,
                        'autoHideDuration': 3000
                    })
                }

            }
            console.log("******************status recieved******************");

            //check for transfer process
            if (Result.process === "Transfer" && Result.isProcessComplete === true) {
                clearInterval(this._transfertimer);
                this.sentForTraining();
            }

            //check for training process
            if (Result.process === "Training" && Result.isProcessComplete === true) {
                clearInterval(this._trainingtimer);
            }

            //check for duplicates
            if (Result.process === "Duplicates" && Result.isProcessComplete === true) {
                clearInterval(this._trainingtimer);
                this.props.notification_action({
                    'variant': 'error',
                    'message': Result.log.message,
                    'autoHideDuration': 3000
                })
                this.setState({ actionInfo: "Multiple duplicates found. Please choose appropriate action to continue." })
                this.setState({ duplicates: Result.duplicateImages });
                this.props.duplicates_action(Result.duplicateImages);

            }
        } catch (err) {
            clearInterval(this._timer);
            console.log(err);
        }
    }

    modalfunctionsHandler = () => {
        if (this.state.buttonClicked === "training") {
            this.sendForTransfer();
        } else if (this.state.buttonClicked === "delete") {
            this.deleteDuplicate();
        } else if (this.state.buttonClicked === "modify") {
            this.modifyDuplicate();
        }

        this.trainingRef.current.handleClose();
    }

    modelOpenHandler = (buttonState) => {
        this.setState({ buttonClicked: buttonState })
        if (buttonState === "training") {
            this.setState({ dialogStatement: "Are you sure you want to proceed with Training ?" })
        }
        if (buttonState === "delete") {
            this.setState({ dialogStatement: "Are you sure you want to delete duplicate parts ?" })
        }
        if (buttonState === "modify") {
            this.setState({ dialogStatement: "Are you sure you want to modify duplicate images ?" })
        }
        if (this.trainingRef.current)
            this.trainingRef.current.handleClickOpen();
    }

    render() {
        const { classes } = this.props;
        return (
            <React.Fragment>
                {(!this.props.duplicatesFound || this.props.duplicatesFound.length === 0) &&
                    <React.Fragment>
                        <h3>Note: Last successful model was trained on {this.props.lastTrainingInfo}</h3>
                        <Button variant="outlined" color="primary" onClick={() => { this.modelOpenHandler("training") }}>Transfer {'&'} Train</Button>
                    </React.Fragment>
                }
                {this.props.duplicatesFound && this.props.duplicatesFound.length > 0 &&
                    <Grid container>
                        <Grid item xs={12}>
                            <Button variant="outlined" color="primary" onClick={() => { this.modelOpenHandler("delete") }} className={classes.lr_margin}>Delete parts with duplicate Images</Button>
                            <Button variant="outlined" color="primary" onClick={() => { this.modelOpenHandler("modify") }} className={classes.lr_margin}>Modify Duplicate Images</Button>
                            <Button variant="outlined" color="primary" onClick={() => { this.getDuplicatePartNames() }} className={classes.lr_margin}>Show Duplicate Images</Button>
                        </Grid>
                        <Grid item xs={12} className={classes.t_margin}>
                            {/* adds list component to show duplicate part names */}
                            {this.state.duplicatePartNames.length > 0 ?
                                <List className={classes.list}>
                                    <ListSubheader>{`Duplicate parts`}</ListSubheader>
                                    {this.state.duplicatePartNames.map((partName, index) => (
                                        <ListItem key={index} className={classes.listItem}>
                                            <ListItemText primary={partName.name}></ListItemText>
                                        </ListItem>
                                    ))}
                                </List>
                                : null}
                        </Grid>
                    </Grid>
                }

                <h3>{this.state.actionInfo}</h3>
                <Modal title="User Profile Delete" obj={this.modalfunctionsHandler} ref={this.trainingRef}>
                    <h3>{this.state.dialogStatement}</h3>
                </Modal>
            </React.Fragment>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        duplicatesFound: state.parts.duplicateParts,
        lastTrainingInfo: state.automl.lastTrainingInfo
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        notification_action: (status) => dispatch(notification(status)),
        deletePart_action: (id) => dispatch(deletePart(id)),
        duplicates_action: (data) => dispatch(duplicates(data)),
        getLastModelInfo_action: () => dispatch(getLastModelInfo())
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(useStyles)(Training));