import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import { connect } from 'react-redux'
import ClientLocLayoutList from "./pd-client-location"
import PropTypes from 'prop-types';
import Box from '@material-ui/core/Box';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import {
    Button,
    Card,
    CardContent,
    TextField,
    InputAdornment,
    SvgIcon, Typography
  } from '@mui/material';
  import { Search as SearchIcon } from './icons/search';
  import AddBoxIcon from '@mui/icons-material/AddBox';
  import AddCircleIcon from '@mui/icons-material/AddCircle';
  import ListAltIcon from '@mui/icons-material/ListAlt';
import {
    fetchClients,
  } from "../store/actions/client_action";
  import 
  {
    fetchLocation
  }
  from "../store/actions/location_action";
import { signIn } from '../store/actions/authentication_action';
import { processInProgress } from '../store/actions/misc_action';
import { addLocation } from '../store/actions/location_action';
import { Link } from 'react-router-dom';
import _,{debounce} from "lodash"

console.log("hello inside pd-location")

class Location extends Component {
    

    constructor(props) {
        super(props);
        this.state = {
            name:"Grid",
            isValidated: false,
            isValuesNegative: false,
            isModalOpen: false,
            locNameError: '',
        };
        this.props.signIn_action();
        this.emptylocationObj = { ...this.location };
        this.debounceSearch = debounce(function (value) {
          this.props.fetchLocation_action(`?searchname=${value}`);
          }, 1000);
    }

    location = {
      locationName: '',
      officeName: '',
      address1: '',
      address2:'',
      city:'',
      state:'',
      country:'',
      pinCode:'',
      isDelete:false
    }
   

    componentDidMount() {
        this.props.processInProgress_action(true);
        this.props.fetchClients_action();
            
    }

    clientsStyle = {
        root: {
            flexGrow: 1,
            backgroundImage: '',
            overflowX: "hidden",
            overflowY: 'hidden',
            height: '100%',
            minHeight: '-webkit-fill-available'
        },
        fabStyles: {
            position: 'fixed',
            bottom: '48px',
            right: '48px',
            zIndex: 1
        }
    }
    
    handleSave = () => {
      this.setState({ isValidated: true });
      if (this.vaidateData(this.location)) {
         console.log("handlesave location ",this.location);
          this.setState({ isValidated: false });
          this.props.addLocation_action(this.location);
          this.location = { ...this.emptylocationObj };
      }
  }

    

    handleCancel = () => {
      this.handleClose();
    }
    handleSearch= (event)=>{
      const value = event.target.value;
      this.debounceSearch(value.toLowerCase());

    }
    

    handleChange = (key) => (event) => {
        this.location = { ...this.location, [key]: event.target.value };
    }

    isEmpty = (data) => {
        if (data === undefined || data === '' || data === null)
            return false;

        return true;
    }

    render() {
     
        const { clientsarray ,location} = this.props;
        console.log("props inside pd-location",this.props);
        
        
        return (
            <>
            <Box >
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
                marginTop:'50px',
                width:'1250px'
              }}
            >
              <Typography
                sx={{ m: 1,color:'#19b4dd',fontWeight: 600 }}
                variant="h4"
              >
                Client Location
              </Typography>
              <Box sx={{ m: 1 }}>
               
                <Button
                  onClick={() => this.setState({ name: "List" })}
                  startIcon={(<ListAltIcon fontSize="small" />)}
                  sx={{ mr: 1,color:'#19b4dd' }}
                >
                  List
                </Button>
                <Button
                  color="inherit"
                  startIcon={(<AddBoxIcon fontSize='large'/>)}
                  variant="text"
                  sx={{ mr: 1,color:'#19b4dd' }}
                   component={Link} to="/locationadd"
                >
                  Add Location
                </Button>
              </Box>
            </Box>
            <Box sx={{ mt: 3 }}>
              <Card>
                <CardContent>
                  <Box sx={{ maxWidth: 500 }}>
                    <TextField
                      fullWidth
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <SvgIcon
                              color="action"
                              fontSize="small"
                            >
                              <SearchIcon />
                            </SvgIcon>
                          </InputAdornment>
                        )
                      }}
                      placeholder="Search Location"
                      variant="outlined"
                      onChange={this.handleSearch}
                    />
                  
                  </Box>
                  
                </CardContent>
              </Card>
            </Box>
          </Box>
            <div style={this.clientsStyle.root}>
                  
                    <Grid container spacing={2}>
                         {location &&
                            <ClientLocLayoutList location={location} />}

                    </Grid>
                </div></>
        )
    }
}

Location.propTypes = {
    clientsarray: PropTypes.array,
    signIn_action: PropTypes.func,
    fetchClients_action: PropTypes.func,
    addClient_action:PropTypes.func,
    processInProgress_action: PropTypes.func,
    location: PropTypes.array,
    fetchLocation_action:PropTypes.func
}

const mapStateToProps = (state) => {
    console.log("state of clients",state);
    return {
        privilege: state.auth && state.auth.user ? state.auth.user.access : undefined,
        clientsarray: state.client.value,
        location:state.location.locations
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        signIn_action: () => dispatch(signIn()),
        fetchClients_action:()=>dispatch(fetchClients()),
        fetchLocation_action: (query) => dispatch(fetchLocation(query)),
        processInProgress_action: (status) => dispatch(processInProgress(status)),
        addLocation_action: (loc) => dispatch(addLocation(loc)),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Location);
