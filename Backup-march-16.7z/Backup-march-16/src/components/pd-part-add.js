import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepContent from '@material-ui/core/StepContent';
import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import InputBase from '@material-ui/core/InputBase';

//*************Component Import*****************
import PartDetails from './pd-part-details';
import ImageUploader from './pd-file-upload';
import StlUploader from './pd-stl-upload'
import { partAdd, partUpdate, emptySelectedPart, setSelectedPart } from "../store/actions/part_action"
import { processInProgress } from '../store/actions/misc_action'
import { connect } from 'react-redux'
import { withRouter } from "react-router-dom";


const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
        height: '100%',
     
    },
    button: {
        marginTop: theme.spacing(1),
        marginRight: theme.spacing(1),
    },
    actionsContainer: {
        marginBottom: theme.spacing(2),
    },
    resetContainer: {
        padding: theme.spacing(3),
    },
}));

let newPartData = {
    name: '',
    description: '',
    complexity: "1",
    timeStamp: '',
    notes: '',
    number: '',
    size: { length: '', breadth: '', height: '' },
    category: '',
    subcategory: '',
    email: 'developer@immensalabs.com',
    material: 'PA 12',
    searchname: '',
    imagesToUpload: [],
    filesToUpload: [],
    costPrice: '',
    sellingPrice: ''
}

let lastPath = ''

function getSteps() {
    if (window.location.pathname.includes('/partedit'))
        return ['Edit part details', 'Edit Images', 'Edit 3D model'];
    else
        return ['Add part details', 'Add Images', 'Add 3D model'];
}

function PartAddContents(step, selectedPart) {

    //called whenever a change is occured in the page
    const handlePartDetails = (obj) => {
        newPartData = { ...newPartData, ...obj };
    }

    //only called in case of edit part i.e. when selected part is available
    const imagesToUpload = () => {
        let images = [];
        let count = 0;
        //used every other time except first time
        if (selectedPart.imagesToUpload && selectedPart.imagesToUpload.length > 0) {
            return selectedPart.imagesToUpload
        }
        //for first time take images from selectedPart
        if (selectedPart.signedUrls) {
            selectedPart.signedUrls.forEach(element => {
                images.push({ 'id': count++, 'file': element.url });
            });
        }
        return images;
    }

    const stlToUpload = () => {
        let stls = [];
        if (selectedPart.urn && window.location.pathname.includes('/partedit')) {
            stls.push(selectedPart.urn);
        }
        else {
            stls = newPartData.filesToUpload ? [...newPartData.filesToUpload] : []
        }
        return stls;
    }

    newPartData = selectedPart.name ? { ...selectedPart } : { ...newPartData };

    switch (step) {
        case 0:
            return <PartDetails partData={selectedPart.name ? selectedPart : newPartData} partdataHandler={(obj) => handlePartDetails(obj)} />
        case 1:
            return <div style={{ textAlign: "center" }}>
                <ImageUploader partdataHandler={(obj) => handlePartDetails(obj)}
                    filesToShow={selectedPart.name ? imagesToUpload() : newPartData.imagesToUpload}
                    fileUploadType={!selectedPart.name ? 'PartAdd' : 'PartEdit'}
                    input='image/jpeg,image/jpg,image/png' />
            </div>;
        case 2:
            return <div style={{ textAlign: "center" }}>
                <StlUploader
                    fileName="filesToUpload"
                    filesToShow={stlToUpload()}
                    partdataHandler={(obj) => handlePartDetails(obj)} />
            </div>;
        default:
            return 'Unknown step';
    }
}

function PartAdd(props) {
    const classes = useStyles();
    const [activeStep, setActiveStep] = React.useState(0);
    const [isValidationSuccess, setValidationStatus] = React.useState(true);
    const [isDataValidated, setValidatedData] = React.useState(false);
    const steps = getSteps();
    const page = window.location.pathname;

    let emptyPartData = {
        name: '',
        description: '',
        complexity: "1",
        timeStamp: '',
        notes: '',
        number: '',
        size: { length: '', breadth: '', height: '' },
        category: '',
        subcategory: '',
        email: 'developer@immensalabs.com',
        material: 'PA 12',
        costPrice: '',
        sellingPrice: '',
    };

    // imagesToUpload: []
    //this is for transition between add part and edit parts
    //if steps are changes between same page maintain data 
    // if page is changed, then make the form empty.
    newPartData = (window.location.pathname !== lastPath) ? { ...emptyPartData } : { ...newPartData }

    //this has to done after newpart is initialized.
    //Do not put it above newpartData
    lastPath = window.location.pathname;

    //params are for initialization for part edit.
    //for first time set selectedPart data 
    //for every other time use newPartData
    let param = newPartData.name && props.selectedPart ? newPartData : props.selectedPart;

    //gets part details on page refresh
    if (!props.selectedPart.id && Object.entries(props.selectedPart).length === 0 && lastPath !== '/partadd') {
        const partId = lastPath.split('/')[1];
        props.setSelectedPart_action(partId);
    }

    function handleNext() {
        param = { ...newPartData };

        let validationData = param;
        if (activeStep === 0)
            delete validationData['imagesToUpload'];

        if (validateFormData(validationData)) {
            setValidationStatus(true);
            setActiveStep(prevActiveStep => prevActiveStep + 1);
        }
        else
            setValidationStatus(false);

        if (activeStep === 2) {
            const formData = getFormData();
            if (page === '/partadd') {
                
                props.processInProgress_action(true);
                props.partAdd_action(formData, props.history);
            }
            else if (page.includes('/partedit')) {
                props.partUpdate_action(formData);
                //empty selectedPart after it has been edited/updated.
                props.emptySelectedPart_action();
                props.history.push("/");
                props.processInProgress_action(true)
            }
        }
    }

    function handleBack() {
        //newpartData is filled whenever a change takes place in function 'handlePartDetails' 
        //with either details of new part or in case of partedit with selected part edited/original details
        param = { ...newPartData }
        setActiveStep(prevActiveStep => prevActiveStep - 1);
    }

    function handleReset() {
        setActiveStep(0);
    }

    function getFormData() {
        const partFormData = new FormData();
        partFormData.append("name", newPartData.name);
        partFormData.append("length", newPartData.size.length);
        partFormData.append("breadth", newPartData.size.breadth);
        partFormData.append("height", newPartData.size.height);
        partFormData.append("category", newPartData.category);
      //  partFormData.append("subcategory", newPartData.subcategory);
       partFormData.append("subcategory", "valve");
        partFormData.append("number", newPartData.number);
        partFormData.append("description", newPartData.description);
        partFormData.append("notes", newPartData.notes);
        partFormData.append("complexity", newPartData.complexity);
        partFormData.append("material", newPartData.material);
        partFormData.append("email", newPartData.email);
        partFormData.append("organization", props.organization);
        partFormData.append("costPrice", newPartData.costPrice);
        partFormData.append("sellingPrice", newPartData.sellingPrice);

        if (newPartData.imagesToUpload) {
            for (let i = 0; i < newPartData.imagesToUpload.length; i++) {
                if (page === '/partadd') {
                    partFormData.append("partFile" + i, newPartData.imagesToUpload[i].file[0]);
                } else if (page.includes('/partedit') && newPartData.imagesToUpload[i].name) {
                    //for partedit new added images have 'name' property
                    partFormData.append("partFile" + i, newPartData.imagesToUpload[i].file[0]);
                }
            }
        }

        if (page.includes('/partedit')) {
            partFormData.append("id", props.selectedPart.id);
            partFormData.append("printabilityScore", newPartData.printabilityScore);

            //for removing existing part images 
            if (newPartData.removedImages) {
                newPartData.removedImages.forEach((value, Index) => {
                    const key = 'removeS3key' + Index;
                    partFormData.append(key, value);
                })
            }
        }

        if (newPartData.filesToUpload && newPartData.filesToUpload !== []) {
            partFormData.append("viewerFile", newPartData.filesToUpload[0]);
        }
        return partFormData;
    }

    const validateFormData = (formData) => {
        if (Object.keys(formData).length === 0) {
            setValidatedData(false);
            return false;
        }
        for (const item in formData) {
            if (formData.hasOwnProperty(item)) {
                const element = formData[item];
                if (item === 'timeStamp' || item === 'notes')
                    continue;
                //check for length, breadth and height
                if (item === 'size') {
                    for (const key in element) {
                        const entity = element[key];
                        if (!checkElementValues(entity)) {
                            return false;
                        }
                    }
                }

                if (item === 'sellingPrice' || item === 'costPrice') {
                    if (!checkElementValues(element)) {
                        return false;
                    }
                }
                if (element.length === 0 || element === undefined || element == null) {
                    setValidatedData(false);
                    return false;
                }
            }
        }
        return true;
    }

    const checkElementValues = (element) => {
        if (element.length === 0 || element === undefined || element == null) {
            setValidatedData(false);
            return false;
        }

        if (element < 0) {
            setValidatedData(true);
            return false;
        }
        return true;
    }

    return (
        <div className={classes.root} >
            
            <Stepper activeStep={activeStep} orientation="vertical" >
                {steps.map((label, index) => (
                    <Step key={label}>
                        <StepLabel>{label}</StepLabel>
                        <StepContent>
                            <Typography>{PartAddContents(index, (page === '/partadd' ? {} : param))}</Typography>
                            <div className={classes.actionsContainer}>
                                <div>
                                    <Button
                                        disabled={activeStep === 0}
                                        onClick={handleBack}
                                        className={classes.button}
                                    >
                                        Back
                                    </Button>
                                    <Button
                                        variant="contained"
                                        color="primary"
                                        onClick={handleNext}
                                        className={classes.button}
                                    >
                                        {activeStep === steps.length - 1 ? (page === '/partadd' ? 'Save' : 'update') : 'Next'}
                                    </Button>
                                    <InputBase
                                        value={activeStep === 0 ? !isDataValidated ? "*All fields are necessary" : "Values cannot be negative" : "*No images are selected"}
                                        inputProps={{ 'aria-label': 'naked' }}
                                        disabled
                                        color="#ff0000"
                                        style={{ display: !isValidationSuccess ? 'block' : 'none', color: "#ff0000" }}
                                    />
                                </div>
                            </div>
                        </StepContent>
                    </Step>
                ))}
            </Stepper>
            {activeStep === steps.length && (
                <Paper square elevation={0} className={classes.resetContainer}>
                    <Typography>All steps completed - Part is getting added. Wait for a while.</Typography>
                    {/* <Button onClick={handleReset} className={classes.button}>
                        Reset
                    </Button> */}
                </Paper>
            )}
        </div>
    );
}

const mapStateToProps = (state) => {
    return {
        selectedPart: state.parts && state.parts.selectedPart ? state.parts.selectedPart : {},
        organization: state.auth.user ? state.auth.user.organization : undefined
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        setSelectedPart_action: (id) => dispatch(setSelectedPart(id)),
        partAdd_action: (formdata, history) => dispatch(partAdd(formdata, history)),
        partUpdate_action: (formdata) => dispatch(partUpdate(formdata)),
        emptySelectedPart_action: () => { dispatch(emptySelectedPart({})) },
        processInProgress_action: (status) => { dispatch(processInProgress(status)) }
    }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(PartAdd))