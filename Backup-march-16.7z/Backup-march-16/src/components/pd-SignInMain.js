import React, { Component } from "react";
import { HashRouter as Router, Route, NavLink, useLocation } from "react-router-dom";
import SignUpForm from "./SignUpForm";
import SignInForm from "./SignInForm";
import Paper from '@mui/material/Paper'
import { Box, Button, Container, Grid, Link, TextField, Typography } from '@mui/material';
import "../Styles/SignIn_styles.css";

const SignInMain = (props) => {
  const location = useLocation(); 
  console.log('loc', location)
  const isResetPage = location.pathname === "/reset-password";
    return (
      // <Router basename="/auth/">
        <div className="SignInMain">
          <div className="SignInMainAside" />
          <div className="SignInMainForm">
            <div className="pageSwitcher">
              <NavLink
                exact
                to="/signin"
                activeClassName="pageSwitcherItem-active"
                className="pageSwitcherItem"
              >
                Sign In
              </NavLink>
              <NavLink
                to="/signup"
                activeClassName="pageSwitcherItem-active"
                className="pageSwitcherItem"
              >
                Sign Up
              </NavLink>
            </div>
            {!isResetPage ?
            <div className="formTitle">
              <NavLink
                exact
                to="/signin"
                activeClassName="formTitleLink-active"
                className="formTitleLink"
              >
                Sign In
              </NavLink>{" "}
              or{" "}
              <NavLink
                to="/signup"
                activeClassName="formTitleLink-active"
                className="formTitleLink"
              >
                Sign Up
              </NavLink>
            </div>
             : 
            <div className="formTitle">
            <NavLink
              exact
              to="/reset-password"
              activeClassName="formTitleLink-active"
              className="formTitleLink"
            >
              Reset Password
            </NavLink>
            </div>
            }

            
            {/* <Route exact path="/" component={} />
            <Route path="/sign-in" component={SignInForm} /> */}
            {props.children}
          </div>
        </div>
      // </Router>
    );
}

export default SignInMain;
