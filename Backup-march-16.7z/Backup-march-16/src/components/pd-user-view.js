import React, { Component } from 'react';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardMedia from '@material-ui/core/CardMedia';
import CardContent from '@material-ui/core/CardContent';
import Avatar from '@material-ui/core/Avatar';
import Typography from '@material-ui/core/Typography';
import { red } from '@material-ui/core/colors';
import Grid from '@material-ui/core/Grid';
import Button from "@material-ui/core/Button";
import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import PropTypes from 'prop-types'
import Modal from './pd-dialog'
import { deleteUser } from '../store/actions/user_action';

const styles = (theme) => ({
    root: {
        flexGrow: 1
    },
    card: {
        maxWidth: 300,
        padding: theme.spacing(1),
        boxShadow: "0 8px 40px -12px rgba(0,0,0,0.3)",
    },
    media: {
        height: 0,
        width: 150,
        paddingTop: '56.25%', // 16:9
    },
    avatar: {
        backgroundColor: red[500]
    },
    button: {
        backgroundImage: "linear-gradient(147deg, #43609C 0%, #43609C 74%)",
        boxShadow: "0px 4px 32px rgba(68, 175, 178, 0.4)",
        borderRadius: 10,
        paddingLeft: 24,
        paddingRight: 24,
        color: "#ffffff"
    },
    button2: {
        backgroundImage: "linear-gradient(1deg, #000 0%, #FF0000 2%)",
        boxShadow: "0px 4px 32px rgba(68, 175, 178, 0.4)",
        borderRadius: 15,
        paddingLeft: 24,
        paddingRight: 24,
        color: "#ffffff"
    }
});

const MediaCardHeader = withStyles({
    content: {
        display: 'flex',
        paddingLeft: '28px',
    },
    title: {
        fontWeight: "bold",
        fontSize: "medium"
    }
})(CardHeader)

class UserProfileView extends Component {

    constructor(props) {
        super(props);
        this.userProfile = React.createRef();
        this.state = {
            isDialogVisible: false,
            email: props.userData.email,
            privilege: props.userData.privilege,
            oldPrivilege: props.userData.privilege,
            username: props.userData.username,
            name: this.props.userData.name
        }
    }

    handleCancel = () => {
        this.userProfile.current.handleClose();
    }

    handleDelete = () => {
        this.userProfile.current.handleClose();
        this.props.deleteUser_action(this.props.userData);
    }

    handleEdit = () => {
        let data = {
            "email": this.props.userData.email,
            "privilege": this.props.userData.privilege,
            'username': this.props.userData.username,
            'name': this.props.userData.name
        }
        this.props.action(data);
    }

    handleNameLength = (attribute) => {
        if (attribute && attribute.length > 26) {
            attribute = attribute.substring(0, 26);
            attribute = attribute + "...";
        }
        return attribute;
    }

    render() {
        const { classes, userData, privilege } = this.props;
        let image = "./images/user.jpg";
        if (userData.imageUrl) {
            image = userData.imageUrl;
        }
        return (
            <div align='center' className={classes.root}>
                <Card className={classes.card}>
                    <MediaCardHeader
                        avatar={
                            <Avatar aria-label="Recipe" className={classes.avatar}>
                                {userData.email.charAt(0).toUpperCase()}
                            </Avatar>
                        }
                        title={this.handleNameLength(userData.name)}
                    />
                    <CardMedia
                        className={classes.media}
                        image={image}
                    />
                    <CardContent>
                        <Typography variant="body2" color="textSecondary" component="p">
                            Privilege : {userData.privilege}
                        </Typography>
                        <Typography variant="body2" color="textSecondary" component="p">
                            Email : {this.handleNameLength(userData.email)}
                        </Typography>
                        {privilege && privilege.editUser &&
                            <Grid container >
                                <Grid style={{ paddingTop: '8%' }} item xs={6} >
                                    <Button className={classes.button} onClick={this.handleEdit} >Edit
                                </Button>
                                </Grid>
                                <Grid style={{ paddingTop: '8%' }} item xs={6}>
                                    <Button className={classes.button2} onClick={() => { this.userProfile.current.handleClickOpen() }}>Delete</Button>
                                </Grid>
                            </Grid>
                        }
                    </CardContent>
                </Card>
                <Modal title="User Profile Delete" obj={this.handleDelete} ref={this.userProfile}>
                    <h4>Are you sure you want to delete ?</h4>
                </Modal>
            </div>
        )
    }
}

UserProfileView.propTypes = {
    deleteUser_action: PropTypes.func,
    privilege: PropTypes.object,
    action: PropTypes.func,
    userData: PropTypes.object,
    classes: PropTypes.any
}

const mapStateToProps = (state) => {
    return {
        privilege: state.auth.user ? state.auth.user.access : undefined
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        deleteUser_action: (user) => dispatch(deleteUser(user))
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(UserProfileView));