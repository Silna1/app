import React from  'react';
import Chart from '@material-ui/icons/InsertChart';
import DashboardIcon from '@mui/icons-material/Dashboard';
import CategoryIcon from '@mui/icons-material/Category';
import TimelineIcon from '@mui/icons-material/Timeline';
import GroupIcon from '@mui/icons-material/Group';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import Inventory2Icon from '@mui/icons-material/Inventory2';
import SettingsIcon from '@mui/icons-material/Settings';
import LogoutIcon from '@mui/icons-material/Logout';
import ViewListIcon from '@mui/icons-material/ViewList';
import AddCardIcon from '@mui/icons-material/AddCard';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import DisplaySettingsIcon from '@mui/icons-material/DisplaySettings';
import PermDataSettingIcon from '@mui/icons-material/PermDataSetting';

export const NavbarData = [
    {
        name : "Dashboard",
        icon : <DashboardIcon />,
        link : '/topcats',
        showMenu : true,
        key: 'dashboard',
        subList: [
            {
                name: "Top Categories",
                icon: <CategoryIcon />,
                link: '/topcats',
                showMenu : false,
            },
            {
                name: "Analysis",
                icon: <TimelineIcon />,
                link: '/analysis',
                showMenu : false,
            },
        ],
    },
    {
        name: "Clients",
        link: "/clients",
        icon: <GroupIcon/>,
        showMenu : true, 
        key: 'client',
        subList: [
            {
                name: "Project",
                link: '/projects',
                icon: <AccountTreeIcon/>,
                showMenu : true,
                key: 'project',
            },
            {
                name: "Location",
                link: "/locations",
                icon: <LocationOnIcon/>,
                key: 'location',
                showMenu : true,
            },
        ],
    },
    {
        name: "Parts",
        link: "/",
        icon : <Inventory2Icon />,
        showMenu : true,
        key: 'part',
        subList: [
            {
                name: "List Parts",
                link: '/partcatalog',
                icon: <ViewListIcon/>,
                showMenu : false,
            },
            {
                name: "Add Parts",
                link: "/partadd",
                icon: <AddCardIcon/>,
                showMenu : false,
            },
        ],
    },
    {
        name: "Settings",
        link: "/adminsettings",
        icon : <SettingsIcon />,
        showMenu : false,
    },
    {
        name: "Users",
        link: "/usersetting",
        icon : <ManageAccountsIcon />,
        showMenu : true,
        key: 'user',
        subList: [
            {
                name: "Menu Access",
                link: '/menuaccess',
                icon: <DisplaySettingsIcon/>,
                showMenu : false,
            },
            {
                name: "Data Access",
                link: "/dataaccess",
                icon: <PermDataSettingIcon/>,
                showMenu : false,
            },
        ],
    },
    {
        name: "Logout",
        link: "/signin",
        icon : <LogoutIcon />,
        showMenu : false,
    }
]
