import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import { connect } from 'react-redux'
import ClientsLayoutGrid from "./pd-client-grid-layout"
import ClientProLayoutList from "./pd-client-project"
import PropTypes from 'prop-types';
import Box from '@material-ui/core/Box';
import { Link } from 'react-router-dom';
import {
    Button,
    Card,
    CardContent,
    TextField,
    InputAdornment,
    SvgIcon, Typography
  } from '@mui/material';
  import { Search as SearchIcon } from './icons/search';
  import AddBoxIcon from '@mui/icons-material/AddBox';
  import ListAltIcon from '@mui/icons-material/ListAlt';
import {
    fetchClients,
    deleteClient,
    addClient,
    updateClient,
  } from "../store/actions/client_action";

import { signIn } from '../store/actions/authentication_action';
import { processInProgress } from '../store/actions/misc_action';
import _,{debounce} from "lodash"
import { fetchProject } from '../store/actions/project_action';

class Projects extends Component {
    

    constructor(props) {
        super(props);
        this.isPartsAvailable = false;
        this.state = {
            name:"Grid",
            isValidated: false,
            isValuesNegative: false
        };
        this.clientObj = React.createRef();
        this.props.signIn_action();
        this.emptyclientObj = { ...this.client };
        this.debounceSearch = debounce(function (value) {
          this.props.fetchProject_action(`?searchname=${value}`);
          }, 1000);
    }

    client = {
      clientName: '',
      clientLogo: "",
      phoneNumber: '',
      active: true,
      createDate: '',
      email: '',
      lastUpdate: '',
      clientType:'',
      sector:'',
      address1:'',
      address2:'',
      city:'',
      state:'',
      country: [],
      pinCode:''
  }
   

    componentDidMount() {
        this.props.processInProgress_action(true);
        this.props.fetchClients_action();
            
    }

    clientsStyle = {
        root: {
            flexGrow: 1,
            backgroundImage: '',
            overflowX: "hidden",
            overflowY: 'hidden',
            height: '100%',
            minHeight: '-webkit-fill-available'
        },
        fabStyles: {
            position: 'fixed',
            bottom: '48px',
            right: '48px',
            zIndex: 1
        }
    }
    
    handleSave = () => {
        this.setState({ isValidated: true });
        if (this.vaidateData(this.client)) {
           console.log("handlesave client ",this.client);
            this.setState({ isValidated: false });
            this.clientObj.current.handleClose();
            this.props.addClient_action(this.client);
            this.client = { ...this.emptyclientObj };
        }
    }

    handleSearch= (event)=>{
      const value = event.target.value;
      this.debounceSearch(value.toLowerCase());

    }

    vaidateData = (data) => {
        /*for (const element in data) {
            if (data.hasOwnProperty(element)) {
                if (element === 'size') {
                    let sizeObj = data[element];
                    for (const item in sizeObj) {
                        if (this.isEmpty(sizeObj[item]) && Number(sizeObj[item]) < 0) {
                            this.setState({ isValuesNegative: true });
                            return false;
                        }
                        else if (!this.isEmpty(sizeObj[item])) {
                            this.setState({ isValuesNegative: false });
                            return false;
                        }
                    }
                }
                if (!this.isEmpty(data[element]))
                    return false;
            }
        }*/
        this.setState({ isValuesNegative: false });
        return true;
    }

    handleChange = (key) => (event) => {
        
        this.client = { ...this.client, [key]: event.target.value };
    }

    isEmpty = (data) => {
        if (data === undefined || data === '' || data === null)
            return false;

        return true;
    }

    handleSave = () => {
        this.setState({ isValidated: true });
        if (this.vaidateData(this.client)) {
           console.log("handlesave client ",this.client);
            this.setState({ isValidated: false });
            this.clientObj.current.handleClose();
            this.props.addClient_action(this.client);
            this.client = { ...this.emptyclientObj };
        }
    }


    render() {
     
        const { clientsarray, clientList ,project} = this.props;
        console.log("props inside pd-client",this.props);
        
        
        return (
            <><Box >
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
                marginTop:'50px'
              }}
            >
              <Typography
                sx={{ m: 1,color:'#19b4dd',fontWeight: 600 }}
                variant="h4"
              >
                Project Overview
              </Typography>
              <Box sx={{ m: 1 }}>
               
                <Button
                  onClick={() => this.setState({ name: "List" })}
                  startIcon={(<ListAltIcon fontSize="small" />)}
                  sx={{ mr: 1,color:'#19b4dd' }}
                >
                  List
                </Button>
                <Button
                  color="inherit"
                  startIcon={(<AddBoxIcon fontSize='large'/>)}
                  variant="text"
                  sx={{ mr: 1,color:'#19b4dd' }}
                  component={Link} to="/projectadd"
                >
                  Add Project
                </Button>
              </Box>
            </Box>
            <Box sx={{ mt: 3 }}>
              <Card>
                <CardContent>
                  <Box sx={{ maxWidth: 500 }}>
                    <TextField
                      fullWidth
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <SvgIcon
                              color="action"
                              fontSize="small"
                            >
                              <SearchIcon />
                            </SvgIcon>
                          </InputAdornment>
                        )
                      }}
                      placeholder="Search Project"
                      variant="outlined"
                      onChange={this.handleSearch}
                    />
                  
                  </Box>
                  
                </CardContent>
              </Card>
            </Box>
          </Box>
            <div style={this.clientsStyle.root}>
                  
                    <Grid container spacing={2}>
                         {project &&
                            <ClientProLayoutList project={project} />}

                    </Grid>
                </div></>
        )
    }
}

ClientProLayoutList.propTypes = {
    selectedClient: PropTypes.string,
    clientsarray: PropTypes.array,
    signIn_action: PropTypes.func,
    fetchClients_action: PropTypes.func,
    addClient_action:PropTypes.func,
    processInProgress_action: PropTypes.func,
    fetchProject_action: PropTypes.func
}

const mapStateToProps = (state) => {
    console.log("state of clients",state);
    return {
        privilege: state.auth && state.auth.user ? state.auth.user.access : undefined,
        clientsarray: state.client.value,
        project:state.project.projects,
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        signIn_action: () => dispatch(signIn()),
        fetchClients_action:()=>dispatch(fetchClients()),
        addClient_action:(clientsarray)=>dispatch(addClient(clientsarray)),
        processInProgress_action: (status) => dispatch(processInProgress(status)),
        fetchProject_action:(query)=>dispatch(fetchProject(query))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Projects);
