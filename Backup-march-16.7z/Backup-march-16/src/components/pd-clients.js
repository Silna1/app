import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import { connect } from 'react-redux'
import ClientsLayoutGrid from "./pd-client-grid-layout"
import ClientLayoutList from "./pd-clients-layout"
import PropTypes from 'prop-types';
import Box from '@material-ui/core/Box';
import Modal from './pd-dialog';
import InputBase from '@material-ui/core/InputBase';
import { Link } from 'react-router-dom';
import {
    Button,
    Card,
    CardContent,
    TextField,
    InputAdornment,
    SvgIcon, Typography
  } from '@mui/material';
  import { Search as SearchIcon } from './icons/search';
  import AddBoxIcon from '@mui/icons-material/AddBox';
  import ListAltIcon from '@mui/icons-material/ListAlt';
  import GridViewIcon from '@mui/icons-material/GridView';
import {
    fetchClients,
    addClient,
  } from "../store/actions/client_action";

import { signIn } from '../store/actions/authentication_action';
import { processInProgress } from '../store/actions/misc_action';
import _,{debounce} from "lodash"


const reload=()=>window.location.reload();

class Clients extends Component {
    

    constructor(props) {
        super(props);
        this.isPartsAvailable = false;
        this.state = {
            name:"Grid",
            isValidated: false,
            isValuesNegative: false
        };
        this.clientObj = React.createRef();
        this.props.signIn_action();
        this.emptyclientObj = { ...this.client };
        this.debounceSearch = debounce(function (value) {
          this.props.fetchClients_action(`?searchname=${value}`);
          }, 1000);
    }

    client = {
    clientName: '',
    clientId: '',
    clientLogo: " ",
    phoneNumber: 123,
    active: true,
    createDate: '',
    locationId: '',
    email: 'developer@immensalabs.com',
    lastUpdate: ''
    }
   

    componentDidMount() {
        this.props.processInProgress_action(true);
        this.props.fetchClients_action();
            
    }

    clientsStyle = {
        root: {
            flexGrow: 1,
            backgroundImage: '',
            overflowX: "hidden",
            overflowY: 'hidden',
            height: '100%',
            minHeight: '-webkit-fill-available'
        },
        fabStyles: {
            position: 'fixed',
            bottom: '48px',
            right: '48px',
            zIndex: 1
        }
    }
    
    handleSave = () => {
        this.setState({ isValidated: true });
        if (this.vaidateData(this.client)) {
           console.log("handlesave client ",this.client);
            this.setState({ isValidated: false });
            this.clientObj.current.handleClose();
            this.props.addClient_action(this.client);
            this.client = { ...this.emptyclientObj };
        }
    }

    handleSearch= (event)=>{
      const value = event.target.value;
      this.debounceSearch(value.toLowerCase());

    }

    vaidateData = (data) => {
        /*for (const element in data) {
            if (data.hasOwnProperty(element)) {
                if (element === 'size') {
                    let sizeObj = data[element];
                    for (const item in sizeObj) {
                        if (this.isEmpty(sizeObj[item]) && Number(sizeObj[item]) < 0) {
                            this.setState({ isValuesNegative: true });
                            return false;
                        }
                        else if (!this.isEmpty(sizeObj[item])) {
                            this.setState({ isValuesNegative: false });
                            return false;
                        }
                    }
                }
                if (!this.isEmpty(data[element]))
                    return false;
            }
        }*/
        this.setState({ isValuesNegative: false });
        return true;
    }

    handleChange = (key) => (event) => {
        
        this.client = { ...this.client, [key]: event.target.value };
    }

    isEmpty = (data) => {
        if (data === undefined || data === '' || data === null)
            return false;

        return true;
    }

    handleSave = () => {
        this.setState({ isValidated: true });
        if (this.vaidateData(this.client)) {
           console.log("handlesave client ",this.client);
            this.setState({ isValidated: false });
            this.clientObj.current.handleClose();
            this.props.addClient_action(this.client);
            this.client = { ...this.emptyclientObj };
        }
    }


    render() {
     
        const { clientsarray, clientList } = this.props;
        console.log("props inside pd-client",this.props);
        
        
        return (
            <><Box >
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
                marginTop:'50px'
              }}
            >
              <Typography
                sx={{ m: 1,color:'#19b4dd',fontWeight: 600 }}
                variant="h4"
              >
                Clients
              </Typography>
              <Box sx={{ m: 1 }}>
                <Button
                  onClick={() => this.setState({ name: "Grid" })}
                  startIcon={(<GridViewIcon fontSize="small" />)}
                  sx={{ mr: 1,color:'#19b4dd' }}
                >
                  Grid
                </Button>
                <Button
                  onClick={() => this.setState({ name: "List" })}
                  startIcon={(<ListAltIcon fontSize="small" />)}
                  sx={{ mr: 1,color:'#19b4dd' }}
                >
                  List
                </Button>
                <Button
                  color="inherit"
                  startIcon={(<AddBoxIcon fontSize='large'/>)}
                  variant="text"
                  sx={{ mr: 1,color:'#19b4dd' }}
                  component={Link} to="/clientadd"
                >
                  Add Client
                </Button>

                <Modal title="Add New Client" obj={this.handleSave} ref={this.clientObj} onExit={reload}>
                    {console.log("add new client",this.clientObj)}
                    <TextField fullWidth label="Name" onChange={this.handleChange('clientName') }style={{ padding: "5px" }} />
                    <TextField label="ClientId" onChange={this.handleChange('clientId')} style={{ padding: "5px", minWidth: "50%" }} />
                    <TextField label="Email" onChange={this.handleChange('email')} style={{ padding: "5px", minWidth: "50%" }} />
                    <TextField fullWidth label="PhoneNumber" onChange={this.handleChange('phoneNumber')} style={{ padding: "5px" }} />
                    <TextField  label="ClientLogo" onChange={this.handleChange('clientLogo')} style={{ padding: "5px" }} InputProps={{ inputProps: { min: 0 } }} />
                    <TextField  label="Active" onChange={this.handleChange('active')} style={{ padding: "5px" }} InputProps={{ inputProps: { min: 0 } }} />
                    <TextField  label="Location" onChange={this.handleChange('locationId')} style={{ padding: "5px" }} InputProps={{ inputProps: { min: 0 } }} />
                    <InputBase
                        value={!this.state.isValuesNegative ? "*All fields are necessary" : "Values cannot be negative"}
                        inputProps={{ 'aria-label': 'naked' }}
                        disabled
                        color="#ff0000"
                        style={{ display: !this.state.isValidated ? 'none' : 'block', color: "#ff0000" }}
                    />
                </Modal>
              </Box>
            </Box>
            <Box sx={{ mt: 3 }}>
              <Card>
                <CardContent>
                  <Box sx={{ maxWidth: 500 }}>
                    <TextField
                      fullWidth
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">
                            <SvgIcon
                              color="action"
                              fontSize="small"
                            >
                              <SearchIcon />
                            </SvgIcon>
                          </InputAdornment>
                        )
                      }}
                      placeholder="Search Client"
                      variant="outlined"
                      onChange={this.handleSearch}
                    />
                  
                  </Box>
                  
                </CardContent>
              </Card>
            </Box>
          </Box>
            <div style={this.clientsStyle.root}>
                   { this.state.name ==="Grid"?
                    
                    <Grid container spacing={2}>
                        {clientsarray &&
                            <ClientsLayoutGrid clientsarray={clientsarray} />}

                    </Grid>
                    :
                    <Grid container spacing={2}>
                         {clientsarray &&
                            <ClientLayoutList clientsarray={clientsarray} />}

                    </Grid>
                    }
                </div></>
        )
    }
}

Clients.propTypes = {
    selectedClient: PropTypes.string,
    clientsarray: PropTypes.array,
    signIn_action: PropTypes.func,
    fetchClients_action: PropTypes.func,
    addClient_action:PropTypes.func,
    processInProgress_action: PropTypes.func,
    fetchClients_action: PropTypes.func
}

const mapStateToProps = (state) => {
    console.log("state of clients",state);
    return {
        privilege: state.auth && state.auth.user ? state.auth.user.access : undefined,
        clientsarray: state.client.value
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        signIn_action: () => dispatch(signIn()),
        fetchClients_action:()=>dispatch(fetchClients()),
        addClient_action:(clientsarray)=>dispatch(addClient(clientsarray)),
        processInProgress_action: (status) => dispatch(processInProgress(status)),
        fetchClients_action:(query) => dispatch(fetchClients(query))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Clients);
