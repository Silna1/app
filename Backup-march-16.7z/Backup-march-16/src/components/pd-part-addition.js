import React, { Component } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepContent from '@material-ui/core/StepContent';
import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import InputBase from '@material-ui/core/InputBase';
import VerticalStepper from './pd-part-add-stepper';
import { partAdd, partUpdate, emptySelectedPart, setSelectedPart } from "../store/actions/part_action";
import { processInProgress } from '../store/actions/misc_action';
import { connect } from 'react-redux'
import { withRouter } from "react-router-dom";
import cloneDeepWith from 'lodash/cloneDeepWith';
import { config } from '../config'
import { FetchAPI } from '../fetch'
import _ from 'lodash';

const useStyles = theme => ({
    root: {
        width: '90%',
    },
    button: {
        marginTop: theme.spacing(1),
        marginRight: theme.spacing(1),
    },
    actionsContainer: {
        marginBottom: theme.spacing(2),
    },
    resetContainer: {
        padding: theme.spacing(3),
    },
});

class PartAdd extends Component {

    constructor(props) {
        super(props);
        this.steps = this.getSteps();
        this.isPartEdited = false;
        this.newParts = {
            name: '',
            description: '',
            complexity: "1",
            timeStamp: '',
            notes: '',
            number: '',
            size: { length: '', breadth: '', height: '' },
            category: '',
            subcategory:'',
            email: 'developer@immensalabs.com',
            material: 'ABS',
            imagesToUpload: [],
            filesToUpload: [],
            costPrice: '',
            sellingPrice: ''
        };
        this.state = {
            activeStep: 0,
            isValidationSuccess: true,
            isDataValidated: "",
            newPartData: { ...this.newParts }
        }
    }

    componentDidMount() {
        //gets part details on page refresh
        const lastPath = window.location.pathname;
        if (!this.props.selectedPart.id && Object.entries(this.props.selectedPart).length === 0 && lastPath !== '/partadd') {
            const partId = lastPath.split('/')[1];
            this.props.setSelectedPart_action(partId);
        }
    }

    componentWillUnmount = () => {
        this.props.emptySelectedPart_action();
    }

    getSteps() {
        if (window.location.pathname.includes('/partedit'))
            return ['Edit part details', 'Edit Images', 'Edit 3D model'];
        else
            return ['Add part details', 'Add Images', 'Add 3D model'];
    }

    handleNext = async () => {
        let paramsData = { ...this.state.newPartData };
        let validationData = cloneDeepWith(paramsData);
        if (this.state.activeStep === 0)
            delete validationData['imagesToUpload'];
        const validate = await this.validateFormData(validationData);
        const currentActiveStep = this.state.activeStep;
        if (validate) {
            let step = this.state.activeStep + 1;
            this.setState({ isValidationSuccess: true, activeStep: step, newPartData: paramsData, isDataValidated: "" })
        } else {
            this.setState({ isValidationSuccess: false });
        }

        if (currentActiveStep === 2) {
            const formData = this.getFormData();
            let page = window.location.pathname
            if (page === '/partadd') {
                this.props.processInProgress_action(true)
                this.props.partAdd_action(formData, this.props.history,this.props.organization);
            }
            else if (page.includes('/partedit')) {
                //empty selectedPart after it has been edited/updated.
                this.props.emptySelectedPart_action();
                this.props.processInProgress_action(true)
                this.props.partUpdate_action(formData, this.props.history);
            }
        }
    };

    handleBack = () => {
        this.param = { ...this.state.newPartData }
        let step = this.state.activeStep - 1;
        this.setState({ activeStep: step });
        if (this.state.activeStep === 1) {
            this.setState({ isValidationSuccess: true });
        }
    };

    handleReset = () => {
        this.setState({ activeStep: 0 });
    };

    checkElementValues = (element) => {
        if (element.length === 0 || element === undefined || element == null) {
            this.setState({ isDataValidated: "*All fields are necessary" });
            return false;
        }

        if (element < 0) {
            this.setState({ isDataValidated: "Values can not be negative" });
            return false;
        }
        return true;
    }

    getFormData = () => {
        const partFormData = new FormData();
        partFormData.append("name", this.state.newPartData.name.trim());
        partFormData.append("length", this.state.newPartData.size.length);
        partFormData.append("breadth", this.state.newPartData.size.breadth);
        partFormData.append("height", this.state.newPartData.size.height);
        partFormData.append("category", this.state.newPartData.category);
       // partFormData.append("subcategory", this.state.newPartData.subcategory);
       partFormData.append("subcategory", "valve");
        partFormData.append("number", this.state.newPartData.number.trim());
        partFormData.append("description", this.state.newPartData.description.trim());
        let notesValue = this.state.newPartData.notes;
        if (!_.isEmpty(this.state.newPartData.notes))
            notesValue = this.state.newPartData.notes.trim();
        partFormData.append("notes", notesValue);
        partFormData.append("complexity", this.state.newPartData.complexity);
        partFormData.append("material", this.state.newPartData.material);
        partFormData.append("email", this.state.newPartData.email);
        partFormData.append("organization", this.props.organization.trim());
        partFormData.append("costPrice", this.state.newPartData.costPrice);
        partFormData.append("sellingPrice", this.state.newPartData.sellingPrice);

        let page = window.location.pathname;
        if (this.state.newPartData.imagesToUpload) {
            for (let i = 0; i < this.state.newPartData.imagesToUpload.length; i++) {
                if (page === '/partadd') {
                    partFormData.append("partFile" + i, this.state.newPartData.imagesToUpload[i].file[0]);
                } else if (page.includes('/partedit') && this.state.newPartData.imagesToUpload[i].name) {
                    //for partedit new added images have 'name' property
                    partFormData.append("partFile" + i, this.state.newPartData.imagesToUpload[i].file[0]);
                }
            }
        }

        if (page.includes('/partedit')) {
            partFormData.append("id", this.props.selectedPart.id);
            partFormData.append("printabilityScore", this.state.newPartData.printabilityScore);

            //for removing existing part images 
            if (this.state.newPartData.removedImages) {
                this.state.newPartData.removedImages.forEach((value, Index) => {
                    const key = 'removeS3key' + Index;
                    partFormData.append(key, value);
                })
            }
        }

        if (this.state.newPartData.filesToUpload && this.state.newPartData.filesToUpload.length > 0) {
            partFormData.append("viewerFile", this.state.newPartData.filesToUpload[0]);
        }
        return partFormData;
    }

    validateFormData = async (formData) => {

        console.log("Check form Data",formData);

        if (Object.keys(formData).length === 0) {
            this.setState({ isDataValidated: "*All fields are necessary" });
            return false;
        }

        for (const item in formData) {
        
            if (formData.hasOwnProperty(item)) {
                let element = formData[item];
                if (typeof (element) === "string")
                    element = element.trim();

                if (item === 'filesToUpload') {
                    continue;
                }
                if (item === 'name' && element.length !== 0) {
                    if (window.location.pathname.includes('/partedit') && this.props.selectedPart.name === element) {
                        continue;
                    }
                    let response = await FetchAPI.postData(config.HostURL + "/search/searchexactpart", { "name": element.toLowerCase(), 'organization': this.props.organization })
                        .then((data) => {
                            if (data.Items.length !== 0 && data.Items[0].name.toLowerCase() === element.toLowerCase()) {
                                this.setState({
                                    isDataValidated: "Same part name is already present, try something different."
                                })
                                return false;
                            } else {
                                return true;
                            }

                        })
                        .catch((err) => {
                            console.log(err);
                        })

                    if (response) {
                        continue;
                    } else {
                        return response;
                    }
                }

                if (item === 'timeStamp' || item === 'notes')
                    continue;
                //check for length, breadth and height
                if (item === 'size') {
                    for (const key in element) {
                        const entity = element[key];
                        if (!this.checkElementValues(entity)) {
                            return false;
                        }
                    }
                }

                if (item === 'sellingPrice' || item === 'costPrice') {
                    if (!this.checkElementValues(element)) {
                        return false;
                    }
                }
                if (element.length === 0 || element === undefined || element == null) {
                    let message = "*All fields are necessary";
                    if (item === "imagesToUpload") {
                        message = "*No images are selected";
                    }
                    this.setState({ isDataValidated: message });

                    return false;
                }
            }
        }
        return true;
    }

    // async checkSameName(element) {
    //     // const _self = this;
    //     // return new Promise(async (resolve, reject) => {
    //     //     if (_self.props.selectedPart.name === element) {
    //     //         resolve(true);
    //     //     }
    //     //     let response = true;
    //     //     response = await FetchAPI.postData(config.HostURL + "/search/searchexactpart", { "name": element.toLowerCase(), 'organization': _self.props.organization })
    //     //         .then((data) => {
    //     //             if (data.Items.length !== 0 && data.Items[0].name.toLowerCase() === element.toLowerCase()) {
    //     //                 this.setState({
    //     //                     isDataValidated: "Same part name is already present, try something different."
    //     //                 })
    //     //                 return false;
    //     //             }
    //     //         })
    //     //         .catch((err) => {
    //     //             console.log(err);
    //     //         })
    //     //     resolve(response);
    //     // })

    //     if (this.props.selectedPart.name === element) {
    //         return true;
    //     }
    //     let response = true;
    //     response = await FetchAPI.postData(config.HostURL + "/search/searchexactpart", { "name": element.toLowerCase(), 'organization': this.props.organization })
    //         .then((data) => {
    //             if (data.Items.length !== 0 && data.Items[0].name.toLowerCase() === element.toLowerCase()) {
    //                 this.setState({
    //                     isDataValidated: "Same part name is already present, try something different."
    //                 })
    //                 return false;
    //             }
    //         })
    //         .catch((err) => {
    //             console.log(err);
    //         })
    //     return response;
    // }

    partDataHandler = (obj) => {
        let partData = cloneDeepWith(this.state.newPartData);
        let key = Object.keys(obj)[0];
        for (let keys in Object.keys(obj)) {
            partData[key] = obj[key];
        }
        this.setState({ newPartData: cloneDeepWith(partData) });
    }

    render() {
        const classes = this.props;
        let partProfileData = cloneDeepWith(this.state.newPartData);
        if (Object.entries(this.props.selectedPart).length > 0 && this.props.selectedPart.name !== "" && !this.isPartEdited) {
            partProfileData = cloneDeepWith(this.props.selectedPart);
            this.setState({ newPartData: partProfileData });
            this.isPartEdited = true;
        }
        let message = "All steps completed - Part is getting added. Wait for a while.";
        let page = window.location.pathname;
        if (page.includes("/partedit")) {
            message = "All steps completed - Part is getting updated. Wait for a while.";
        }

        return (
            <div className={classes.root}>
                <br />
                <Stepper activeStep={this.state.activeStep} orientation="vertical">
                    {this.steps.map((label, index) => (
                        <Step key={label}>
                            <StepLabel>{label}</StepLabel>
                            <StepContent>
                                <Typography>
                                    <VerticalStepper
                                        partDataHandler={obj => this.partDataHandler(obj)}
                                        partData={partProfileData}
                                        step={index}
                                    />
                                </Typography>
                                <div className={classes.actionsContainer}>
                                    <div>
                                        <Button
                                            disabled={this.state.activeStep === 0}
                                            onClick={this.handleBack}
                                            className={classes.button}
                                        >
                                            Back
                                        </Button>
                                        <Button
                                            variant="contained"
                                            color="primary"
                                            onClick={this.handleNext}
                                            className={classes.button}
                                        >
                                            {this.state.activeStep === this.steps.length - 1 ? (window.location.pathname === '/partadd' ? 'Save' : 'Update') : 'Next'}
                                        </Button>
                                        <InputBase
                                            value={this.state.isDataValidated}
                                            inputProps={{ 'aria-label': 'naked' }}
                                            disabled
                                            color="#ff0000"
                                            style={{ display: !this.state.isValidationSuccess ? 'block' : 'none', color: "#ff0000" }}
                                        />
                                    </div>
                                </div>
                            </StepContent>
                        </Step>
                    ))}
                </Stepper>
                {this.state.activeStep === this.steps.length && (
                    <Paper square elevation={0} className={classes.resetContainer}>
                        <Typography>{message}</Typography>
                    </Paper>
                )}
            </div>
        );
    }

}

const mapStateToProps = (state) => {
    return {
        selectedPart: state.parts && state.parts.selectedPart ? state.parts.selectedPart : {},
        organization: state.auth.user ? state.auth.user.organization : undefined
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        setSelectedPart_action: (id) => dispatch(setSelectedPart(id)),
        partAdd_action: (formdata, history) => dispatch(partAdd(formdata, history)),
        partUpdate_action: (formdata, history) => dispatch(partUpdate(formdata, history)),
        emptySelectedPart_action: () => { dispatch(emptySelectedPart({})) },
        processInProgress_action: (status) => { dispatch(processInProgress(status)) }
    }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(withStyles(useStyles)(PartAdd)))