// ********Main imports**************
import React, { useEffect } from "react";
import PropTypes from "prop-types";

// ********Material ui imports**************

import TablePagination from "@material-ui/core/TablePagination";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Divider from "@material-ui/core/Divider";
import Fab from "@material-ui/core/Fab";
import cloneDeepWith from "lodash/cloneDeepWith";
import Container from '@material-ui/core/Container';
import { styled } from '@mui/material/styles';
import clsx from 'clsx';
import PerfectScrollbar from 'react-perfect-scrollbar';
import {
  Avatar,
  Box,
  Checkbox,
  Typography
} from '@mui/material';
import { getInitials } from './utils/get-initials';



// ********Component imports**************
import { connect } from "react-redux";
import TablePaginationActions from "./pd-pagination";
import { useStyles2 } from "../Styles/dahboardLayout_styles";
import {
  fetchProject
} from "../store/actions/project_action";
import {
  searchInProgress,
  getPartsData,
  getTotalPartsCount,
  totalPartsCount,
} from "../store/actions/part_action";
import {
  processInProgress,
  setSelectedClient,
} from "../store/actions/misc_action";
import color from "@material-ui/core/colors/amber";
import { Button,Modal,Form,Spinner,Alert } from 'react-bootstrap';
import {
  Card,
  CardActions,
  CardHeader,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableRow,
} from '@material-ui/core';
import TableHead from '@mui/material/TableHead';
import ArrowRightIcon from '@material-ui/icons/ArrowRight';
import Scrollbar from 'react-scrollbar';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { format } from 'date-fns';
const axios = require("axios");

const useStyles = theme => ({
  root: {},
  content: {
    padding: 0,
    marginTop:'100px'
  },
  inner: {
    minWidth: 350,
    overflow: 'auto',
    height: 350,
  },
  statusContainer: {
    display: 'flex',
    alignItems: 'center'
  },
  status: {
    marginRight: theme.spacing(1)
  },
  actions: {
    justifyContent: 'flex-end'
  }
});

function ClientProLayoutList(props) {
  const {
    clientsarray,
    fetchClients_action,
    privilege,
    selectedClient,
    client,
    clientList,
    className, 
    project,
    fetchprojects_action,
    ...rest
  } = props;


  console.log("silna surendran",props);
  const classes = useStyles2();
  const [page, setPage] = React.useState(0);
  const [searchValue, setsearchValue] = React.useState("");

  //
  const [open, setIsOpen] = React.useState("");
  const [show, setshowFile] = React.useState(null);
  const [file, setFile] = React.useState(null);
  const [isButtonHidden, setisButtonHidden] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const [messageText,setmessageText]= React.useState("");
  const [isFile, setisFile] = React.useState(false);
  const [datax, setdatax] = React.useState("...");
  

  const [rowsPerPage, setRowsPerPage] = React.useState(4);
  const [clients, setClients] = React.useState(client);
  //called First time when component mounts and every other time when part add is called


  //create REF to call child function from parent
  const child = React.createRef();

  const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    width:'200px',
    height:'200px',
    color: theme.palette.text.secondary,

  }));

  const [selectedCustomerIds, setSelectedCustomerIds] = useState([]);
  const [limit, setLimit] = useState(10);

  const handleSelectAll = (event) => {
    let newSelectedCustomerIds;

    if (event.target.checked) {
      newSelectedCustomerIds = clientsarray.map((client) => client.id);
    } else {
      newSelectedCustomerIds = [];
    }

    setSelectedCustomerIds(newSelectedCustomerIds);
  };

  const handleSelectOne = (event, id) => {
    const selectedIndex = selectedCustomerIds.indexOf(id);
    let newSelectedCustomerIds = [];

    if (selectedIndex === -1) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds, id);
    } else if (selectedIndex === 0) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds.slice(1));
    } else if (selectedIndex === selectedCustomerIds.length - 1) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(
        selectedCustomerIds.slice(0, selectedIndex),
        selectedCustomerIds.slice(selectedIndex + 1)
      );
    }

    setSelectedCustomerIds(newSelectedCustomerIds);
    console.log("newSelectedCustomerIds ",newSelectedCustomerIds[0],newSelectedCustomerIds.length);
    fetchprojects_action();
  };

  const handleLimitChange = (event) => {
    setLimit(event.target.value);
  };

  const handlePageChange = (event, newPage) => {
    setPage(newPage);
  };

  //Pagination function
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  //Pagination function
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };


  // {/* Searchbar with camera icon button */}
  return (
<Box
      sx={{
        display: 'flex',
        '& > :not(style)': {
          m: 1,
         
        },
        marginTop:'20px'
      }}
    >
    {console.log("project name",project.name)}
    <Paper elevation={3}{...rest}>
      <PerfectScrollbar>
        <Box sx={{ minWidth: 400 }}>
          <Table>
            <TableHead sx={{ backgroundColor: 'whitesmoke' }}>
              <TableRow>
                <TableCell padding="checkbox">
                  <Checkbox
                    checked={selectedCustomerIds.length === clientsarray.length}
                    color="primary"
                    indeterminate={
                      selectedCustomerIds.length > 0
                      && selectedCustomerIds.length < clientsarray.length
                    }
                    onChange={handleSelectAll}
                  />
                </TableCell>
                <TableCell>
                  ClientName
                </TableCell>
                
              </TableRow>
            </TableHead>
            <TableBody>
              {clientsarray.slice(0, limit).map((client) => (
                <TableRow
                  hover
                  key={client.id}
                  selected={selectedCustomerIds.indexOf(client.id) !== -1}
                >
                  <TableCell padding="checkbox">
                    <Checkbox
                      checked={selectedCustomerIds.indexOf(client.id) !== -1}
                      onChange={(event) => handleSelectOne(event, client.id)}
                      value="true"
                    />
                  </TableCell>
                  <TableCell>
                    <Box
                      sx={{
                        alignItems: 'center',
                        display: 'flex'
                      }}
                    >
                      <Avatar
                        src={client.avatarUrl}
                        sx={{ mr: 2 }}
                      >
                        {getInitials(client.clientName)}
                      </Avatar>
                      <Typography
                        color="textPrimary"
                        variant="body1"
                      >
                        {client.clientName}
                      </Typography>
                    </Box>
                  </TableCell>
                 
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      </PerfectScrollbar>
      <TablePagination
        component="div"
        count={clientsarray.length}
        onPageChange={handlePageChange}
        onRowsPerPageChange={handleLimitChange}
        page={page}
        rowsPerPage={limit}
        rowsPerPageOptions={[5, 10, 25]}
      />
      </Paper>
      <Paper elevation={3}>
       <PerfectScrollbar>
        <Box sx={{ minWidth: 400 }}>
          <Table>
            <TableHead sx={{ backgroundColor: 'whitesmoke' }}>
              <TableRow>
                <TableCell>
                  ProjectList
                </TableCell>
                
              </TableRow>
            </TableHead>
            <TableBody>
              {project.slice(0, limit).map((proj) => (
                <TableRow
                  hover
                  key={proj.projectId}
                  selected={selectedCustomerIds.indexOf(proj.projectId) !== -1}
                >
                 
                  <TableCell>
                    <Box
                      sx={{
                        alignItems: 'center',
                        display: 'flex'
                      }}
                    >
                     
                      <Typography
                        color="textPrimary"
                        variant="body1"
                      >
                        
                      {proj.name}
                      </Typography>
                    </Box>
                  </TableCell>
                 
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Box>
      </PerfectScrollbar>
     
      
    </Paper>
    </Box>
  );
}

ClientProLayoutList.propTypes = {
  selectedClient: PropTypes.string,
  client: PropTypes.string,
  clientList: PropTypes.any,
  clientsarray:PropTypes.array,
  fetchClients:PropTypes.func,
  fetchprojects_action:PropTypes.func,
  project: PropTypes.array
};

const mapStateToProps = (state) => {
  return {
    selectedClient: state.misc.selectedClient
      ? state.misc.selectedClient
      : undefined,
    clientList: state.misc.clients,
    project:state.project.projects
   
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    searchProgress_action: (status) => dispatch(searchInProgress(status)),
    processInProgress_action: (status) => dispatch(processInProgress(status)),
    setSelectedClient_action: (client) => dispatch(setSelectedClient(client)),
    fetchprojects_action:()=>dispatch(fetchProject()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ClientProLayoutList);
