import {
    Button,
    Icon,
    Grid,
    Radio,
    RadioGroup,
    ValidatorFormControlLabel,
    Checkbox,
    Box,
    Card
} from '@mui/material'
import React, { useState, useEffect, useRef } from "react";
import {useHistory} from 'react-router-dom';
import InputLabel from '@mui/material/InputLabel';
import { styled } from '@mui/system'
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import MenuItem from '@mui/material/MenuItem';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Select from '@mui/material/Select';
import CancelIcon from '@mui/icons-material/Cancel';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import DeleteIcon from '@mui/icons-material/Delete';
import CheckIcon from '@mui/icons-material/Check';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import BackspaceIcon from '@mui/icons-material/Backspace';
import {
    fetchClients
} from "../store/actions/client_action";
import { processInProgress } from '../store/actions/misc_action';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import {fetchLocation,addLocation, fetchLocationById,updateLocation,deleteLocation} from '../store/actions/location_action';
import countries from './utils/countries.json';


const TextInput = styled(TextField)(() => ({
    width: '100%',
    marginBottom: '16px',
}))

const CustomSelect = styled(Select)(() => ({
    width: '100%',
    marginBottom: '16px',
}))

const defaultError = {
    name: '',
    client:'',
    officeName: '',
    address1: '',
    address2:'',
    city:'',
    state:'',
    country:'',
    pinCode:''
}

const defaultLocation = {
    name: '',
    client:{},
    officeName: '',
    address1: '',
    address2:'',
    city:'',
    state:'',
    country:[],
    pinCode:'',
    isDelete:false  
}

const fieldRequiredText = 'This field is required';

const LocationAdd = (props) => {
    const { fetchClients_action, addLocation_action, locations, clientsarray, email,fetchLocationById_action,deleteLocation_action,updateLocation_action} = props;
    const history = useHistory();
    const [errors, setErrors] = useState({...defaultError});
    const [location, setLocation] = useState({...defaultLocation});
    const [date, setDateValue] = useState('');
    const [isEditPage,setIsEditPage] = useState(false);
    const [isModalOpen,setIsModalOpen] = useState(false);
    const [isEdit, setIsEdit] = useState(false);
    const [country,setCountry] = useState([]);
    const locationRef = useRef(null);
    
    useEffect(() => {
        setCountry(countries);
        fetchClients_action();
    }, [])

    useEffect(() => {
        const pathData = history.location.pathname.split('/');
        if(pathData[2] === 'edit') {
            setIsEditPage(true);
            fetchLocationById_action(pathData[3])
            .then(res => {
                setLocation({...res});
                console.log('res', res)
                locationRef.current = {...res};
            })
            .catch(err => {
                console.log(err);
            })
        }
    }, [])

    const getDate = () => {
        let today = new Date();
        let date = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();
        setDateValue(date);
    };

    const validateData = (data) => {
        const errorProxy = {...errors};
        let valid = true;
        Object.keys(defaultError).forEach(itemKey => {
            errorProxy[itemKey] = !data[itemKey] ? fieldRequiredText : '';
        })
        errorProxy.name = !data.name ? fieldRequiredText : validateName(data.name) ? '' : 'Name should minimum be 4-15 characters';
        setErrors(errorProxy)
        Object.values(errorProxy).forEach(item => {
            if(item && valid) {
                valid = false
            }
        })
        return valid;
    }

    const validateName = (name) =>
    {
        if(name.length< 4 || name.length > 15)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    const handleClear = (event) => {
        event.preventDefault();
        setLocation({...defaultLocation});
    }

    const handleBack = () => {
        history.goBack();
    }

    const handleDelete = () => {
        deleteLocation_action(location)
        .then(() => {
            history.goBack();
        })
        .catch(err => {
            console.log(err);
        })
    }

    const handleCancel = (event) => {
        event.preventDefault();
        history.goBack();
    }

    const  handleEdit = () => {
        setIsEdit(!isEdit);
        if(isEdit) {
            setLocation({...locationRef.current});
            setErrors({...defaultError})
        }
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log("handlesubmit",location);
        if(validateData(location)) {
            if(isEditPage) {
                updateLocation_action(location)
                .then(() => {
                    setLocation({...defaultLocation});
                    history.goBack();
                })
                .catch(err => {
                    console.log(err);
                })
            } else {
                addLocation_action(location)
                .then(() => {
                    setLocation({...defaultLocation});
                    history.goBack();
                })
                .catch((error) =>{
                    if(error && error.statusCode === 409)
                    {
                       if(error.statuskey === "Nexist")
                       {
                           setErrors({...errors, name: "Location Name already exist" });
                       }
                    }
                })
            }  
            }
        else{
            console.log("Handlesubmit error");
        }
    }

    const handleChange = (key) => (event) => {
        if(key === 'client')
        {
            const clientData = clientsarray.find(item => item.id === event.target.value);
            setLocation({...location, [key]:{id:clientData.id,name:clientData.clientName}}) 
        }
        else
        {
        setLocation({...location, [key]:event.target.value})   
        }     
    }

    return (
        <div>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
                marginTop:'50px'
              }}
            >
              <Typography
                sx={{ m: 1,color:'#19b4dd',fontWeight: 600 }}
                variant="h4"
              >
                {!isEditPage ? "Add Location" : "Edit Location"}
              </Typography>
              <Button onClick={handleBack} style={{color:"#19b4dd",mr: 1}} variant="outlined" startIcon={<ArrowBackIcon />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Go Back
                    </Typography>
                </Button>
            </Box>
            <Box
            sx={{
            display: 'flex',
            '& > :not(style)': {
             m: 1, 
             },
            marginTop:'20px'
            }}
            >
            <Card style={{padding: '0 25px 25px'}} sx={{marginTop:'30px'}}>
                <Grid container spacing={6}>
                    <Grid item lg={6} md={6} sm={12} xs={12} sx={{ mt: 5 }}>
                        <TextInput
                            type="text"
                            name="name"
                            onChange={handleChange('name')}
                            disabled = {isEditPage && !isEdit}
                            label="Location Name (Min length 4, Max length 15)"
                            error={!!errors.name}
                            helperText={errors.name}
                            value={location.name}
                        />
                        <TextInput
                            type="text"
                            name="officeName"
                            onChange={handleChange('officeName')}
                            disabled = {isEditPage && !isEdit}
                            label="Building Number"
                            error={!!errors.officeName}
                            helperText={errors.officeName}
                            value={location.officeName}
                        />
                        <TextInput
                            label="Address 1"
                            onChange={handleChange('address1')}
                            disabled = {isEditPage && !isEdit}
                            type="text"
                            name="address1"
                            error={!!errors.address1}
                            helperText={errors.address1}
                            value={location.address1}
                        />
                        <TextInput
                            label="Address 2"
                            onChange={handleChange('address2')}
                            disabled = {isEditPage && !isEdit}
                            type="text"
                            name="address2"
                            error={!!errors.address2}
                            helperText={errors.address2}
                            value={location.address2}
                        />
                         <TextInput
                            label="City"
                            onChange={handleChange('city')}
                            disabled = {isEditPage && !isEdit}
                            type="text"
                            name="city"
                            error={!!errors.city}
                            helperText={errors.city}
                            value={location.city}
                        />
                        <TextInput
                            label="State/Province"
                            onChange={handleChange('state')}
                            disabled = {isEditPage && !isEdit}
                            type="text"
                            name="state"
                            error={!!errors.state}
                            helperText={errors.state}
                            value={location.state}
                        />
                       <InputLabel id="demo-simple-select-label">Country</InputLabel>
                        <CustomSelect
                            value={location.country}
                            disabled = {isEditPage && !isEdit}
                            label="Country"
                            multiple
                            onChange={handleChange('country')}
                        >
                            {countries.map(item => 
                                <MenuItem value={item.code}>{item.name}</MenuItem>
                            )}
                            </CustomSelect>
                        <TextInput
                            label="Pin Code"
                            disabled = {isEditPage && !isEdit}
                            onChange={handleChange('pinCode')}
                            type="number"
                            name="pinCode"
                            error={!!errors.pinCode}
                            helperText={errors.pinCode}
                            value={location.pinCode}
                        />
                        <InputLabel id="demo-simple-select-label">Client</InputLabel>
                        <CustomSelect
                            value={location.client?.id || ''}
                            disabled = {isEditPage && !isEdit}
                            label="Client"
                            onChange={handleChange('client')}
                            error={!!errors.client}
                        >
                            {clientsarray && clientsarray.map(item => 
                                <MenuItem key={item.id} value={item.id}>{item.clientName}</MenuItem>
                            )}
                        </CustomSelect>
                    </Grid>
                </Grid>
                <Box
                        sx={{
                            display: 'flex',
                            justifyContent: 'flex-end',
                            p: 2
                        }}
                         >
                        {!isEditPage ?
                        <>
                        <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" type="submit" onClick={handleSubmit} startIcon={<AddCircleIcon  />}>
                        
                            <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                                Add
                            </Typography>
                        </Button>
                        <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" type="submit" onClick={handleClear} startIcon={<BackspaceIcon  />}>
                            <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                                Clear
                            </Typography>
                        </Button>
                        <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" type="submit" onClick={handleCancel} startIcon={<CancelIcon  />}>
                            <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                                Cancel
                            </Typography>
                        </Button>
                        </> :
                        <>
                        <Button onClick={handleEdit} style={{color:"#19b4dd",mr: 1}}  variant="outlined" startIcon={!isEdit ? <EditIcon /> : <CancelIcon/>}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        {!isEdit ? "Edit" : "Cancel"}
                    </Typography>
                </Button>
                {isEdit &&
                    <Button onClick={handleSubmit} style={{color:"#19b4dd",mr: 1}}  variant="outlined" startIcon={<SaveIcon />}>
                        <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                            Save
                        </Typography>
                    </Button>
                }
                <Button onClick={() => setIsModalOpen(true)} style={{color:"#19b4dd",mr: 1}} variant="outlined" startIcon={<DeleteIcon />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Delete
                    </Typography>
                </Button>
                        </>
                }
                        </Box>
            </Card>
            </Box>
            <Dialog onClose={() => setIsModalOpen(false)} open={isModalOpen}>
              <DialogTitle>Alert</DialogTitle>
              <DialogContent style={{paddingTop: '20px'}}>
                Are you sure ,you want to delete the client?
              </DialogContent>
              <DialogActions>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={handleDelete} startIcon={<CheckIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Confirm
                    </Typography>
                </Button>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={() => setIsModalOpen(false)} startIcon={<CancelIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Cancel
                    </Typography>
                </Button>
              </DialogActions>
            </Dialog>
        </div>
    )
}

LocationAdd.propTypes = {
    selectedClient: PropTypes.string,
    clientsarray: PropTypes.array,
    fetchClients_action: PropTypes.func,
    addLocation_action:PropTypes.func,
    processInProgress_action: PropTypes.func,
    email: PropTypes.string,
    updateLocation_action: PropTypes.func,
    deleteLocation_action: PropTypes.func
}

const mapStateToProps = (state) => {
    console.log("state of clients",state);
    return {
        privilege: state.auth && state.auth.user ? state.auth.user.access : undefined,
        clientsarray: state.client.value,
        location: state.location.locations,
        email: state.auth.user ? state.auth.user.email : undefined,
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        processInProgress_action: (status) => dispatch(processInProgress(status)),
        fetchLocation_action: () => dispatch(fetchLocation()),
        fetchClients_action: () => dispatch(fetchClients()),
        addLocation_action: (location) => dispatch(addLocation(location)),
        fetchLocationById_action: (id) => dispatch(fetchLocationById(id)),
        updateLocation_action:(location) => dispatch(updateLocation(location)),
        deleteLocation_action:(location) => dispatch(deleteLocation(location))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(LocationAdd);

