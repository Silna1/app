import React from 'react';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import IconButton from '@material-ui/core/IconButton';
import OpenInNew from '@material-ui/icons/OpenInNew';

import { useStyles } from '../Styles/partgrid_styles'
import Modal from './pd-modal';
import PartProfileView from './pd-part-profile-view';

export default function PredictedParts(props) {

    const classes = useStyles();

    return (
        <Grid item xs={12} sm={6} lg={4}>
            <Card className={classes.card}>
                <Grid item xs={6} sm={6} lg={6}>
                    <CardContent className={classes.content}>
                        <Typography noWrap={true} component="h5" variant="h5">
                            {props.predictionData.partName}
                        </Typography>
                        <Typography noWrap={true} variant="subtitle1" color="textSecondary">
                            Material : {props.predictionData.material}
                        </Typography>
                        <Typography variant="subtitle1" color="textSecondary">
                            Complexity : {props.predictionData.complexity}
                        </Typography>
                        {props.predictionData.imageSrc !== "./images/notfound.png" &&
                            <div className={classes.controls}>
                                <Modal buttonObj={<IconButton size="small" aria-label="Play/pause" className={"MuiButton--readMore"} ><OpenInNew className={classes.playIcon} /></IconButton>}>
                                    <PartProfileView partId={props.predictionData.id}></PartProfileView>
                                </Modal>
                            </div>
                        }
                    </CardContent>
                </Grid>
                <CardMedia
                    className={classes.cover}
                    image={props.predictionData.imageSrc}
                />
            </Card>
        </Grid>
    )
}
