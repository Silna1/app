import React, { Component } from 'react';
import { config } from '../config';
import { FetchAPI } from '../fetch';

var Autodesk;
var element;
var viewerApp;
var _self;

export class ForgeViewer extends Component {
    render() {
        _self = this;
        _self.urn = this.props.modelUrn;
        Autodesk = Window.Autodesk;
        return (
            <div id="viewerDiv"></div>
        );
    }

    componentDidMount() {
        this.launchViewer();
    }

    componentWillUnmount() {
        if (element) {
            element.innerHTML = '';
        }
    }

    _launchViewer(token, urn) {
        var options = {
            env: 'AutodeskProduction',
            accessToken: token.access_token
        };
        element = document.getElementById('viewerDiv');
        var documentId = 'urn:' + urn;
        Autodesk.Viewing.Initializer(options, function onInitialized() {
            Autodesk.Viewing.Document.load(documentId, _self._onDocumentLoadSuccess);
        });
    }

    _onDocumentLoadSuccess(doc) {
        // Choose any of the avialble viewables
        var viewables = Autodesk.Viewing.Document.getSubItemsWithProperties(doc.getRootItem(), { 'type': 'geometry' }, true);
        if (viewables.length === 0) {
            console.error('Document contains no viewables.');
            return;
        }

        var initialViewable = viewables[0];
        var svfUrl = doc.getViewablePath(initialViewable);
        var modelOptions = {
            sharedPropertyDbPath: doc.getPropertyDbPath()
        };
        viewerApp = new Autodesk.Viewing.Private.GuiViewer3D(element);
        viewerApp.start(svfUrl, modelOptions, _self._onItemLoadSuccess, _self.onItemLoadFail);
    }

    _onItemLoadSuccess() {
        console.log("viewer Success");
    }

    onItemLoadFail(errorCode) {
        console.error('onItemLoadFail() - errorCode:' + errorCode);
    }

    launchViewer = () => {
        const fileurl = config.HostURL + "/viewer/token";
        FetchAPI.get(fileurl)
            .then((token) => {
                const fileurl = config.HostURL + "/viewer/getTranslationProgress";
                let data = {
                    urn: _self.urn
                }
                FetchAPI.postData(fileurl, data)
                    .then((result) => {
                        if (result.body.status === 'success')
                            _self._launchViewer(token, _self.urn);
                        else
                            console.log("viewer initialization failed");
                    }).catch(err => {
                        console.log("err", err);
                    });
            })
            .catch((error) => {
                console.log(error);
            });
    }
}

export function downloadFile(uid, fileName) {
    return new Promise(async (resolve, reject) => {
        try {
            let data = {
                uid: uid,
                name: fileName
            }
            const fileurl = config.HostURL + "/viewer/downloadFile";
            let dataLink = await FetchAPI.postData(fileurl, data);
            if (dataLink.url) {
                window.location.href = dataLink.url;
            }
            resolve();
        } catch (error) {
            reject(error);
        }
    })
}