// ********Main imports**************
import React, { useEffect, useMemo, useRef } from "react";
import PropTypes from "prop-types";
import {useHistory} from 'react-router-dom';

// ********Material ui imports**************

import TablePagination from "@material-ui/core/TablePagination";
import Paper from "@material-ui/core/Paper";
import { styled } from '@mui/material/styles';
import Grid from '@material-ui/core/Grid';
import PerfectScrollbar from 'react-perfect-scrollbar';
import {
  Avatar,
  Box,
  Checkbox,
  Typography,
  Button
} from '@mui/material';
import { getInitials } from './utils/get-initials';
import CustomTable from './utils/Table';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import CheckIcon from '@mui/icons-material/Check';
import CancelIcon from '@mui/icons-material/Cancel';

// ********Component imports**************
import { connect } from "react-redux";
import TablePaginationActions from "./pd-pagination";
import { useStyles2 } from "../Styles/dahboardLayout_styles";
import {
  fetchClients,
  deleteClient,
  addClient,
  updateClient,
} from "../store/actions/client_action";
import {
  processInProgress,
  setSelectedClient,
} from "../store/actions/misc_action";
import {
  Card,
  CardActions,
  CardHeader,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableRow,
} from '@material-ui/core';
import {fetchLocation, fetchClientLocation, deleteLocation} from '../store/actions/location_action';
import TableHead from '@mui/material/TableHead';
import { useState } from 'react';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import VisibilityIcon from '@material-ui/icons/Visibility';
import ButtonGroup from '@mui/material/ButtonGroup';
const axios = require("axios");

const useStyles = theme => ({
  root: {},
  content: {
    padding: 0,
    marginTop:'100px'
  },
  inner: {
    minWidth: 350,
    overflow: 'auto',
    height: 350,
  },
  statusContainer: {
    display: 'flex',
    alignItems: 'center'
  },
  status: {
    marginRight: theme.spacing(1)
  },
  actions: {
    justifyContent: 'flex-end'
  }
});

const CustomSelect = styled(Select)(() => ({
  width: '100%',
  marginBottom: '16px',
}))

function ClientLocLayoutList(props) {
  const {
    fetchClients_action,
    fetchLocation_action,
    fetchClientLocation_action,
    deleteLocation_action,
    clientLocations,
    privilege,
    selectedClient,
    client,
    clientList,
    className,
    location, 
    ...rest
  } = props;


  console.log("silna surendran",props);
  const classes = useStyles2();
  const history = useHistory();
  const [page, setPage] = React.useState(0);
  const [searchValue, setsearchValue] = React.useState("");

  //
  const [open, setIsOpen] = React.useState("");
  const [show, setshowFile] = React.useState(null);
  const [file, setFile] = React.useState(null);
  const [isButtonHidden, setisButtonHidden] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const [messageText,setmessageText]= React.useState("");
  const [isFile, setisFile] = React.useState(false);
  const [datax, setdatax] = React.useState("...");
  

  const [rowsPerPage, setRowsPerPage] = React.useState(4);
  const [clients, setClients] = React.useState(client);
  const [tableData, setTableData] = React.useState([]);
  const [isModalOpen,setIsModalOpen] = useState(false);
  const locationRef = useRef(null);
  //called First time when component mounts and every other time when part add is called


  //create REF to call child function from parent
  const child = React.createRef();

  const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
    width:'1250px'

  }));

  useEffect(() => {
    fetchLocation_action();
    fetchClientLocation_action();
  }, [])

  useEffect(() => { 
      setTableData(location);
  }, [location])

  const actionContainer = (cell, i, row) => {
    return (
      <ButtonGroup variant="outlined" aria-label="outlined primary button group">
        <EditIcon onClick={() => handleEdit(cell.value)} className={classes.icons} color='inherit'/>
        <DeleteIcon onClick={() => handledeleteModal(row.original)} className={classes.icons} color='inherit' />
      </ButtonGroup>
    )
  }

  

  const columnData = useMemo(() => [
    {
      header: "Location Name",
      accessor: "name",
      width: 20
    },
    {
      header: "Location Address",
      accessor: "address1",
      width: 35
    },
    {
      header: "Client Name",
      accessor: "client.name",
      width: 20
    },
    {
      header: "",
      accessor: "id", //action
      templateFn: actionContainer,
      width: 15
    }
  ], [])



  const [selectedCustomerIds, setSelectedCustomerIds] = useState([]);
  const [limit, setLimit] = useState(10);

 

  const handleSelectOne = (event, id) => {
    const selectedIndex = selectedCustomerIds.indexOf(id);
    let newSelectedCustomerIds = [];

    if (selectedIndex === -1) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds, id);
    } else if (selectedIndex === 0) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds.slice(1));
    } else if (selectedIndex === selectedCustomerIds.length - 1) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(selectedCustomerIds.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelectedCustomerIds = newSelectedCustomerIds.concat(
        selectedCustomerIds.slice(0, selectedIndex),
        selectedCustomerIds.slice(selectedIndex + 1)
      );
    }

    setSelectedCustomerIds(newSelectedCustomerIds);
  };

  const handleLimitChange = (event) => {
    setLimit(event.target.value);
  };

  const handlePageChange = (event, newPage) => {
    setPage(newPage);
  };

  //Pagination function
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  //Pagination function
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleView = (event, newPage) => {
    setPage(newPage);
  };

  const handleEdit = (id) => {
    history.push(`/location/edit/${id}`);
  };

  const handleDelete = () => {
    deleteLocation_action(locationRef.current)
    setIsModalOpen(false);
    locationRef.current = null;
  };

  const handledeleteModal = (location) =>{
    setIsModalOpen(true);
    locationRef.current = location;
  }

  // {/* Searchbar with camera icon button */}
  return (
    <>
    <Box
      sx={{
        display: 'flex',
        '& > :not(style)': {
          m: 1,
         
        },
        marginTop:'20px'
      }}
      style={{width: "100%"}}
    >
      <CustomTable 
        columns={columnData}
        data={tableData}
      />  
    </Box>
    <Dialog onClose={() => setIsModalOpen(false)} open={isModalOpen}>
              <DialogTitle>Alert</DialogTitle>
              <DialogContent style={{paddingTop: '20px'}}>
                Are you sure ,you want to delete the client?
              </DialogContent>
              <DialogActions>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={handleDelete} startIcon={<CheckIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Confirm
                    </Typography>
                </Button>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={() => setIsModalOpen(false)} startIcon={<CancelIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Cancel
                    </Typography>
                </Button>
              </DialogActions>
            </Dialog>
    </>
  );
}

ClientLocLayoutList.propTypes = {
  selectedClient: PropTypes.string,
  client: PropTypes.string,
  clientList: PropTypes.any,
  fetchClients:PropTypes.func,
  deleteLocation_action: PropTypes.func
};

const mapStateToProps = (state) => {
  return {
    selectedClient: state.misc.selectedClient
      ? state.misc.selectedClient
      : undefined,
    clientList: state.misc.clients,
    location:state.location.locations,
    clientLocations: state.location.clientLocations
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    processInProgress_action: (status) => dispatch(processInProgress(status)),
    fetchLocation_action: () => dispatch(fetchLocation()),
    fetchClientLocation_action: () => dispatch(fetchClientLocation()),
    deleteLocation_action: (location) => dispatch(deleteLocation(location))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ClientLocLayoutList);
