import React from 'react';
import SwipeableViews from 'react-swipeable-views';
import { useTheme } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import CloudUpload from '@material-ui/icons/CloudUpload';
import Settings from '@material-ui/icons/Settings';

import Training from './pd-training'
import BatchUpload from './pd-batch-upload';
import TabPanel from './pd-tab'

function setProps(index) {
  return {
    id: `full-width-tab-${index}`,
    'aria-controls': `full-width-tabpanel-${index}`,
  };
}

export default function AdminSettings() {
  const theme = useTheme();
  const [value, setValue] = React.useState(0);

  function handleChange(event, newValue) {
    setValue(newValue);
  }

  function handleChangeIndex(index) {
    setValue(index);
  }

  return (
    <Paper style={{ marginTop: '54px' }}>
      <Tabs
        style={{ backgroundColor: '#e6efff' }}
        value={value}
        onChange={handleChange}
        indicatorColor="primary"
        textColor="primary"
        variant="fullWidth"
        centered
      >
        <Tab label="Batch Upload" icon={<CloudUpload />} {...setProps(0)} />
        <Tab label="Traning Model" icon={<Settings />} {...setProps(1)} />
      </Tabs>
      <SwipeableViews
        axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
        index={value}
        onChangeIndex={handleChangeIndex}
      >
        <TabPanel value={value} index={0} dir={theme.direction}>
          <BatchUpload></BatchUpload>
        </TabPanel>
        <TabPanel value={value} index={1} dir={theme.direction} style={{ textAlign: 'center' }}>
          <Training></Training>
        </TabPanel>
      </SwipeableViews>
    </Paper>
  );
}