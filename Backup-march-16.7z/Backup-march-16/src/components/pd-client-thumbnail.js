import React, { Component } from "react";
import Card from "@material-ui/core/Card";
import CardMedia from "@material-ui/core/CardMedia";
import CardContent from "@material-ui/core/CardContent";
import Typography from "@material-ui/core/Typography";
import Tooltip from '@material-ui/core/Tooltip';
import { withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import { Divider } from "@material-ui/core";

class ThumbnailClient extends Component {

    redirect = () => {
        this.props.history.push(this.props.clientsarray.clientId + "/Clientview");
    }

    render() {
        const { clientsarray } = this.props;
        return (
            <Card className={"MuiReviewCard--01"} onClick={this.redirect} style={{margin:20}}>
                <CardMedia
                    component={"img"}
                    className={"MuiCardMedia-root"}
                    src={clientsarray.signedUrls}
                />
                <Tooltip title={clientsarray.clientName}>
                    <CardContent className={"MuiCardContent-root"}>
                        <div className={"ContentHead"}>
                            <Typography
                                className={"MuiTypography--heading"}
                                variant={"overline"}
                                display="block"
                                gutterBottom
                                noWrap
                            >
                                {clientsarray.clientName}
                            </Typography>
                        </div>
                        <Divider/>
                        <Typography variant="overline" display="block"   color={"textPrimary"} gutterBottom noWrap>
                            Email: {clientsarray.email}
                        </Typography>
                        <Divider/>
                        <Typography variant="overline" display="block"  color={"textPrimary"} gutterBottom noWrap>
                            PhoneNumber : {clientsarray.phoneNumber}
                        </Typography>
                        <Divider/>
                    </CardContent>
                </Tooltip>
            </Card>
        );
    }
}

ThumbnailClient.propTypes = {
    clientsarray: PropTypes.object,
    history: PropTypes.any
}

export default withRouter(ThumbnailClient);

