import React, { Component } from "react";
import PartDetails from './pd-part-details';
import ImageUploader from './pd-file-upload';
import StlUploader from './pd-stl-upload';
import cloneDeepWith from 'lodash/cloneDeepWith';

class VerticalStepper extends Component {

    constructor(props) {
        super(props);
        this.state = {
            newParts: props.partData,
        }
        this.PartData = cloneDeepWith(this.state.newParts);
    }


    stlToUpload = () => {
        let cadFile = [];
        if (this.state.newParts.filesToUpload && this.state.newParts.filesToUpload.length > 0) {
            cadFile = this.state.newParts.filesToUpload;
        } else if (this.state.newParts.filesPath) {
            cadFile.push(this.state.newParts.filesPath);
        }
        return cadFile;
    }

    partDataHandler = (obj) => {
        let key = Object.keys(obj)[0];
        for (let {} in Object.keys(obj)) {
            this.PartData[key] = obj[key];
        }
        this.setState({ newParts: cloneDeepWith(this.PartData) });
        this.props.partDataHandler(obj);
    }

    imagesToUpload = () => {
        let images = [];
        let count = 0;
        //used every other time except first time
        if (this.state.newParts.imagesToUpload && this.state.newParts.imagesToUpload.length > 0) {
            return this.state.newParts.imagesToUpload;
        }
        // for all already saved image deleted.
        if( this.state.newParts.removedImages && this.state.newParts.signedUrls.length ===  this.state.newParts.removedImages.length){
            return images;
        }
        //for first time take images from selectedPart
        if (this.state.newParts.signedUrls ) {
            this.state.newParts.signedUrls.forEach(element => {
                images.push({ 'id': count++, 'file': element.url });
            });
        }
        return images;
    }

    render() {
        return (
            this.props.step === 0 ?
                <PartDetails
                    partData={this.props.partData}
                    partdataHandler={obj => this.partDataHandler(obj)}
                />
                : this.props.step === 1 ?
                    <div style={{ textAlign: "center" }}>
                        <ImageUploader
                            partdataHandler={obj => this.partDataHandler(obj)}
                            filesToShow={this.imagesToUpload()}
                            input='image/jpeg,image/jpg,image/png' />
                    </div>
                    : this.props.step === 2 ?
                        <div style={{ textAlign: "center" }}>
                            <StlUploader
                                fileName="filesToUpload"
                                filesToShow={this.stlToUpload()}
                                partdataHandler={obj => this.partDataHandler(obj)}
                            />
                        </div>
                        : <p>Unknown step</p>
        );
    }
}

export default VerticalStepper;