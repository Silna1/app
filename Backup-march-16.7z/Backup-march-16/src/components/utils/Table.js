import React, {useState, useEffect} from 'react';
import {makeStyles} from "@material-ui/styles";
import { useTable, useSortBy, useExpanded } from 'react-table';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const useStyles = makeStyles(() => ({
    tableRoot: {
        width: '100%',
    },
    tableRow: {
        borderBottom: '1px solid #ddd'
    }
}));

const Table = (props) => {
    const { columns, data, sorted, renderRowSubComponent } = props;
    const classes = useStyles();
    const [sortedCol, setsortedCol] = useState(sorted?.sort_by);

    const handleSorting = () => {

    };

    const handleRowClick = () => {

    }

    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        rows,
        prepareRow,
        visibleColumns,
    } = useTable({ columns, data }, useSortBy, useExpanded);

    return (
        <>
            <table className={classes.tableRoot} {...getTableProps()}>
                <thead>
                    {headerGroups.map(headerGroup => (
                        <tr {...headerGroup.getHeaderGroupProps()}>
                            {headerGroup.headers.map(column => (
                                <th
                                    {...column.getHeaderProps()}
                                    style={{
                                        background: '#eee',
                                        color: '#000',
                                        fontWeight: '400',
                                        padding: 10,
                                        fontSize: '13px',
                                        cursor: 'pointer',
                                        width: column.width ? `${column.width}%` : 'min-content',
                                        margin: '0 auto',
                                    }}
                                    onClick={(e) =>handleSorting(e, column)}
                                >
                                    <div
                                        style={{  
                                            fontSize: '13px',
                                            margin: '0',
                                            padding:'0',
                                        }}
                                    >{column.render('header')}</div> {/* temporary */}
                                    <span>
                                        {column.id === sortedCol && sorted
                                ? sorted.sort_order === 'asc'
                                    ?  <ExpandLessIcon /> : <ExpandMoreIcon />
                                : ''}
                                    </span>
                                </th>
                            ))}
                        </tr>
                    ))}
                </thead>
                <tbody {...getTableBodyProps()}>
                    {rows.map(row => {
                        prepareRow(row)
                        return (
                            <>
                            <tr {...row.getRowProps()} className={classes.tableRow}>
                                {row.cells.map((cell, i) => {
                                    return (
                                        <td 
                                            onClick={() => handleRowClick(row, cell)}
                                            {...cell.getCellProps()}
                                            style={{
                                                padding: '10px',
                                                margin: '0 auto',
                                                fontSize: '13px',
                                                border: '0px',
                                                width: columns[i].width ? `${columns[i].width}%` : 'min-content',
                                            }}
                                        >
                                            <div
                                                style={{  
                                                    fontSize: '13px',
                                                    margin: '0',
                                                    padding:'0',
                                                }}
                                            >{columns[i].templateFn ? columns[i].templateFn(cell, i, row): cell.render('Cell')}
                                            </div>
                                        </td>
                                    )
                                })}
                            </tr>
                            {row.isExpanded ? (
                            <tr className="table-row-border">
                                <td
                                    colSpan={visibleColumns.length}
                                    style={{
                                        padding: '16px',
                                        margin: '0 auto',
                                        fontSize: '13px',
                                        border: '0px',
                                        background:'#ddd',
                                    }}
                                >
                                    {renderRowSubComponent && renderRowSubComponent({ row })}
                                </td>
                            </tr>
                        ) : null}
                        </>
                        )
                    })}
                </tbody>
            </table>
        </>
    )
}

export default Table;