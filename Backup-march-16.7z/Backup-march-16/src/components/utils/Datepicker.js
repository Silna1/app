import * as React from 'react';
import TextField from '@mui/material/TextField';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import DatePicker from '@mui/lab/DatePicker';
import { styled } from '@mui/system'

const TextInput = styled(TextField)(() => ({
    width: '100%',
    marginBottom: '16px',
}))

export default function BasicDatePicker(props) {
    const {onChange,value,label} = props;

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <DatePicker
        label= {label}
        value={value}
        onChange = {onChange}
        renderInput={(params) => <TextInput {...params} {...props}/>}
        
      />
    </LocalizationProvider>
  );
}
