import React from 'react'
import Grid from '@material-ui/core/Grid';
import Fab from '@material-ui/core/Fab';
import { connect } from 'react-redux'

import { processInProgress } from '../store/actions/misc_action'

import { config } from '../config'
import { FetchAPI } from '../fetch'
import PredictedParts from './pd-predicted-parts'
import PrintabilityScore from './pd-printability-score'
import { fetchMaterials } from '../store/actions/part_action'

class PartPrediction extends React.Component {

    state = {
        predictionResultArray: [],
        printabilityScoreDisplay: false
    }

    componentDidMount() {
        this.sentForPredict(this.props.imgdata);
        this.props.fetchMaterials_action();
    }

    sentForPredict = (files) => {
        //store.dispatch(progressLoader(true));
        let predictionArray = [];

        const formData = new FormData();
        for (let i = 0; i < files.length; i++) {
            formData.append("image" + i, files[i].file[0]);
        }
        //passing organization to filter predicted results i.e 
        //user will be shown his organization's and Immensalab's parts only
        formData.append("organization", this.props.organization);

        const url = config.HostAutomlURL + "/automl/predicts";

        FetchAPI.postFormData(url, formData)
            .then(async (ResultArray) => {
                console.log("result", ResultArray);
                const PartURL = config.HostURL + '/part/getpartbyid';
                let count = 0;

                for (let i = 0; i < ResultArray.length; i++) {
                    //We are going to show only 6 results, currently we automl server returns 10 predicted parts
                    //in predicted parts some parts can not be present in db
                    //we need to skip those and show first 6 parts with high precision
                    if (count === 6) {
                        break;
                    }
                    let predictionData = {};
                    let item = ResultArray[i];
                    const id = {
                        'id': item.key
                    }
                    predictionData["id"] = item.key;
                    predictionData["count"] = item.count;
                    predictionData["precision"] = item.HighestValue;
                    await FetchAPI.postData(PartURL, id)
                        .then(Result => {
                            if (Result && Result.Items) {
                                count++;
                                predictionData["imageSrc"] = Result.Items[0].signedUrls[0].url;
                                predictionData["partName"] = Result.Items[0].name;
                                predictionData["complexity"] = Result.Items[0].complexity;
                                predictionData["material"] = Result.Items[0].material;
                                predictionData["size"] = Result.Items[0].size;
                                predictionArray.push(predictionData);
                            } else {
                                console.log(Result.message); //Result.message = Requested Item fb9d2e32e94541c4924931b739ca88e9 is not present in database
                                //Do not delete below commented code
                                //count++;
                                // predictionData["imageSrc"] = "./images/notfound.png";
                                // predictionData["partName"] = 'Matched part is unavailable/deleted';
                                // predictionData["complexity"] = "";
                                // predictionData["material"] = "";
                                // predictionData["size"] = "";
                            }

                            if (count === 6 || (i === (ResultArray.length - 1))) {//need only six results
                                this.setState({ predictionResultArray: [...predictionArray.sort((a, b) => { return b.precision - a.precision; })] });
                                console.log("predictionArray", this.state.predictionResultArray);
                                this.props.processInProgress_action(false);
                            }
                        }).catch(err => {
                            count++;
                            this.props.processInProgress_action(false);
                            console.log(err);
                        });
                }
            });
    }

    render() {
        const { privilege } = this.props;
        return (
            <React.Fragment>
                <Grid container spacing={3}>
                    {this.state.predictionResultArray.length > 0 &&
                        (this.state.predictionResultArray.map((ele, Index) => (
                            <PredictedParts key={Index} predictionData={ele} style={{ width: '33%' }} />
                        )))
                    }
                </Grid>

                {privilege && privilege.checkPrintability && this.state.predictionResultArray.length > 0 &&
                    <div style={{ width: '100%', padding: 'auto', textAlign: 'center' }}>
                        <Fab variant="extended" color="primary" aria-label="Add" onClick={() => (this.setState({ printabilityScoreDisplay: true }))}>
                            Compute 3D Printability Score
                        </Fab>
                    </div>
                }
                {this.state.printabilityScoreDisplay &&
                    <PrintabilityScore materials={this.props.materials} PredictionResult={this.state.predictionResultArray.filter(ele => ele.imageSrc !== "./images/notfound.png")}></PrintabilityScore>
                }

            </React.Fragment>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        materials: state.parts.materials,
        privilege: state.auth.user ? state.auth.user.access : undefined,
        organization: state.auth && state.auth.user ? state.auth.user.organization : undefined
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        processInProgress_action: (status) => dispatch(processInProgress(status)),
        fetchMaterials_action: () => dispatch(fetchMaterials())
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(PartPrediction);
