import ReactDOM from 'react-dom';
import React,{ Component } from 'react';
import CommentAdd from './CommentAdd'
import CommentList from './CommentsList'
import {setCommentAdd,getComments,emptySelectedPart} from '../../store/actions/part_action';
import { connect } from 'react-redux';
import { withRouter } from "react-router-dom";
import { CognitoIdToken } from 'amazon-cognito-identity-js';
import { ContinuousColorLegend } from 'react-vis';
import PropTypes from 'prop-types';


class CommentGroup extends Component
{
    constructor(props)
    {
        super(props)
        this.state = {
            comments:[],
            commentID:"",
            CPID:""
        }
    }

    componentWillReceiveProps(props) {
       
        if(props.cdata)
        { let acData = [];
            props.cdata.forEach(part => {acData.push({"id":part.CommentID, "comment":part.CommentText,"user":part.UserID,"date":part.AddDate});});
            this.setState({ comments: acData.sort(function(a,b){
                if(a.date > b.date){return -1;}
            })});
        }
        else
        {
            this.setState({comments:[]})
        }
        
    }

    handleCommentSubmit = (data)=>
    {
            if(data.length > 1)
            {
                this.props.setCommentAdd_action(data,this.props.CID.name,this.props.PID);
                window.location.reload();
            }
            else
            {
                console.log(">>> Comment not Send .....");
            }    
    }


    componentDidMount()
    {   
        console.log(">>>>",this.props.PID);
        this.props.getComments_action(this.props.PID);
        console.log(">>>>",this.props.PID);
    }

    componentWillUnmount()
    {      
    
       this.setState({comments:[],  commentID:"",CPID:"" });
    }

    renderComments()
    {
        const {comments} = this.state;
        return comments.map(comment => {
          
            return(
              <CommentList  key={comment.id} body={comment.comment} user={comment.user} date={comment.date} />
            );
        });
    }

    render(){
        
        

        return(
            <div>
                     
                {this.renderComments()}
            <CommentAdd handleCommentSubmit={this.handleCommentSubmit}/>

      
            </div>
        );
    }

}

CommentAdd.prototype={
    history: PropTypes.any,
}
const mapStateToProps = (state) => {
    return {
        privilege: state.auth.user ? state.auth.user.privilege : undefined,
        cdata:state.parts.allcomments
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        setCommentAdd_action: (c,b,j) => { dispatch(setCommentAdd(c,b,j))},
        getComments_action: (id) => { dispatch(getComments(id)) },
        emptySelectedPart_action: () => { dispatch(emptySelectedPart({})) },
    }
}

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(CommentGroup));

