import ReactDOM from 'react-dom';
import React,{ Component } from 'react';
import PersonAdd from '@material-ui/icons/PersonAdd';
import MessageIcon from '@material-ui/icons/Message';
class CommentList extends Component
{
    constructor(props){
        super(props);
    }
render()
{
    const {body,user,date} = this.props
    return(
         <div className="comment card mb-2">
             <div className="card-body">
             <div><MessageIcon style={{margin:10}}/><strong style={{color:"#43609C"}}>{user}</strong><small> on {date} </small></div>{body}
             </div>
         </div>
    );
}
}
export default CommentList;