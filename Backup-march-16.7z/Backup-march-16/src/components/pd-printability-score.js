import React from 'react'
import clsx from 'clsx';
import TextField from '@material-ui/core/TextField';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import MenuItem from '@material-ui/core/MenuItem';
import Grid from '@material-ui/core/Grid';
import { config } from '../config'
import { FetchAPI } from "../fetch.js";
import PrintabilityScoreChart from './pd-printabilityScore-chart';

const useStyles = makeStyles(theme => ({
    root: {
        display: 'flex',
        flexGrow: 1,
        flexWrap: 'wrap',
        width: '100%',
        margin: theme.spacing(6),
    },
    margin: {
        margin: theme.spacing(1),
    },
    textField: {
        paddingRight: theme.spacing(2),
        flexBasis: 200,
    },
    //to show printability score highlighted in blue color
    printabilityScoreTextField: {
        color: 'blue',
        fontSize: 'large'
    }
}));

export default function PrintabilityScore({ PredictionResult, materials }) {

    const classes = useStyles();

    const [values, setValues] = React.useState(PredictionResult[0]);
    const [result] = React.useState(PredictionResult);
    const [selectedIndex, setIndex] = React.useState(0);
    const [chartDataValue, setChartDataValue] = React.useState([]);
    const [isMounted, mountChartData] = React.useState(false);

    const calculatePrintabilityScore = (newValues) => {
        return new Promise((resolve, reject) => {
            const url = config.HostURL + "/score/getprintabilityScore";
            let printabilityData = {};
            let selecteddataForScore = newValues ? { ...newValues } : { ...values };
            selecteddataForScore.size = values.size;

            for (let property in selecteddataForScore) {
                printabilityData[property] = selecteddataForScore[property];
            }

            FetchAPI.postData(url, printabilityData)
                .then(Response => {
                    setScore(Response.Score);
                    resolve(Response.Score);
                })
                .catch(err => {
                    reject(err);
                });
        })
    }

    const partSelectionChange = () => (event) => {
        //filters selected part from drop down
        let filteredPart = PredictionResult.filter(ele => (
            ele.partName === event.target.value
        ))
        //gets index of selected part from predicted parts
        let index = PredictionResult.findIndex(objList => objList.partName === event.target.value);
        setIndex(index);

        setValues({ ...filteredPart[0] });
        calculatePrintabilityScore(filteredPart[0]);
    }

    const [score, setScore] = React.useState(calculatePrintabilityScore(values));

    async function calChartsData(newValues) {
        let chartDataList = [];
        if (newValues !== undefined) {
            for (var i = 0; i < result.length; i++) {
                if (result[i].partName === newValues.partName) {
                    let changedResults = [...result];
                    changedResults[i] = { ...newValues };
                    let score = await calculatePrintabilityScore(changedResults[i]);
                    chartDataList = chartDataValue;
                    let index = chartDataList.findIndex(objList => objList.name === newValues.partName);
                    setIndex(index);
                    chartDataList[index].y = score;
                }
            }
        } else {
            for (let i = 0; i < result.length; i++) {
                let score = await calculatePrintabilityScore(result[i]);
                chartDataList.push({ x: 'Part ' + (i + 1), y: score, name: result[i].partName });
            }
        }
        setChartDataValue(chartDataList);
        mountChartData(true);
    }

    React.useEffect(() => {
        calChartsData();
    }, [result])

    const handleChange = prop => event => {
        mountChartData(false);
        let newValues = {}
        if (values.size.hasOwnProperty(prop)) {
            newValues = { ...values, size: { ...values.size, [prop]: event.target.value } }
        } else {
            newValues = { ...values, [prop]: event.target.value }
        }
        setValues({ ...newValues });
        calChartsData(newValues);
    }

    return (
        <React.Fragment>
            <Paper className={classes.root}>
                <Grid container>
                    <Grid item xs={12} sm={6} lg={6}>
                        <TextField
                            fullWidth
                            select
                            label="Part Name"
                            className={clsx(classes.margin, classes.textField)}
                            onChange={partSelectionChange()}
                            value={values.partName}
                            SelectProps={{
                                MenuProps: {
                                    className: classes.menu,
                                },
                            }}
                            margin="normal"
                            variant="outlined"
                        >
                            {PredictionResult &&
                                (PredictionResult.map(option => (
                                    <MenuItem key={option.id} value={option.partName}>
                                        {option.partName}
                                    </MenuItem>)
                                ))}
                        </TextField>
                        <TextField
                            fullWidth
                            select
                            label="Material"
                            value={values.material}
                            className={clsx(classes.margin, classes.textField)}
                            onChange={handleChange('material')}
                            SelectProps={{
                                MenuProps: {
                                    className: classes.menu,
                                },
                            }}
                            margin="normal"
                            variant="outlined"
                        >
                            {materials.map((option, Index) => (
                                <MenuItem key={Index} value={option}>
                                    {option}
                                </MenuItem>
                            ))}
                        </TextField>
                        <TextField
                            fullWidth
                            className={clsx(classes.margin, classes.textField)}
                            variant="outlined"
                            label="length"
                            value={values.size.length}
                            onChange={handleChange('length')}
                        />
                        <TextField
                            fullWidth
                            className={clsx(classes.margin, classes.textField)}
                            variant="outlined"
                            label="Breadth"
                            value={values.size.breadth}
                            onChange={handleChange('breadth')}
                        />
                        <TextField
                            fullWidth
                            className={clsx(classes.margin, classes.textField)}
                            variant="outlined"
                            label="Height"
                            value={values.size.height}
                            onChange={handleChange('height')}
                        />
                        <TextField
                            fullWidth
                            select
                            label="Complexity"
                            value={values.complexity}
                            className={clsx(classes.margin, classes.textField)}
                            onChange={handleChange('complexity')}
                            SelectProps={{
                                MenuProps: {
                                    className: classes.menu,
                                },
                            }}
                            margin="normal"
                            variant="outlined"
                        >
                            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((option) => (
                                <MenuItem key={option} value={option}>
                                    {option}
                                </MenuItem>
                            ))}
                        </TextField>
                        <TextField
                            id="outlined-read-only-input"
                            fullWidth
                            className={clsx(classes.margin, classes.textField)}
                            variant="outlined"
                            label="Score"
                            value={score}
                            InputProps={
                                {
                                    className: classes.printabilityScoreTextField,
                                    readOnly: true
                                }
                            }
                        />
                    </Grid>
                    <Grid item xs={12} sm={6} lg={6}>
                        {isMounted &&
                            <PrintabilityScoreChart selectedValue={selectedIndex} data={chartDataValue}></PrintabilityScoreChart>
                        }
                    </Grid>
                </Grid>
            </Paper>
        </React.Fragment >
    );
}