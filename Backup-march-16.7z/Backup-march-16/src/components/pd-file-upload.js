import React from 'react';

import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile';
import DeleteIcon from '@material-ui/icons/Delete';
import Fab from '@material-ui/core/Fab';
import Button from '@material-ui/core/Button';
import { Paper } from '@material-ui/core';
import { useStyles } from '../Styles/fileUpload_styles'

var imagesExt = ["png", "jpeg", "jpg"];

class FileImageUploader extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            filesToUpload: [],
            uploadedFiles: props.filesToShow ? [...props.filesToShow] : [],
            initialFilesToUpload: []
        }
    }

    removedImagesFromOriginalPart = []

    //this is written to fill the images if they have been previously uploaded
    //Or in case of PART-EDIT
    componentDidMount = () => {

        this.setState({ filesToUpload: [...this.state.uploadedFiles] }, () => {

            this.setState({ initialFilesToUpload: [...this.state.uploadedFiles] })

            //sending data to parent after the state is updated
            this.props.partdataHandler({ "imagesToUpload": this.state.filesToUpload });
            // this.props.fileHandler({ "imagesToUpload": this.state.filesToUpload });
        });
    }

    //this function is called when images are selected for upload
    handleChange = (event) => {

        let newFiles = [];
        var filesArr = Object.keys(event.target.files).map(function (key) {
            return [event.target.files[key]];
        });

        let IndexId = this.state.filesToUpload.length > 0 ? this.state.filesToUpload[this.state.filesToUpload.length - 1].id + 1 : 0

        filesArr.forEach((file, Index) => {
            if (imagesExt.includes(file[0].name.split('.')[1].toLowerCase()))
                newFiles.push({ "id": IndexId + Index, "name": file[0].name, "file": file })
        });

        this.setState({ filesToUpload: [...this.state.initialFilesToUpload, ...newFiles] }, () => {
            this.setState({ 'initialFilesToUpload': [...this.state.filesToUpload] });
            this.props.partdataHandler({ "imagesToUpload": [...this.state.initialFilesToUpload, ...newFiles] });
        });
    }

    //this function is called when images are edited/deleted for upload
    imageEditHandler = (val) => {
        let filteredImages = this.state.filesToUpload.filter(ele => { return ele.id !== val });

        if (window.location.pathname.includes('/partedit')) {
            this.state.filesToUpload.forEach(ele => {
                if (ele.id === val && !ele.name) {
                    let value = ele.file.split('?')[0].split('/')[3] + "/" + ele.file.split('?')[0].split('/')[4] + "/" + ele.file.split('?')[0].split('/')[5];
                    let arr = [...this.removedImagesFromOriginalPart]
                    arr.push(value);
                    this.removedImagesFromOriginalPart = [...arr];
                    this.setState({ 'removedImagesFromOriginalPart': [...arr] });
                    this.props.partdataHandler({ "removedImages": this.removedImagesFromOriginalPart });
                }
            })
        }

        this.setState({ filesToUpload: [...filteredImages] }, () => {
            this.setState({ 'initialFilesToUpload': [...this.state.filesToUpload] })
            this.setState({ 'imagesToUpload': [...this.state.filesToUpload] })
            this.props.partdataHandler({ "imagesToUpload": [...this.state.filesToUpload] });
        });
    }

    openInputForImages = () => {
        //added check to clear previous selection
        if (this.inputElement.files.length) {
            this.inputElement.value = '';
        }
        //using ref to click input button on add button click
        this.inputElement.click();
    }

    getImages = (filesToUpload) => {
        let images = [];
        let path = window.location.pathname;

        if (this.state.filesToUpload.length > 0) {
            this.state.filesToUpload.forEach(ele => {
                if (!path.includes('/partedit')) {
                    if (ele.name) {
                        images.push({ "id": ele.id, "name": ele.name, "file": URL.createObjectURL(ele.file[0]) })
                    } else {
                        images.push({ "id": ele.id, "name": ele.name, "file": ele.file[0] })
                    }
                }
                else {
                    if (ele.name) {
                        images.push({ "id": ele.id, "name": ele.name, "file": URL.createObjectURL(ele.file[0]) })
                    } else {
                        images.push(ele)
                    }
                }

            })
        }
        return images;
    }

    render() {
        let images = this.getImages(this.state.filesToUpload);

        let filesToShow = images && images.length > 0 ? [...images] : [];

        return (
            <React.Fragment>
                <input id="inputImages" type="file" onChange={this.handleChange} ref={input => this.inputElement = input} accept=".png, .jpeg, .jpg" multiple style={{ display: "none" }} />
                {!this.props.isAddButttonVisible &&
                    <Button variant="contained" color="primary" onClick={this.openInputForImages} style={{ width: "20%", margin: "auto", marginBottom: "40px" }} >
                        Add Images
                    </Button>
                }
                <br />

                {filesToShow.length > 0 ?
                    <Paper style={this.props.isAddButttonVisible ? { margin: '50px', width: '100%', float: 'left' } : {}}>
                        <PartImage images={filesToShow} onEditClick={this.imageEditHandler}></PartImage>
                    </Paper>
                    : (filesToShow.length > 0 &&
                        <Button variant="contained" color="secondary">
                            {filesToShow[0].name}
                        </Button>
                    )
                }
            </React.Fragment>
        );
    }
}

function PartImage({ images, onEditClick }) {
    const classes = useStyles();

    return (
        <div className={classes.root}>
            <GridList cellHeight={250} className={classes.gridList}>
                {images.map((img) => (

                    //setting custom setting by overriding classes
                    <GridListTile key={img.id} classes={{ root: classes.gridContainer }}>
                        <img src={img.file} alt={img.id} className={classes.gridImg} />
                        <Fab aria-label="Delete" className={classes.gridIcon} onClick={() => onEditClick(img.id)} >
                            <DeleteIcon />
                        </Fab>
                    </GridListTile>
                ))}
            </GridList>
        </div>
    )
}

export default FileImageUploader;