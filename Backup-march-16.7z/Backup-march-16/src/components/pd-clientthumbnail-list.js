import React from "react";
import JssProvider from "react-jss/lib/JssProvider";
import { createGenerateClassName } from "@material-ui/styles";
import { MuiThemeProvider, createMuiTheme } from "@material-ui/core/styles";
import ThumbnailClient from "./pd-client-thumbnail"
import Thumbnail from "./pd-thumbnail"
import "../Styles/thumbnail_styles"

const muiBaseTheme = createMuiTheme();

const generateClassName = createGenerateClassName({
    dangerouslyUseGlobalCSS: true
});

export default function ClientThumbnailList({ clientsarray }, props) {
    return (
        <JssProvider generateClassName={generateClassName}>
            <MuiThemeProvider
                theme={createMuiTheme({
                    typography: {
                        useNextVariants: true
                    },
                    overrides: Thumbnail.getTheme(muiBaseTheme)
                })}
            >
                <ThumbnailClient clientsarray={clientsarray}></ThumbnailClient>
            </MuiThemeProvider>
        </JssProvider>
    );
}



