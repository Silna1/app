import React from 'react';
import ReactApexChart from 'react-apexcharts'
import PropTypes from 'prop-types';

class PrintabilityScoreChart extends React.Component {

    constructor(props) {
        super(props);
        this.colors = [];//['#26a69a', '#26a69a', '#26a69a', '#26a69a', '#26a69a', '#26a69a', '#26a69a', '#26a69a', '#008FFB'];
        this.partNames = [];
        this.partScores = [];
        let _self = this;

        this.state = {
            options: {
                title: {
                    text: 'Printability Score',
                    align: 'center',
                    style: {
                        fontSize: '20px'
                    },
                },
                plotOptions: {
                    bar: {
                        columnWidth: '45%',
                        distributed: true
                    },
                },
                colors: this.colors,
                dataLabels: {
                    enabled: false
                },
                xaxis: {
                    categories: ['Part1', 'Part2', 'Part3', 'Part4', 'Part5', 'Part6'],
                    title: {
                        text: 'Predicted Parts',
                        style: {
                            color: '#575772',
                            fontSize: '14px'
                        },
                    },
                    axisTicks: {
                        show: true,
                    },
                    axisBorder: {
                        show: true,
                        color: '#008FFB'
                    },
                    labels: {
                        style: {
                            colors: '#000000',
                        }
                    },
                    type: 'string'
                },
                yaxis: {
                    title: {
                        text: 'Printability Score',
                        style: {
                            color: '#575772',
                            fontSize: '14px'
                        },
                    },
                    axisTicks: {
                        show: true,
                    },
                    axisBorder: {
                        show: true,
                        color: '#008FFB'
                    },
                    labels: {
                        style: {
                            color: '#000000',
                        }
                    },
                    min: 0,
                    max: 100
                },
                tooltip: {
                    x: {
                        formatter: function (val, opts) {
                            if (_self.partNames !== undefined)
                                return _self.partNames[opts.dataPointIndex]
                            else
                                return val;
                        }
                    }
                },
                chart: {
                    animations: {
                        enabled: true,
                        easing: 'easeinout',
                        speed: 800,
                        animateGradually: {
                            enabled: true,
                            delay: 150
                        },
                        dynamicAnimation: {
                            enabled: true,
                            speed: 350
                        }
                    }
                }
            },
            series: [{
                name: "Score",
                data: this.partScores,//[44, 55, 57, 56, 61, 58]
            },
            ],
        }
    }

    componentDidMount() {
        const { data, selectedValue } = this.props;
        for (let key in data) {
            if (data.hasOwnProperty(key)) {
                const part = data[key];
                this.partNames.push(part.name);
                this.partScores.push(part.y);
                if (selectedValue === parseInt(key))
                    this.colors.push('#ef5d28');//#008FFB
                else
                    this.colors.push('#ff9833');//26a69a
            }
        }
    }

    //This method will not supported in react 17 version. We need to write method like below commented code 
    UNSAFE_componentWillReceiveProps(newProps) {
        if (JSON.stringify(this.props) !== JSON.stringify(newProps)) {
            this.updateNewData(newProps.selectedValue);
        }
    }

    // static getDerivedStateFromProps(props, state) {
    //     if(props !== newProps){
    //         this.prepareColors();
    //     }
    //   }

    updateNewData(selectedValue) {
        const { data } = this.props;
        this.colors = [];
        this.partScores = [];
        for (let key in data) {
            if (data.hasOwnProperty(key)) {
                const part = data[key];
                this.partScores.push(part.y);
                if (selectedValue === parseInt(key))
                    this.colors.push('#ef5d28');
                else
                    this.colors.push('#ff9833');
            }
        }

        var options = { ...this.state.options };
        options.colors = this.colors;
        options.series = [{
            name: "Score",
            data: this.partScores
        }];
        this.setState({ options: options });
    }

    render() {
        return (
            <div id="chart" style={{ margin: "17px" }}>
                <ReactApexChart options={this.state.options} series={this.state.series} type="bar" height="450" />
            </div>
        );
    }
}

PrintabilityScoreChart.propTypes = {
    data: PropTypes.array,
    selectedValue: PropTypes.number
}

export default PrintabilityScoreChart;