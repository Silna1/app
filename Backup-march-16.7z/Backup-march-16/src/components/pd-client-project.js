// ********Main imports**************
import React, { useEffect, useState ,useRef} from "react";
import PropTypes from "prop-types";
import {useHistory} from 'react-router-dom';

// ********Material ui imports**************
import {makeStyles} from "@material-ui/styles"
import MenuItem from '@material-ui/core/MenuItem';
import TablePagination from "@material-ui/core/TablePagination";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Divider from "@material-ui/core/Divider";
import Fab from "@material-ui/core/Fab";
import cloneDeepWith from "lodash/cloneDeepWith";
import Container from '@material-ui/core/Container';
import { styled } from '@mui/material/styles';
import clsx from 'clsx';
import PerfectScrollbar from 'react-perfect-scrollbar';
import TableContainer from '@material-ui/core/TableContainer';
import {
  Avatar,
  Box,
  Checkbox,
  Typography
} from '@mui/material';
import { getInitials } from './utils/get-initials';



// ********Component imports**************
import { connect } from "react-redux";
import TablePaginationActions from "./pd-pagination";
import { useStyles2 } from "../Styles/dahboardLayout_styles";
import {
  fetchProject,
  deleteProject,
  fetchProjectLocation,
  fetchprojectClient
} from "../store/actions/project_action";
import {
  searchInProgress,
  getPartsData,
  getTotalPartsCount,
  totalPartsCount,
} from "../store/actions/part_action";
import {
  processInProgress,
  setSelectedClient,
} from "../store/actions/misc_action";
import color from "@material-ui/core/colors/amber";
import { Button,Modal,Form,Spinner,Alert } from 'react-bootstrap';
import {
  Card,
  CardActions,
  CardHeader,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableRow,
} from '@material-ui/core';
import TableHead from '@mui/material/TableHead';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import CancelIcon from '@mui/icons-material/Cancel';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import DeleteIcon from '@mui/icons-material/Delete';
import BackspaceIcon from '@mui/icons-material/Backspace';
import CheckIcon from '@mui/icons-material/Check';
import VisibilityIcon from '@material-ui/icons/Visibility';
import ButtonGroup from '@mui/material/ButtonGroup';
import moment from 'moment';

const axios = require("axios");


const useStyles = makeStyles(theme => ({
  card: {
    width: '100%',
    marginTop: '30px',
  },
  icons: {
    cursor: 'pointer',
    margin: '0 10px',
  }
}));



function ClientProLayoutList(props) {
  const {
    clientsarray,
    fetchClients_action,
    privilege,
    selectedClient,
    client,
    clientList,
    className, 
    project,
    fetchprojects_action,
    email,
    deleteProject_action,
    fetchprojectClient_action,
    fetchProjectLocation_action,
    clientProject,
    projectLocation,
    location,
    ...rest
  } = props;


  console.log("silna surendran",props);
  const classes = useStyles();
  const history = useHistory();
  const [page, setPage] = React.useState(0);
  const [searchValue, setsearchValue] = React.useState("");

  //
  const [isModalOpen,setIsModalOpen] = useState(false);
  const projectRef = useRef(null);
 
  //create REF to call child function from parent
  const child = React.createRef();

  const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    width:'200px',
    height:'200px',
    color: theme.palette.text.secondary,

  }));

  const [selectedCustomerIds, setSelectedCustomerIds] = useState([]);
  const [limit, setLimit] = useState(10);

  useEffect(() => {
    fetchprojects_action();
    fetchprojectClient_action();
    fetchProjectLocation_action();
  }, [])

 

  const handleLimitChange = (event) => {
    setLimit(event.target.value);
  };

  const handlePageChange = (event, newPage) => {
    setPage(newPage);
  };

  //Pagination function
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  //Pagination function
  const handleChangeRowsPerPage = (event) => {
   // setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleView = (id) => {

  }

  const handleEdit = (id) => {
    history.push(`/project/edit/${id}`);
  };

  const handleDelete = () => {
    deleteProject_action(projectRef.current)
    setIsModalOpen(false);
    projectRef.current = null;
  };

  const handledeleteModal = (project) =>{
    setIsModalOpen(true);
    projectRef.current = project;
  }

  // {/* Searchbar with camera icon button */}
  return (
    <Card className={classes.card} {...rest}>
    <PerfectScrollbar>
      <Box sx={{ minWidth: 1250 }}>
        
      <TableContainer component={Paper}>
        <Table aria-label="collapsible table">
          <TableHead>
            <TableRow>
              <TableCell>Project Name</TableCell>
              <TableCell>Client Name</TableCell>
              <TableCell>Location</TableCell>
              <TableCell >Project Status</TableCell>
              <TableCell >Start Date</TableCell>
              <TableCell >End Date</TableCell>
              <TableCell> Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
          {project.slice(0, limit).map((proj) => (
              <TableRow
                hover
                key={proj.projectId}
                selected={selectedCustomerIds.indexOf(proj.id) !== -1}
              >
                {/* <TableCell padding="checkbox">
                  <Checkbox
                    checked={selectedCustomerIds.indexOf(proj.projectId) !== -1}
                    onChange={(event) => handleSelectOne(event, proj.projectId)}
                    value="true"
                  />
                </TableCell> */}
                <TableCell>
                  <Box
                    sx={{
                      alignItems: 'center',
                      display: 'flex'
                    }}
                  >
                    <Avatar
                      src={proj.avatarUrl}
                      sx={{ mr: 2 }}
                    >
                      {getInitials(proj.name)}
                    </Avatar>
                    <Typography
                      color="textPrimary"
                      variant="body1"
                    >
                      {proj.name}
                    </Typography>
                  </Box>
                </TableCell>
                <TableCell>
                {proj.client?.name}
                </TableCell>
                <TableCell>
                {proj.location?.name}
                </TableCell>
                <TableCell>
                {proj.projStatus}
                </TableCell>
                <TableCell>
                {moment(proj.startDate).format("MM/DD/YYYY")}
                </TableCell>
                <TableCell>
                {moment(proj.lastDate).format("MM/DD/YYYY")}
                </TableCell>
                <TableCell>
                <ButtonGroup variant="outlined" aria-label="outlined primary button group">
                <VisibilityIcon onClick={() => handleView(proj.projectId)} className={classes.icons} color='inherit'/>
                <EditIcon onClick={() => handleEdit(proj.projectId)} className={classes.icons} color='inherit'/>
                <DeleteIcon onClick={() => handledeleteModal(proj)} className={classes.icons} color='inherit' />
                </ButtonGroup>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      </Box>
    </PerfectScrollbar>
    <TablePagination
      component="div"
      count={project.length}
      onPageChange={handlePageChange}
      onRowsPerPageChange={handleLimitChange}
      page={page}
      rowsPerPage={limit}
      rowsPerPageOptions={[5, 10, 25]}
    />
    <Dialog onClose={() => setIsModalOpen(false)} open={isModalOpen}>
              <DialogTitle>Alert</DialogTitle>
              <DialogContent style={{paddingTop: '20px'}}>
                Are you sure ,you want to delete the client?
              </DialogContent>
              <DialogActions>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={handleDelete} startIcon={<CheckIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Confirm
                    </Typography>
                </Button>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={() => setIsModalOpen(false)} startIcon={<CancelIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Cancel
                    </Typography>
                </Button>
              </DialogActions>
            </Dialog>
  </Card>
  );
}

ClientProLayoutList.propTypes = {
  selectedClient: PropTypes.string,
  client: PropTypes.string,
  clientList: PropTypes.any,
  clientsarray:PropTypes.array,
  fetchClients:PropTypes.func,
  fetchprojects_action:PropTypes.func,
  project: PropTypes.array,
  email: PropTypes.string,
  fetchprojectClient_action:PropTypes.func,
  fetchProjectLocation_action:PropTypes.func
};

const mapStateToProps = (state) => {
  return {
    selectedClient: state.misc.selectedClient
      ? state.misc.selectedClient
      : undefined,
    clientList: state.misc.clients,
    project:state.project.projects,
    email: state.auth.user ? state.auth.user.email : undefined,
    clientProject: state.project.clientProject,
    projectLocation: state.project.projectLocation
   
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    searchProgress_action: (status) => dispatch(searchInProgress(status)),
    processInProgress_action: (status) => dispatch(processInProgress(status)),
    setSelectedClient_action: (client) => dispatch(setSelectedClient(client)),
    fetchprojects_action:()=>dispatch(fetchProject()),
    deleteProject_action: (data)=> dispatch(deleteProject(data)),
    fetchProjectLocation_action:()=>dispatch(fetchProjectLocation()),
    fetchprojectClient_action:()=>dispatch(fetchprojectClient())
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ClientProLayoutList);
