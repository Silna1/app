import React, { PureComponent } from 'react';
import Layout from './pd-layout';
import { SnackbarProvider } from 'notistack';
import { createTheme, ThemeProvider, styled } from '@mui/material/styles';
import "@fontsource/montserrat"; 

const theme = createTheme({
  typography: {
    fontFamily: [
      'Montserrat',
      'sans-serif'
    ].join(','),
  }
});

class App extends PureComponent {
  render() {
    return (
      <ThemeProvider theme={theme}>
        <div className="App" >
          <SnackbarProvider maxSnack={8} autoHideDuration={3000}><Layout></Layout></SnackbarProvider>
        </div>
      </ThemeProvider>
    );
  }
}

export default App;