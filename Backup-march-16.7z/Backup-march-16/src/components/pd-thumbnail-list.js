import React from "react";
import JssProvider from "react-jss/lib/JssProvider";
import { createGenerateClassName } from "@material-ui/styles";
import { MuiThemeProvider, createMuiTheme } from "@material-ui/core/styles";
import Thumbnail from "./pd-thumbnail"
import "../Styles/thumbnail_styles"

const muiBaseTheme = createMuiTheme();

const generateClassName = createGenerateClassName({
    dangerouslyUseGlobalCSS: true
});

export default function ThumbnailList({ partData }, props) {
    return (
        <JssProvider generateClassName={generateClassName}>
            <MuiThemeProvider
                theme={createMuiTheme({
                    typography: {
                        useNextVariants: true
                    },
                    overrides: Thumbnail.getTheme(muiBaseTheme)
                })}
            >
                <Thumbnail partsData={partData}></Thumbnail>
            </MuiThemeProvider>
        </JssProvider>
    );
}



