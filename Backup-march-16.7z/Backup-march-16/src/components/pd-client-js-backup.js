import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import { connect } from 'react-redux'
import ClientsLayoutGrid from "./pd-client-grid-layout"
import ClientsLayoutist from "./pd-clients-layout"
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import { Link } from 'react-router-dom'
import Tooltip from '@material-ui/core/Tooltip';
import PropTypes from 'prop-types';
import Box from '@material-ui/core/Box';
import {
    Typography
  } from '@mui/material';
import {
    fetchClients,
    deleteClient,
    addClient,
    updateClient,
  } from "../store/actions/client_action";

import { getPartsData ,getCategoriesList} from '../store/actions/part_action';
import { signIn } from '../store/actions/authentication_action';
import { processInProgress } from '../store/actions/misc_action'

class Clients extends Component {

    constructor(props) {
        super(props);
        this.isPartsAvailable = false;
        this.props.signIn_action();
    }

    componentDidMount() {

        console.log("Back in Here...");
        console.log("Back in Here.fetchClients_action..");
        this.props.fetchClients_action();
        this.props.getCategoriesList_action(this.props.organization);
        if (this.props.parts === undefined){
            this.props.processInProgress_action(true);
            console.log("inside if ");
        }
        else
        {
            this.props.processInProgress_action(false);
            console.log("inside else ");
        }
       

            
    }

    clientsStyle = {
        root: {
            flexGrow: 1,
            backgroundImage: '',
            overflowX: "hidden",
            overflowY: 'hidden',
            height: '100%',
            minHeight: '-webkit-fill-available'
        },
        fabStyles: {
            position: 'fixed',
            bottom: '48px',
            right: '48px',
            zIndex: 1
        }
    }
    
    render() {
     
        const { clientsarray, organization, selectedClient, clientList } = this.props;
        console.log("props inside pd-client",this.props);
      //  let client = selectedClient ? selectedClient : organization;
        
        
        return (
            <><Box
            sx={{
             
              display: 'flex',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              marginTop:'50px'
            }}
          >
            <Typography
              sx={{ m: 1,color:'#19b4dd' }}
              variant="h4"
            >
              Clients
            </Typography>
            </Box><div style={this.clientsStyle.root}>

                    <Grid container spacing={2}>
                        {console.log("inside return ", clientList)}
                        {clientList &&
                            <ClientsLayoutGrid clientsarray={clientsarray} />}

                    </Grid>
                    <Tooltip title="Add Customer">
                        <Fab color="#152836" style={{ color: '#3f51b5' }} aria-label="Add" style={this.clientsStyle.fabStyles} component={Link} to="/partcustomer">
                            <AddIcon />
                        </Fab>
                    </Tooltip>
                </div></>
        )
    }
}

Clients.propTypes = {
    parts: PropTypes.object,
    organization: PropTypes.string,
    selectedClient: PropTypes.string,
    clientList: PropTypes.array,
    getPartsData_action: PropTypes.func,
    processInProgress_action: PropTypes.func,
    signIn_action: PropTypes.func,
    fetchClients_action: PropTypes.func
}

const mapStateToProps = (state) => {
    console.log("state of clients",state);
    return {
        parts: state.parts,
        selectedClient: state.misc.selectedClient,
        clientList: state.misc.clients,
        organization: state.auth && state.auth.user ? state.auth.user.organization : undefined,
        privilege: state.auth && state.auth.user ? state.auth.user.access : undefined,
        cats:state.parts.categories,
        clientsarray: state.client.value
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        getPartsData_action: (organization) => dispatch(getPartsData({ 'lastEvaluatedKey': null, 'organization': organization })),
        processInProgress_action: (status) => dispatch(processInProgress(status)),
        signIn_action: () => dispatch(signIn()),
        getCategoriesList_action:(organization) => dispatch(getCategoriesList(organization)),
        fetchClients_action:()=>dispatch(fetchClients()),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Clients);
