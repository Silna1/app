import React, { Component } from 'react';
import { connect } from 'react-redux'
import JssProvider from "react-jss/lib/JssProvider";
import { createGenerateClassName } from "@material-ui/styles";
import { MuiThemeProvider, createMuiTheme } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid"
import TextField from '@material-ui/core/TextField';
import Tooltip from '@material-ui/core/Tooltip';
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import PropTypes from 'prop-types';
import '../Styles/printercard_styles';
import { fetchPrinters, addPrinter } from "../store/actions/printer_action"
import { processInProgress } from '../store/actions/misc_action';
import Modal from './pd-dialog'
import PrinterCard from './pd-printer-card'
import InputBase from '@material-ui/core/InputBase';
import { config } from '../config'

const muiBaseTheme = createMuiTheme();

const generateClassName = createGenerateClassName({
    dangerouslyUseGlobalCSS: true
});

class Printer extends Component {

    constructor(props) {
        super(props);
        this.printerObj = React.createRef();
        this.state = {
            isValidated: false,
            isValuesNegative: false
        }
        this.emptyPrinterObj = { ...this.printer };
    }

    printer = {
        manufacturer: "",
        material: "",
        model: "",
        name: "",
        size: {
            breadth: undefined,
            height: undefined,
            length: undefined,
        }
    }

    componentDidMount() {
        this.props.processInProgress_action(true);
        this.props.getPrinterData_action();
    }

    fabStyles = {
        position: 'fixed',
        bottom: '48px',
        right: '48px',
        zIndex: 1
    }

    handleSave = () => {
        console.log("silan handleSave printer",this.printer);
        this.setState({ isValidated: true });
        if (this.vaidateData(this.printer)) {
            this.setState({ isValidated: false });
            this.printerObj.current.handleClose();
            this.props.addPrinter_action(this.printer);
            this.printer = { ...this.emptyPrinterObj };
        }
    }

    handleChange = (key) => (event) => {
        if (key === "length" || key === "breadth" || key === "height") {
            this.printer = { ...this.printer, 'size': { ...this.printer.size, [key]: event.target.value } };
        } else {
            this.printer = { ...this.printer, [key]:                              event.target.value };
        }
    }

    vaidateData = (data) => {
        for (const element in data) {
            if (data.hasOwnProperty(element)) {
                if (element === 'size') {
                    let sizeObj = data[element];
                    for (const item in sizeObj) {
                        if (this.isEmpty(sizeObj[item]) && Number(sizeObj[item]) < 0) {
                            this.setState({ isValuesNegative: true });
                            return false;
                        }
                        else if (!this.isEmpty(sizeObj[item])) {
                            this.setState({ isValuesNegative: false });
                            return false;
                        }
                    }
                }
                if (!this.isEmpty(data[element]))
                    return false;
            }
        }
        this.setState({ isValuesNegative: false });
        return true;
    }

    isEmpty = (data) => {
        if (data === undefined || data === '' || data === null)
            return false;

        return true;
    }

    render() {
        const { printer, privilege, userOrganization } = this.props;
        console.log("printer render value checking",this.props);

        //sorts printer array of objects by name property value, to show printer tiles alphabetically
        // if (printer)
        //     printer.sort((a, b) => (a.name.toLowerCase() > b.name.toLowerCase()) ? 1 : ((b.name.toLowerCase() > a.name.toLowerCase()) ? -1 : 0));

        return (
            <Grid container style={{ marginTop: '30px' }} spacing={2} >
                {printer && printer.map((value, index) => (
                    <Grid item xs={12} sm={6} lg={3} key={index} >
                        <JssProvider generateClassName={generateClassName}>
                            <MuiThemeProvider
                                theme={createMuiTheme({
                                    typography: {
                                        useNextVariants: true
                                    },
                                    overrides: PrinterCard.getTheme(muiBaseTheme)
                                })}
                            >
                                <PrinterCard printerData={value}></PrinterCard>
                            </MuiThemeProvider>
                        </JssProvider>
                    </Grid>
                ))}
                {privilege && privilege.addPrinter && userOrganization === config.ProductOwner &&
                    <Tooltip title="Add Printer">
                        <Fab color="primary" aria-label="Add" style={this.fabStyles} onClick={() => (this.printerObj.current.handleClickOpen())} >
                            <AddIcon />
                        </Fab>
                    </Tooltip>
                }
                <Modal title="Add New Printer" obj={this.handleSave} ref={this.printerObj}>
                {console.log("add new Printer inside modal",this.printerObj)}
                    <TextField fullWidth label="Name" onChange={this.handleChange('name')} style={{ padding: "5px" }} />
                    <TextField label="Model" onChange={this.handleChange('model')} style={{ padding: "5px", minWidth: "50%" }} />
                    <TextField label="Material" onChange={this.handleChange('material')} style={{ padding: "5px", minWidth: "50%" }} />
                    <TextField fullWidth label="Manufacturer" onChange={this.handleChange('manufacturer')} style={{ padding: "5px" }} />
                    <br />
                    <TextField type="number" label="Length(mm)" onChange={this.handleChange('length')} style={{ padding: "5px" }} InputProps={{ inputProps: { min: 0 } }} />
                    <TextField type="number" label="Breadth(mm)" onChange={this.handleChange('breadth')} style={{ padding: "5px" }} InputProps={{ inputProps: { min: 0 } }} />
                    <TextField type="number" label="Height(mm)" onChange={this.handleChange('height')} style={{ padding: "5px" }} InputProps={{ inputProps: { min: 0 } }} />
                    <InputBase
                        value={!this.state.isValuesNegative ? "*All fields are necessary" : "Values cannot be negative"}
                        inputProps={{ 'aria-label': 'naked' }}
                        disabled
                        color="#ff0000"
                        style={{ display: !this.state.isValidated ? 'none' : 'block', color: "#ff0000" }}
                    />
                </Modal>
            </Grid >
        );
    }
}

Printer.propTypes = {
    printer: PropTypes.any,
    privilege: PropTypes.object,
    addPrinter_action: PropTypes.func,
    processInProgress_action: PropTypes.func,
    getPrinterData_action: PropTypes.func,
}

const mapStateToProps = (state) => {
    console.log("add printer mapStateToProps",state);
    return {
        printer: state.printer.value,
        privilege: state.auth.user ? state.auth.user.access : undefined,
        userOrganization: state.auth && state.auth.user ? state.auth.user.organization : undefined
    }
}

const mapDispatchToProps = (dispatch) => {
    console.log("mapDispatchToProps printer",dispatch);
    return {
        getPrinterData_action: () => dispatch(fetchPrinters()),
        addPrinter_action: (printerData) => dispatch(addPrinter(printerData)),
        processInProgress_action: (status) => dispatch(processInProgress(status)),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Printer);