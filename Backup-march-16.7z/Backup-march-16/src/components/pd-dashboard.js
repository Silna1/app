import React, { Component } from 'react';
import Grid from '@material-ui/core/Grid';
import { connect } from 'react-redux'
import DashboardLayout from "./pd-dashboard-layout"
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import { Link } from 'react-router-dom'
import Tooltip from '@material-ui/core/Tooltip';
import PropTypes from 'prop-types';

import { getPartsData ,getCategoriesList} from '../store/actions/part_action';
import { signIn } from '../store/actions/authentication_action';
import { processInProgress } from '../store/actions/misc_action';

class Dashboard extends Component {

    constructor(props) {
        super(props);
        this.isPartsAvailable = false;
        this.props.signIn_action();
    }

    componentDidMount() {

        console.log("Back in Here...");
        this.props.getCategoriesList_action(this.props.organization);
        if (this.props.parts === undefined){
            this.props.processInProgress_action(true);
        }
        else
        {
            this.props.processInProgress_action(false);
        }
       

            
    }

    dashboardStyle = {
        root: {
            flexGrow: 1,
            backgroundImage: '',
            overflowX: "hidden",
            overflowY: 'hidden',
            height: '100%',
            minHeight: '-webkit-fill-available'
        },
        fabStyles: {
            position: 'fixed',
            bottom: '48px',
            right: '48px',
            zIndex: 1
        }
    }
    
    render() {
     
        const { parts, organization, selectedClient, clientList } = this.props;
        let client = selectedClient ? selectedClient : organization;
        if (!this.isPartsAvailable && organization !== undefined && clientList && clientList.includes(organization)) {
            this.props.getPartsData_action(client);
            this.isPartsAvailable = true;
        }
        
        return (
            <div style={this.dashboardStyle.root}>

                <Grid container spacing={2}>
                    {parts && parts.Items &&
                        <DashboardLayout partData={parts.Items} client={client} cats={this.props.cats}/>
                    }
                </Grid>
                <Tooltip title="Add Part">
                    <Fab color="primary" style={{color:'#3f51b5'}} aria-label="Add"  style={this.dashboardStyle.fabStyles} component={Link} to="/partadd">
                        <AddIcon />
                    </Fab>
                </Tooltip>
            </div>
        )
    }
}

Dashboard.propTypes = {
    parts: PropTypes.object,
    organization: PropTypes.string,
    selectedClient: PropTypes.string,
    clientList: PropTypes.array,
    getPartsData_action: PropTypes.func,
    processInProgress_action: PropTypes.func,
    signIn_action: PropTypes.func
}

const mapStateToProps = (state) => {
    return {
        parts: state.parts,
        selectedClient: state.misc.selectedClient,
        clientList: state.misc.clients,
        organization: state.auth && state.auth.user ? state.auth.user.organization : undefined,
        privilege: state.auth && state.auth.user ? state.auth.user.access : undefined,
        cats:state.parts.categories
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        getPartsData_action: (organization) => dispatch(getPartsData({ 'lastEvaluatedKey': null, 'organization': organization })),
        processInProgress_action: (status) => dispatch(processInProgress(status)),
        signIn_action: () => dispatch(signIn()),
        getCategoriesList_action:(organization) => dispatch(getCategoriesList(organization))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
