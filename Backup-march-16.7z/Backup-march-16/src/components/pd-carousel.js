import React, { Component } from 'react';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';

class ImageCarousel extends Component {

    render() {
        return (
            <Carousel autoPlay >
                {this.props.partImages.map((imgsrc, Index) => (
                    <img src={imgsrc.url} alt={Index} />
                ))}
            </Carousel>
        )
    }
}

export default ImageCarousel;