// ********Main imports**************
import React, { useEffect } from "react";
import PropTypes from "prop-types";
import { config } from "../config";
import { FetchAPI } from "../fetch.js";

// ********Material ui imports**************

import CameraAltRounded from "@material-ui/icons/CameraAltRounded";
import TablePagination from "@material-ui/core/TablePagination";
import Paper from "@material-ui/core/Paper";
import IconButton from "@material-ui/core/IconButton";
import Grid from "@material-ui/core/Grid";
import InputBase from "@material-ui/core/InputBase";
import Divider from "@material-ui/core/Divider";
import Fab from "@material-ui/core/Fab";
import MenuItem from "@material-ui/core/MenuItem";
import TextField from "@material-ui/core/TextField";
import Tooltip from "@material-ui/core/Tooltip";
import Hidden from "@material-ui/core/Hidden";
import cloneDeepWith from "lodash/cloneDeepWith";
import AccountCircle from '@material-ui/icons/AccountCircle';
import PageviewIcon from '@material-ui/icons/Pageview';
import InputAdornment from "@material-ui/core/InputAdornment";
import Typography from '@material-ui/core/Typography';
import SvgIcon from '@material-ui/core/SvgIcon';
import Pagination from '@material-ui/lab/Pagination';
import Container from '@material-ui/core/Container';
import {FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {faSearch } from "@fortawesome/free-solid-svg-icons";




// ********Component imports**************
import { connect } from "react-redux";
import ThumbnailList from "./pd-thumbnail-list";
import FileUpload from "./pd-file-upload";
import PartPrediction from "./pd-part-prediction";
import TablePaginationActions from "./pd-pagination";
import { useStyles2 } from "../Styles/dahboardLayout_styles";
import {
  searchInProgress,
  getPartsData,
  getTotalPartsCount,
  totalPartsCount,
} from "../store/actions/part_action";
import {
  processInProgress,
  setSelectedClient,
} from "../store/actions/misc_action";
import {
    fetchLocation
}  from "../store/actions/location_action";
import {
  fetchProject
} from "../store/actions/project_action";
import color from "@material-ui/core/colors/amber";
import { Button,Modal,Form,Spinner,Alert } from 'react-bootstrap';

const axios = require("axios");


let oldPartData = {};
let searchData = null;

function DashBoardLayout(props) {
  const {
    partData,
    searchProgress_action,
    processInProgress_action,
    setSelectedClient_action,
    getPartsData_action,
    setTotalpartCount_action,
    privilege,
    selectedClient,
    client,
    getTotalPartCount_action,
    parts,
    clientList,
    cats,
    project,
    location,
    fetchLocation_action,
    fetchProject_action
  } = props;


  
  const classes = useStyles2();
  const [page, setPage] = React.useState(0);
  const [searchValue, setsearchValue] = React.useState("");

  //
  const [open, setIsOpen] = React.useState("");
  const [show, setshowFile] = React.useState(null);
  const [file, setFile] = React.useState(null);
  const [isButtonHidden, setisButtonHidden] = React.useState(false);
  const [loading, setLoading] = React.useState(true);
  const [messageText,setmessageText]= React.useState("");
  const [isFile, setisFile] = React.useState(false);
  const [datax, setdatax] = React.useState("...");
  

  const [rowsPerPage, setRowsPerPage] = React.useState(4);
  const [partItems, setPartItems] = React.useState([...partData]);
  const [imagesForSearch, setImages] = React.useState([]);
  const [searchForPrediction, setDisplayforPrediction] = React.useState(false);
  oldPartData = cloneDeepWith(partData);
  const [clients, setClients] = React.useState(client);
  //called First time when component mounts and every other time when part add is called
  useEffect(() => {
    setPartItems([...partData]);
    fetchLocation_action();
    fetchProject_action();
    if (selectedClient) getTotalPartCount_action(selectedClient);
    else setTotalpartCount_action(partData.length);
  }, [partData]);

  //create REF to call child function from parent
  const child = React.createRef();

  //Pagination function
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChange = (event) => {
    setClients(event.target.value);
    setsearchValue("");
    searchProgress_action(false); //sets search status to false on organization change
    setSelectedClient_action(event.target.value);
    setPage(0);
    //processInProgress_action(processInProgress(true));
    getPartsData_action(event.target.value);
  };

  //Pagination function
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  //Text Search Input function
  const searchInputHandler = (event) => {
    clearInterval(searchData);
    let searchString = event.target.value;
    setsearchValue(searchString);
    const search = () => {
      FetchAPI.postData(config.HostURL + "/search/searchpart", {
        name: searchString.toLowerCase(),
        organization: selectedClient,
      })
        .then((data) => {
          clearInterval(searchData);
          if (data) {
            searchProgress_action(true);
            setPartItems([...data]);
            setTotalpartCount_action(data.length);
            handleChangePage(event, 0);
          } else {
            searchProgress_action(false);
            setPartItems([]);
            setTotalpartCount_action(0);
          }
        })
        .catch((err) => {
          console.log(err);
          clearInterval(searchData);
          searchProgress_action(false);
          setPartItems([]);
          setTotalpartCount_action(0);
        });
    };

    if (searchString) {
      searchData = setInterval(search, 500);
    } else if (searchString === "") {
      searchProgress_action(false);
      setPartItems([...oldPartData]);
      getTotalPartCount_action(selectedClient);
    }
  };

  //Image Search Input function
  const handleImagesDetails = (obj) => {
    setImages([...obj.imagesToUpload]);
    setDisplayforPrediction(false);

    //close progressbar when new images/input is taken
    if (obj.imagesToUpload.length !== imagesForSearch.length) {
      processInProgress_action(false);
    }
  };

  //Image Search Input function
  const handleFileSelect = () => {
    //using REF to call child function from parent
    child.current.openInputForImages();
  };

  const sendForPredict = () => {
    setDisplayforPrediction(true);
    processInProgress_action(true);
  };

     //Modal

    const closeModal = () =>{
      setIsOpen(false);
    }

   const openModal = () =>{
      
      setIsOpen(true);
    }

    function onFormSubmit(e){
      e.preventDefault();
        if(isFile){
          const formData = new FormData();
          formData.append('myImage',file);
          const config = {
              headers: {
                  'content-type': 'multipart/form-data'
              }
          };

          console.log("Submiting");
         sendGetRequest(formData,config,e);
         setFile(undefined);
         setshowFile(undefined);
         setisFile(false);
         setisButtonHidden(false);
         setmessageText("");
         setLoading(false);
         
         //isButtonHidden(false);
         // this.setState({file:undefined,showfile:undefined,isFile:false,isButtonHidden:false,messageText:""});
      }else{
          console.log("File not Selected...");
          setmessageText("* No File Selected.");
          //this.setState({messageText:"* No File Selected."});
      }

    }

    //axios to send post request
    const sendGetRequest = async (formDatax,configx,event) => {
      try {
          
          const resp = await axios.post('http://127.0.0.1:8083/search/recciveimage',formDatax,configx);

        

        /* if(resp.data.length < 1){
           
           
          // this.setState({playerName:"Uploaded Image not Defined."});
             
             setLoading(true);
             closeModal();
             console.log("No Returned Data");
            
         }
         else{*/

          if (resp) {
            console.log(resp);
            setLoading(true);
            setPartItems([...resp.data]);
            setTotalpartCount_action(resp.data.length);
            handleChangePage(event, 0);
            closeModal();
          } else {
            setLoading(false);
            setPartItems([]);
            setTotalpartCount_action(0);
            closeModal();
          }
         
             
         
         
      } catch (err) {
          
          console.error(err);
      }
     };

     //

    function onChange(e) {
      setFile(e.target.files[0]);
      setshowFile(URL.createObjectURL(e.target.files[0]));
      setisFile(true);
      setisButtonHidden(true);
      setmessageText("");
      
    }

    const removeImage = () => {
      setshowFile(undefined);
      setFile(false);
      setisFile(false);
      setisButtonHidden(false);
      
    }


  // {/* Searchbar with camera icon button */}
  return (
    <React.Fragment>
  
      <Grid container spacing={0} alignItems="flex-end" style={{marginTop:100,marginLeft:0}}>

      <Grid item xs={12} sm={11} >
          {privilege && privilege.searchPart && (
            
              <TextField
                className={classes.input}
                label="Parts Search"
                onChange={searchInputHandler}
                value={searchValue}
                variant="outlined"
                size="normal"
                style={{width:"100%",marginBottom:20}}
                InputProps={{
                  startAdornment: (
                    <InputAdornment>
                    
                      <Button style={{marginRight:10}} variant="outline-dark" onClick={openModal} disabled>  <FontAwesomeIcon icon={faSearch} /></Button>
                    </InputAdornment>
                  )
                }}
                
              />

              
            
          )}

<Modal show={open} style={{marginTop:65}}  onHide={closeModal}>
  <Modal.Header closeButton>
    <Modal.Title>
        Parts Image Search
    </Modal.Title>
  </Modal.Header>
  <Modal.Body>
  
  {loading === true ? (
                <>
  {isButtonHidden == true?(
            <img src={show} width="260px" height="220px" style={{marginLeft:"20%"}}/>
            )
                :
                (
                    <img src={ process.env.PUBLIC_URL + "/noimage.jpg"} width="320px" height="220px" style={{marginLeft:"20%"}}/>
                )
            }


  <br /> <br />   <p>{messageText}</p>   
  <form onSubmit={onFormSubmit}>
  <Form.File  label="Upload Image to Serach a Player" lang="en" custom  name="myImage" class="form-control-file" onChange= {onChange}   accept="image/*" />
  <br />     <hr />  
  {isButtonHidden == true?(<Button  variant="outline-danger"  onClick={removeImage}>REMOVE</Button>):(<></>)}
            {' '}
                            <Button type="submit" variant="outline-primary">SEARCH</Button>
        


</form>
<br /></>):(
                 <div class="container" width="100%" style={{color:"#FFF"},{textAlign:"center"}}>
                     <Spinner animation="border" variant="primary" /> 
                     <h5>Please wait,Image Searching....</h5>
                     
                 </div>
                
             )
            }
  </Modal.Body>
        </Modal>
        
           </Grid>
           
           

           <Grid item xs={12} sm={12} style={{marginLeft:20,marginBottom:20}}>Filter By :</Grid>
           <Grid item xs={4} sm={4} >
           
              {parts && clientList && (
                <TextField
                  InputProps={{ className: classes.whiteColor }}
                  onChange={handleChange}
                  select
                  label="Client"
                  variant="outlined"
                  value={clients ? clients : selectedClient}
                  required
                  size="large"
                  style={{marginLeft:20,width:"70%",marginBottom:20}}
                >
                  {clientList.map((option) => (
                    <MenuItem key={option} value={option}>
                      {option}
                    </MenuItem>
                  ))}
                </TextField>
              )}
             
            </Grid>

            <Grid item xs={4} sm={4} >
           
              {parts && clientList && location && (
                <TextField
                  InputProps={{ className: classes.whiteColor }}
                  onChange={handleChange}
                  select
                  label="Location"
                  variant="outlined"
                  value={location.name}
                  required
                  size="medium"
                  style={{marginLeft:20,width:"70%",marginBottom:20}}
                >
                  {location && location.map(item => 
                                <MenuItem key={item.id} value={item.id}>{item.name}</MenuItem>
                            )}
           
                </TextField>
              )}
             
            </Grid>
            <Grid item xs={4} sm={4}>
           
              {parts && clientList && project && (
                <TextField
                  InputProps={{ className: classes.whiteColor }}
                  onChange={handleChange}
                  select
                  label="Project"
                  variant="outlined"
                  value={project.name}
                  required
                  size="medium"
                  style={{marginLeft:20,width:"70%",marginBottom:20}}
                >
                  {project && project.map(item => 
                                <MenuItem key={item.projectId} value={item.projectId}>{item.name}</MenuItem>
                            )}
                </TextField>
              )}
             
            </Grid>
          
      </Grid>

      {/* Shows images selected for searching */}
      <FileUpload
        partdataHandler={(obj) => handleImagesDetails(obj)}
        ref={child}
        isAddButttonVisible={true}
      ></FileUpload>

      {/* Search parts button */}
      {imagesForSearch.length > 0 && (
        <div className={classes.button}>
          <Fab
            variant="extended"
            color="primary"
            aria-label="Add"
            onClick={sendForPredict}
          >
            Search Parts
          </Fab>
        </div>
      )}

      {/* Shows predicted parts */}
      {searchForPrediction && <PartPrediction imgdata={imagesForSearch} />}
        
          {/* Pagination */}
          <Container fixed>
          <Grid container>
            <Grid
              item
              xs={12}
              sm={12}
              lg={12}
              style={{marginBottom:10}}
            >
              <TablePagination
                rowsPerPageOptions={[4,6,12]}
                colSpan={3}
                count={parts.totalPartsCount?parts.totalPartsCount:0}
                rowsPerPage={rowsPerPage}
               
                page={page}
                SelectProps={{
                  inputProps: {
                    "aria-label": "Parts per page",
                  },
                  
                }}
                
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeRowsPerPage}
                ActionsComponent={TablePaginationActions}
                classes={{
                  root: classes.whiteColor,
                  caption: classes.whiteColor,
                  selectIcon: classes.whiteColor,
                  select: classes.whiteColor,
                }}
                labelRowsPerPage="Items per Page"
           
              />
            </Grid>
          </Grid>
          </Container>
          {/* part Thumbnails */}
          <Container fixed>
          <Grid container xs={12} sm={12} lg={12}>
            {partItems
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((part, Index) => (
                <Grid item xs={12} sm={6} lg={3} key={Index}>
                  {console.log("partData silna",{part})}
                  <ThumbnailList partData={part} />
                </Grid>
              ))}
          </Grid>
          </Container>
     
      
    </React.Fragment>
  );
}

DashBoardLayout.propTypes = {
  partData: PropTypes.array,
  searchProgress_action: PropTypes.func,
  processInProgress_action: PropTypes.func,
  getPartsData_action: PropTypes.func,
  getTotalPartCount_action: PropTypes.func,
  setSelectedClient_action: PropTypes.func,
  setTotalpartCount_action: PropTypes.func,
  lastEvaluatedKey: PropTypes.any,
  organization: PropTypes.string,
  selectedClient: PropTypes.string,
  client: PropTypes.string,
  privilege: PropTypes.any,
  parts: PropTypes.object,
  clientList: PropTypes.any,
  fetchLocation_action: PropTypes.func,
  fetchProject_action: PropTypes.func
};

const mapStateToProps = (state) => {
  return {
    parts: state.parts,
    selectedClient: state.misc.selectedClient
      ? state.misc.selectedClient
      : undefined,
    clientList: state.misc.clients,
    lastEvaluatedKey: state.parts.LastEvaluatedKey,
    privilege: state.auth.user ? state.auth.user.access : undefined,
    organization: state.auth.user ? state.auth.user.organization : undefined,
    location: state.location.locations,
    project: state.project.projects

  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    searchProgress_action: (status) => dispatch(searchInProgress(status)),
    processInProgress_action: (status) => dispatch(processInProgress(status)),
    getPartsData_action: (organization) =>
      dispatch(
        getPartsData({ lastEvaluatedKey: null, organization: organization })
      ),
    setSelectedClient_action: (client) => dispatch(setSelectedClient(client)),
    setTotalpartCount_action: (count) => dispatch(totalPartsCount(count)),
    getTotalPartCount_action: (organization) =>
    dispatch(getTotalPartsCount(organization)),
    fetchLocation_action:()=>dispatch(fetchLocation()),
    fetchProject_action:()=>dispatch(fetchProject())
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(DashBoardLayout);
