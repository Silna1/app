import {
    Button,
    Icon,
    Grid,
    Radio,
    RadioGroup,
    ValidatorFormControlLabel,
    Checkbox,
    Box,
    Card
} from '@mui/material'
import React, { Suspense, lazy, useRef } from "react";
import {useHistory} from 'react-router-dom';
import InputLabel from '@mui/material/InputLabel';
import { styled } from '@mui/system'
import FormHelperText from '@mui/material/FormHelperText';
import { useState, useEffect } from 'react'
import { ValidatorForm, TextValidator } from 'react-material-ui-form-validator'
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom'
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import CancelIcon from '@mui/icons-material/Cancel';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import DeleteIcon from '@mui/icons-material/Delete';
import BackspaceIcon from '@mui/icons-material/Backspace';
import {
    fetchClients,
    deleteClient,
    addClient,
    updateClient,
} from "../store/actions/client_action";
import { processInProgress } from '../store/actions/misc_action';
import { BrowserRouter as Router,NavLink, Link, Route, Switch } from 'react-router-dom';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import {fetchLocation} from '../store/actions/location_action';
import {addProject, fetchProjectById, updateProject,deleteProject} from '../store/actions/project_action';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import CheckIcon from '@mui/icons-material/Check';
import DatePicker from './utils/Datepicker';
import moment from "moment";
import { getUsersdata} from '../store/actions/user_action';


const TextInput = styled(TextField)(() => ({
    width: '100%',
    marginBottom: '16px',
}))

const CustomSelect = styled(Select)(() => ({
    width: '100%',
    marginBottom: '16px',
}))

const defaultError = {
name:'',
description:'',
client:'',
location:'',
startDate:'',
lastDate:'',
//projCloseDate:'',
projStatus:'',
projOwner:'',
projPriority:'',
partsCount :''  
}

const fieldRequiredText = 'This field is required';

const ProjectAdd = (props) => {
    
        
    const {fetchLocation_action, fetchClients_action, addProject_action, fetchProjectById_action, updateProject_action, locations, clientsarray,deleteProject_action,usersData, privilege, organization,getUserdata_action} = props;
    const history = useHistory();
    const userEmail = props.email;
    const defaultProject = {
        name:'',
        description:'',
        client: {},
        location:{},
        createDate:new Date().toISOString(),
        lastUpdate:new Date().toISOString(),
        createdUser:userEmail,
        updatedUser:userEmail,
        startDate:'',
        lastDate:'',
        projStatus:'',
        projOwner:'',
        projPriority:'',
        projCloseDate:'',
        partsCount :'',
        isDelete : false 
        }

    const [errors, setErrors] = useState({...defaultError});
    const [project, setProject] = useState({...defaultProject});
    const [date, setDateValue] = useState('');
    const [isEdit, setIsEdit] = useState(false);
    const [isEditPage,setIsEditPage] = useState(false);
    const [isModalOpen,setIsModalOpen] = useState(false);
    const [isOrganizationAvailable,setIsOrganizationAvailable] = useState(false);
    const projectRef = useRef(null);
    const [clientlocation,setClientLocation]=useState([]);

    useEffect(() => {
        getDate();
        fetchValues();
        if (organization !== undefined && !isOrganizationAvailable) {
                getUserdata_action(organization);
            setIsOrganizationAvailable(true);
        }
        fetchLocation_action();
        fetchClients_action();
    }, [])

    useEffect(()=>
    {
        setClientLocation(locations);
    
    },[locations])



    useEffect(() => {
        const pathData = history.location.pathname.split('/');
        if(pathData[2] === 'edit') {
            setIsEditPage(true);
            fetchProjectById_action(pathData[3])
            .then(res => {
                setProject({...res})
                projectRef.current = {...res}
            })
            .catch(err => {
                console.log(err);
            })
        }
    }, [])

    const getDate = () => {
        let today = new Date();
        let date = today.getFullYear()+'/'+(today.getMonth()+1)+'/'+today.getDate();
        setDateValue(date);
    };

    const fetchValues = () => {
        
    }

    const validateData = (data) => {
        const errorProxy = {...errors};
        let valid = true;
        console.log("validat data project add",data)
        Object.keys(defaultError).forEach(itemKey => {
            errorProxy[itemKey] = (!data[itemKey] || (typeof data[itemKey] === 'object' && !Object.keys(data[itemKey]).length)) ? fieldRequiredText : '';
        })
       errorProxy.name = !data.name ? fieldRequiredText : validateName(data.name) ? '' : 'Name should be minimum 4-15 characters';
        setErrors(errorProxy)
        Object.values(errorProxy).forEach(item => {
            if(item && valid) {
                valid = false
            }
        })
        return valid;
    }

    const validateName = (name) =>
    {
        if(name.length< 4 || name.length > 15)
        {
            console.log("checking validation project name",name.length)
            return false;
        }
        else
        {
            console.log("checking validatename");
            return true;
        }
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log("handlesubmit");
        if(validateData(project)) {
            if(isEditPage) {
                const payload =  {...project,lastUpdate:new Date().toISOString(),updatedbyUser:userEmail}
                updateProject_action(payload)
                .then(() => {
                    setProject({...defaultProject});
                    history.goBack();
                })
                .catch(err => {
                    console.log(err);
                })
            } else {
                console.log("addproject action");
                console.log("Project values",project);
                addProject_action(project)
                .then(() => {
                    setProject({...defaultProject});
                    history.goBack();
                })
                .catch((error) =>{
                    if(error && error.statusCode === 409)
                    {
                       if(error.statuskey === "Nexist")
                       {
                           setErrors({...errors, name: "Project Name already exist" });
                       }
                    }
                })
            }
        }
        else{
            console.log("Handlesubmit error");
        }
    }

    const handleClear = (event) => {
        event.preventDefault();
        setProject({...defaultProject});
    }

    const handleBack = () => {
        history.goBack();
    }

    const handleCancel = (event) => {
        event.preventDefault();
        history.goBack();
    }

    const  handleEdit = () => {
        setIsEdit(!isEdit);
        if(isEdit) {
            setProject({...projectRef.current});
            setErrors({...defaultError})
        }
    }

    const handleDelete = () => {
        deleteProject_action(projectRef.current)
        setIsModalOpen(false);
        projectRef.current = null;
        props.history.goBack();
      };

    const handleDateChange = (key) => (value) => {
        console.log(value);
        setProject({...project, [key]:moment(value).format()})        
    }


    const handleChange = (key) => (event) => {
        console.log(event);
        if(key === 'client')
        {
            const clientData = clientsarray.find(item => item.id === event.target.value);
           // fetchLocation_action(`?clientId=${clientData.id}`);
           const locationData = locations.filter(item=> item.client.id== clientData.id)
            setClientLocation(locationData);
            setProject({...project, [key]:{id:clientData.id,name:clientData.clientName}}) 
        }
        else if (key === 'location')
        {
            const locationData = locations.find(item => item.id === event.target.value);
            setProject({...project, [key]:{id:locationData.id,name:locationData.name}}) 
        }
       else
        {
            setProject({...project, [key]:event.target.value}) 
        }
               
    }

    return (
        <div>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
                marginTop:'50px'
              }}
            >
              <Typography
                sx={{ m: 1,color:'#19b4dd',fontWeight: 600 }}
                variant="h4"
              >
                {!isEditPage ? "Add project" : "Edit Project"}
              </Typography>
              <Button onClick={handleBack} style={{color:"#19b4dd",mr: 1}} variant="outlined" startIcon={<ArrowBackIcon />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Go Back
                    </Typography>
                </Button>
            </Box>
            <Box
            sx={{
            display: 'flex',
            '& > :not(style)': {
             m: 1, 
             },
            marginTop:'20px'
            }}
            >
            <Card style={{padding: '0 25px 25px'}} sx={{marginTop:'30px'}}>
                <Grid container spacing={6}>
                    <Grid item lg={6} md={6} sm={12} xs={12} sx={{ mt: 5 }}>
                        <TextInput
                            type="text"
                            name="name"
                            disabled= {isEditPage && !isEdit}
                            onChange={handleChange('name')}
                            label="Project Name (Min length 4, Max length 15)"
                            error={!!errors.name}
                            helperText={errors.name}
                            value={project.name}
                        />
                        <InputLabel id="demo-simple-select-label">Status</InputLabel>
                        <CustomSelect
                            value={project.projStatus || ''}
                            label="Status"
                            disabled= {isEditPage && !isEdit}
                            onChange={handleChange('projStatus')}
                            error={!!errors.projStatus}
                        >
                            {["Initial", "Inprogress", "Done"].map(option => (
                            <MenuItem key={option} value={option}>
                                {option}
                            </MenuItem>
                        ))}
                        </CustomSelect>
                        <TextInput
                            label="Description"
                            onChange={handleChange('description')}
                            disabled= {isEditPage && !isEdit}
                            type="text"
                            multiline
                            minRows={3}
                            name="description"
                            value={project.description}
                        />
                       
                        <InputLabel id="demo-simple-select-label">Owner</InputLabel>
                        <CustomSelect
                            value={project.projOwner}
                            label="Owner"
                            disabled = {isEditPage && !isEdit}
                            onChange={handleChange('projOwner')}
                        >
                            {usersData && usersData.map((user, index) => (
                            <MenuItem key={user.email} value={user.email}>{user.email}</MenuItem>
                            ))}
                        </CustomSelect>
                        <TextInput
                            label="Potential Parts"
                            onChange={handleChange('partsCount')}
                            disabled= {isEditPage && !isEdit}
                            type="text"
                            name="partsCount"
                            value={project.partsCount}
                            error={!!errors.partsCount}
                            helperText={errors.partsCount}
                        />
                        <DatePicker
                            label="Start Date"
                            disabled = {isEditPage}
                            onChange={handleDateChange('startDate')}
                            value={project.startDate}
                            error={!!errors.startDate}
                            helperText={errors.startDate}
                        />
                        <DatePicker
                            label="Last Date"
                            disabled = {isEditPage}
                            onChange={handleDateChange('lastDate')}
                            value={project.lastDate}
                            error={!!errors.lastDate}
                            helperText={errors.lastDate}
                        />
                        {isEditPage && 
                        <DatePicker
                            label="Closing Date"
                            onChange={handleDateChange('projCloseDate')}
                            disabled= {isEditPage && !isEdit}
                            value={project.projCloseDate}
                            error={!!errors.projCloseDate}
                            helperText={errors.projCloseDate}
                        />
                        }
                        <InputLabel id="demo-simple-select-label">Priority</InputLabel>
                        <CustomSelect
                            value={project.projPriority || []}
                            label="projPriority"
                            disabled= {isEditPage && !isEdit}
                            onChange={handleChange('projPriority')}
                            error={!!errors.projPriority}
                        >
                            {["High", "Medium", "Low"].map(option => (
                            <MenuItem key={option} value={option}>
                                {option}
                            </MenuItem>
                        ))}
                        </CustomSelect>
                        <InputLabel id="demo-simple-select-label">Client</InputLabel>
                        <CustomSelect
                            value={project.client?.id || ''}
                            label="Client"
                            disabled= {isEditPage && !isEdit}
                            onChange={handleChange('client')}
                            error={!!errors.client}
                        >
                            {clientsarray && clientsarray.map(item => 
                                <MenuItem key={item.id} value={item.id}>{item.clientName}</MenuItem>
                            )}
                        </CustomSelect>
                        <FormHelperText error>{errors.client}</FormHelperText>
                        <FormHelperText error>{errors.projPriority}</FormHelperText>
                        <InputLabel id="demo-simple-select-label">Location</InputLabel>
                        <CustomSelect
                            value={project.location?.id || ''}
                            label="Location"
                            disabled= {isEditPage && !isEdit}
                            onChange={handleChange('location')}
                            error={!!errors.location}
                        >
                            {clientlocation && clientlocation.map(item => 
                                <MenuItem key={item.id} value={item.id}>{item.name}</MenuItem>
                            )}
                        </CustomSelect>
                        <FormHelperText error>{errors.location}</FormHelperText>
                        
                    </Grid>
                </Grid>
                <Box
                        sx={{
                            display: 'flex',
                            justifyContent: 'flex-end',
                            p: 2
                        }}
                         >
                        {!isEditPage ?
                        <>
                        <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" type="submit" onClick={handleSubmit} startIcon={<AddCircleIcon  />}>
                        
                            <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                                Add
                            </Typography>
                        </Button>
                        <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" type="submit" onClick={handleClear} startIcon={<BackspaceIcon  />}>
                        
                            <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                                Clear
                            </Typography>
                            
                        </Button>
                        <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" type="submit" onClick={handleCancel} startIcon={<CancelIcon  />}>
                        
                            <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                                Cancel
                            </Typography>
                            
                        </Button>
                        </> :
                        <>
                        <Button onClick={handleEdit} style={{color:"#19b4dd",mr: 1}}  variant="outlined" startIcon={!isEdit ? <EditIcon /> : <CancelIcon/>}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        {!isEdit ? "Edit" : "Cancel"}
                    </Typography>
                </Button>
                {isEdit &&
                    <Button onClick={handleSubmit} style={{color:"#19b4dd",mr: 1}}  variant="outlined" startIcon={<SaveIcon />}>
                        <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                            Save
                        </Typography>
                    </Button>
                }
                
                <Button onClick={() => setIsModalOpen(true)} style={{color:"#19b4dd",mr: 1}} variant="outlined" startIcon={<DeleteIcon />}>
                    {console.log("setIsModalOpen",isModalOpen)}
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Delete
                    </Typography>
                </Button>
                        </>
                }
                        </Box>
            </Card>
            </Box>
            <Dialog onClose={() => setIsModalOpen(false)} open={isModalOpen}>
              <DialogTitle>Alert</DialogTitle>
              <DialogContent style={{paddingTop: '20px'}}>
                Are you sure ,you want to delete the client?
              </DialogContent>
              <DialogActions>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={handleDelete} startIcon={<CheckIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Confirm
                    </Typography>
                </Button>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={() => setIsModalOpen(false)} startIcon={<CancelIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Cancel
                    </Typography>
                </Button>
              </DialogActions>
            </Dialog>
        </div>
    )
}

ProjectAdd.propTypes = {
    selectedClient: PropTypes.string,
    clientsarray: PropTypes.array,
    fetchClients_action: PropTypes.func,
    addClient_action:PropTypes.func,
    processInProgress_action: PropTypes.func,
    email: PropTypes.string,
    deleteProject_action: PropTypes.func,
    usersData: PropTypes.object,
    privilege: PropTypes.any,
    organization: PropTypes.string,
    getUserdata_action: PropTypes.func
}

const mapStateToProps = (state) => {
    console.log("state of clients",state);
    return {
        privilege: state.auth && state.auth.user ? state.auth.user.access : undefined,
        clientsarray: state.client.value,
        locations: state.location.locations,
        email: state.auth.user ? state.auth.user.email : undefined,
        usersData: state.users.usersdata,
        organization: state.auth.user ? state.auth.user.organization : undefined
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        addClient_action:(clientsarray)=>dispatch(addClient(clientsarray)),
        processInProgress_action: (status) => dispatch(processInProgress(status)),
        fetchLocation_action: (query) => dispatch(fetchLocation(query)),
        fetchClients_action: () => dispatch(fetchClients()),
        addProject_action: (project) => dispatch(addProject(project)),
        fetchProjectById_action: (id) => dispatch(fetchProjectById(id)),
        updateProject_action: (project) => dispatch(updateProject(project)),
        deleteProject_action: (data)=> dispatch(deleteProject(data)),
        getUserdata_action: (organization) => dispatch(getUsersdata(organization)),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ProjectAdd);

