// ********Main imports**************
import React, { Suspense, lazy, useEffect, useState } from "react";
import clsx from 'clsx';
import { BrowserRouter as Router,NavLink, Link, Route, Switch, Redirect } from 'react-router-dom'
import { signout } from '../store/actions/authentication_action';

// ********Material ui imports**************
import { AppBar, IconButton, CssBaseline, MenuList, MenuItem, Typography, Toolbar, Drawer, Divider,Card } from '@material-ui/core'
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import DashboardIcon from '@material-ui/icons/Dashboard';
import MenuIcon from '@material-ui/icons/Menu';
import Home from '@material-ui/icons/Home';
import Chart from '@material-ui/icons/InsertChart';
import Person from '@material-ui/icons/Person';
import LocalPrintshop from '@material-ui/icons/LocalPrintshop';
import Settings from '@material-ui/icons/Settings';
import Tooltip from '@material-ui/core/Tooltip';
import Menu from '@material-ui/core/Menu';
import { connect } from "react-redux";
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Collapse from '@mui/material/Collapse';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
//import { useStyles } from "../Styles/layout_styles"
import { makeStyles, useTheme } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import LinearProgress from '@material-ui/core/LinearProgress';
import { useSnackbar } from 'notistack';
import Proptypes from 'prop-types'
import { config } from "../config";
import CachedIcon from '@material-ui/icons/Cached';
import GavelIcon from '@material-ui/icons/Gavel';
import ThreeDRotationIcon from '@material-ui/icons/ThreeDRotation';
import { RiLoginBoxLine } from "react-icons/ri";
import { SiNintendoswitch } from "react-icons/si";
import TimelineIcon from '@material-ui/icons/Timeline';
import PieChartIcon from '@material-ui/icons/PieChart';
import GroupIcon from '@mui/icons-material/Group';

import InboxIcon from '@material-ui/icons/MoveToInbox';
import MailIcon from '@material-ui/icons/Mail';
import LockIcon from '@mui/icons-material/Lock';
import { withStyles } from '@material-ui/core/styles';
import {NavbarData} from './navbarData';
import { signIn } from "../store/actions/auth_action";
import {fetchMenuAccess} from '../store/actions/menuaccess_action';
import SignInMain from "./pd-SignInMain";
import SignInForm from "./SignInForm";
import SignUpForm from "./SignUpForm";
import ResetPasswordForm from './ResetPasswordForm';

// ********Component imports**************
const PartCatalog = lazy(() => import('../components/Part-Catalog/pd-part-catalog'));
const TopCats = lazy(() => import('../components/Part-Catalog/top-categories'));
const TopAnalytics = lazy(() => import('../components/Part-Catalog/pd-analysis'));
const Dashboard = lazy(() => import('./pd-dashboard'));
const PartProfileView = lazy(() => import('./pd-part-profile-view'));
const UserSettings = lazy(() => import('./pd-userSettings'));
const PartAdd = lazy(() => import('./pd-part-addition'));
const Printer = lazy(() => import('./pd-printer'));
const AdminSetting = lazy(() => import('./pd-admin-settings'));
const Clients = lazy(() => import('./pd-clients'));
const ClientAdd = lazy(() => import('./pd-client-add'));
const ClientView = lazy(()  => import('./pd-clientView'));
const Projects = lazy(()  => import('./pd-project'));
const ProjectAdd = lazy(()  => import('./pd-add-project'));
const Locations = lazy(()  => import('./pd-location'));
const LocationAdd = lazy(()  => import('./pd-add-location'));
const SignIn = lazy(() => import('./pd-signIn'))
const MenuAccess = lazy(() => import('./pd-menu-access'))
const DataAccess = lazy(() => import('./pd-data-access'))
//const SignInMain = lazy(() => import('./pd-SignInMain'))
const NotFound = lazy(() => import('./pd-notfound'));

const StyledMenu = withStyles({
  paper: {
    border: '1px solid #d3d4d5',
  },
})((props) => (
  <Menu
    elevation={0}
    getContentAnchorEl={null}
    anchorOrigin={{
      vertical: 'bottom',
      horizontal: 'center',
    }}
    transformOrigin={{
      vertical: 'top',
      horizontal: 'center',
    }}
    {...props}
  />
));

const StyledMenuItem = withStyles((theme) => ({
  root: {
    '&:focus': {
      backgroundColor: theme.palette.primary.main,
      '& .MuiListItemIcon-root, & .MuiListItemText-primary': {
        color: theme.palette.common.white,
      },
    },
  },
}))(MenuItem);



const drawerWidth = 200;



const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    fontFamily: "'Montserrat', sans-serif"
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    background: 'linear-gradient(to right, #152836 41%, #FFFFFF 100%)',
    // background : 'linear-gradient(100deg, rgba(2,0,36,1) 0%, rgba(25,180,221,1) 35%, rgba(0,212,255,1) 100%)',
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  appBarShift: {
    // marginLeft: drawerWidth,
    // width: `calc(100% - ${drawerWidth}px)`,
   // background: 'linear-gradient(0.75turn,#FFFFFF,#152836 )',
   //background:'linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(25,180,221,1) 35%, rgba(0,212,255,1) 100%)',
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  menuButton: {
    marginRight: 36,
  },
  hide: {
    display: 'none',
  },
  drawer: {
    width: drawerWidth,
    // flexShrink: 0,
    // whiteSpace: 'nowrap',
    '& .MuiDrawer-paper': {
      background: 'linear-gradient(100turn,#FFFFFF,#F5F5F5 )',
    },
  },
  drawerPaper:{
      height:'100%',
      background: 'linear-gradient(0.75turn,#FFFFFF,#F5F5F5 )',
      position: "relative",
      marginTop:"85px",
    },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  },
  drawerClose: {
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up('sm')]: {
      width: theme.spacing(9) + 1,
    },
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
  listText: {
    minWidth: '85px !important',
  },
  listButton: {
    display: 'flex',
    flexDirection: 'column'
  },
  listItems: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  "&.MuiList-root": {
    margin :'20px'
  }
}));


function Layout({ userImage, signOut_action, processInProgress, notificationState, privilege, email, organization ,auth, user, access, fetchMenuAccess_action}) {
  const classes = useStyles();
  const theme = useTheme();
  const { enqueueSnackbar } = useSnackbar();
  
  const [open, setOpen] = React.useState(true);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [collapseIndex, setCollapseIndex] = React.useState(-1);
  const [navbarList, setNavbarList] = useState([]);

  // displaying snackbar when process completes
  React.useEffect(() => {
    if (notificationState) {
      let variant = notificationState.variant;
      enqueueSnackbar(notificationState.message, { variant, autoHideDuration: 3000 });
    }
  }, [notificationState])

  useEffect(() => {
    if(user && auth) {
      console.log('useruseruser', user);
    fetchMenuAccess_action(user.privilege)
    }
  }, [user,auth])

  useEffect(() => {
    if(access) {
      const navData = [...NavbarData];
      navData.forEach(item => {
        if(item.showMenu) {
          item.showItem = access[`${item.key}View`] || false;
        }
        if(item.subList) {
          item.subList.forEach(subItem => {
            if(subItem.showMenu) {
              subItem.showItem = access[`${subItem.key}View`] || false;
            }
          })
        }
      });
      setNavbarList(navData);
      console.log('navData', navData)
    }
  }, [access])

  const handleDrawerOpen = () => {
    setOpen(true);
  }

  const handleDrawerClose = () => {
    // setOpen(false);
  }

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  }

  const handleCollapse = (index, e) => {
    e.preventDefault();
    e.stopPropagation();
    setCollapseIndex(index === collapseIndex ? -1 : index);
  }

  const handleClose = () => {
    setAnchorEl(null);
  }

  const signOut = () => {
    signOut_action();
    handleClose();
  }

  // Tabs 
  const [anchorElx, setAnchorElx] = React.useState(null);
  const handleClickx = (event) => {
    setAnchorElx(event.currentTarget);
    
  };
  const handleClosex = () => {
    setAnchorElx(null);
  };

  if(auth)
  {
    console.log("checking auth value",auth);
  return (
    <Router>
      <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,400;0,500;0,600;1,400;1,500;1,600&display=swap" rel="stylesheet"/>
      <div className={classes.root}>
        <CssBaseline />
        <AppBar
          position="fixed"
          className={clsx(classes.appBar, {
            [classes.appBarShift]: open,
          })}
        >
          <Toolbar>
            <Tooltip title="Menu">
              <IconButton
                color="inherit"
                aria-label="Open drawer"
                onClick={handleDrawerOpen}
                edge="start"
                className={clsx(classes.menuButton, open && classes.hide)}
              >
                <MenuIcon />
              </IconButton>
            </Tooltip>
            <Tooltip>
            <img src="./Immensa-dark-c.png" width="180px"  alt="sa" marginLeft="-30px"/>
            </Tooltip>
          {/*  <Tooltip title="Refresh">
              <IconButton onClick={()=> window.location.reload(false)}><CachedIcon fontSize="large" style={{ color: 'gray',alignItems:'right' }}></CachedIcon>
              </IconButton>
        </Tooltip>*/}
            <Grid container spacing={3}>
              <Grid item xs={12} sm={12} style={{ textAlign: "center", }}>
                <Typography variant="h4" style={{ display: 'inline-block', color: 'white', fontFamily: "'Montserrat', sans-serif", paddingLeft: "1%" }}>
                 
              </Typography>
              </Grid>
            </Grid>
            <div>
              <Tooltip title={email}>
                <IconButton onClick={handleClick}>
                  <Person fontSize="large" style={{ color: 'white' }}></Person>
                </IconButton>
              </Tooltip>
              <Menu
                id="simple-menu"
                anchorEl={anchorEl}
                keepMounted
                open={Boolean(anchorEl)}
                onClose={handleClose}
                className={classes.menu}
              >
                <MenuItem component={Link} to='/' onClick={signOut}><RiLoginBoxLine /> Sign Out</MenuItem>
              </Menu>
            </div>
          </Toolbar>
          {processInProgress &&
            <LinearProgress style={{ height: '5px' }} />
          }
        </AppBar>
        <Drawer
           className={clsx(classes.drawer, {
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open,
          })}
          variant="persistent"
          open={window.close}
          classes={{
            paper: clsx({
              [classes.drawerOpen]: open,
              [classes.drawerClose]: !open,
            }),
          }}
        >
          <div className={classes.toolbar}>
            <IconButton onClick={handleDrawerClose}>
              {theme.direction === 'ltr' ? <ChevronLeftIcon /> : <ChevronRightIcon />}
            </IconButton>
          </div>
          <Divider variant='middle'/>
          <List component="nav">
          {/* <MenuItem  aria-controls="customized-menu" aria-haspopup="true" variant="contained" color="primary" onClick={handleClickx}><ListItemIcon><Chart /></ListItemIcon>Dashboard</MenuItem>
          <Divider variant='middle'/> */}

          {navbarList.map((item, i) => {
            if((item.hasOwnProperty('showItem') && item.showItem) || !item.hasOwnProperty('showItem'))
            return (
              <>
                <ListItemButton className={classes.listButton} component={Link} to={item.link} onClick={handleClickx}>
                  <div className={classes.listItems}>
                    <ListItemIcon>{item.icon && item.icon}</ListItemIcon>
                    <ListItemText className={classes.listText} primary={item.name} />
                    {item.subList ? <div onClick={(e) => handleCollapse(i, e)}>{collapseIndex === i ? <ExpandLessIcon /> : <ExpandMoreIcon />}</div> : <div style={{height:24, width: 24}} />}
                  </div>
                  {item.subList && item.subList.length > 1 ?
                    <Collapse in={collapseIndex === i} timeout="auto" unmountOnEdit>
                      <List component="nav" disablePadding>
                        {item.subList.map((subItem) => {
                          if((subItem.hasOwnProperty('showItem') && subItem.showItem) || !subItem.hasOwnProperty('showItem'))
                          return (
                            <>
                              <Divider variant='middle'/>
                              <ListItemButton component={Link} to={subItem.link}>
                                <div className={classes.listItems}>
                                  <ListItemIcon>
                                    {subItem.icon && subItem.icon}
                                  </ListItemIcon>
                                  <ListItemText className={classes.listText} primary={subItem.name} />
                                </div>
                              </ListItemButton>
                            </>
                          )
                        })}
                      </List>
                    </Collapse>: 
                  null}
                </ListItemButton>
                <Divider variant='middle'/>
              </>
              )
          })}
          </List>
        </Drawer>
        <main
          className={clsx(classes.content, {
            [classes.contentShift]: open,
          })}
        >
          <div className={classes.drawerHeader} />
          <React.Fragment>
            <Suspense fallback={<div></div>}>
              <Switch>
                <Route path='/signin' render={() => <Redirect to='/' />} />
                <Route path="/" exact component={Dashboard} />
                <Route path="/partcatalog" component={PartCatalog} />

                <Route path="/topcats" component={TopCats} />
                <Route path="/analysis" component={TopAnalytics} />

                <Route path="/:id/partprofileview" component={PartProfileView} />
                {privilege && privilege.editPart &&
                  <Route path="/:id/partedit" component={PartAdd} />
                }
                {privilege && privilege.addPart &&
                  <Route path="/partadd" component={PartAdd} />
                }
                <Route path="/usersetting" render={() => (<UserSettings></UserSettings>)} />
                <Route path="/printer" render={() => (<Printer></Printer>)} />
                <Route path="/clients" render={() => (<Clients></Clients>)} />
                
                  <Route path="/clientadd" component={ClientAdd} />
                  <Route path="/projects" component={Projects} />
                  <Route path="/projectadd" component={ProjectAdd} />
                  <Route path="/project/edit/:id" component={ProjectAdd} />
                  <Route path="/locations" component={Locations} />
                   <Route path="/locationadd" component={LocationAdd} />
                   <Route path="/location/edit/:id" component={LocationAdd} />
                    {privilege && privilege.zipUpload && organization === config.ProductOwner &&
                  <Route path="/adminsettings" render={() => (<AdminSetting></AdminSetting>)} />
                }
                <Route path="/client/edit/:id" component={ClientAdd} />
                <Route path="/login" component={SignIn} />
                <Route path="/dataaccess" component={DataAccess} />
                <Route path="/menuaccess" component={MenuAccess} />
                <Route component={NotFound} />
              </Switch>
            </Suspense>
          </React.Fragment>
        </main>
      </div>
    </Router>
  );
  }
  return (
    <Router>
      <Switch>
        <Route exact path='/' render={() => <Redirect to='/signin' />} />
        <Route exact path="/signin" render={() => <SignInMain><SignInForm /></SignInMain>} />
        <Route exact path="/signup" render={() => <SignInMain><SignUpForm /></SignInMain>} />
        <Route exact path="/reset-password" render={() => <SignInMain><ResetPasswordForm /></SignInMain>} />
      </Switch>
    </Router>
  );
 

}

Layout.propTypes = {
  userImage: Proptypes.string,
  email: Proptypes.string,
  processInProgress: Proptypes.bool,
  notificationState: Proptypes.any,
  auth: Proptypes.string,
  privilege: Proptypes.object,
  organization: Proptypes.string,
  signOut_action: Proptypes.func,
}

const mapStateToProps = (state) => {
  return {
    user: state.auth.user,
    userImage: state.auth.user && state.auth.user.imageUrl !== undefined ? state.auth.user.imageUrl : "./images/avatar.jpg",
    email: state.auth.user ? state.auth.user.email : undefined,
    processInProgress: state.misc.processInProgress,
    notificationState: state.misc.notification,
    auth: state.auth.initialized ? state.auth.initialized : undefined,
    organization: state.auth && state.auth.user ? state.auth.user.organization : undefined,
    privilege: state.auth.user ? state.auth.user.access : undefined,
    access: state.menuaccess.currentMenuAccess || null,
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    signOut_action: () => dispatch(signout()),
    fetchMenuAccess_action: (name) => dispatch(fetchMenuAccess(name))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Layout)