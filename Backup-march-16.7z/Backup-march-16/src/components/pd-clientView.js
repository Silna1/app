import {
    Button,
    Icon,
    Grid,
    Radio,
    RadioGroup,
    ValidatorFormControlLabel,
    Checkbox,
    Box,
    Card
} from '@mui/material'
import React, { Suspense, lazy, useEffect, useState } from "react";
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import { styled } from '@mui/system'
import TextField from '@mui/material/TextField';
import { ValidatorForm, TextValidator } from 'react-material-ui-form-validator'
import { makeStyles, createStyles } from '@material-ui/core/styles';
import AdapterDateFns from '@mui/lab/AdapterDateFns'
import LocalizationProvider from '@mui/lab/LocalizationProvider'
import { DatePicker } from '@mui/lab'
import Typography from '@mui/material/Typography';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Cancel';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import {useHistory} from 'react-router-dom';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import {
    fetchClients,
    deleteClient,
    addClient,
    updateClient,
    viewClient,
  } from "../store/actions/client_action";
  import { processInProgress } from '../store/actions/misc_action';
  import {config} from '../config';
  import countries from './utils/countries.json';
  import CheckIcon from '@mui/icons-material/Check';

const TextInput = styled(TextField)(() => ({
    width: '100%',
    marginBottom: '16px',
}))

const CustomSelect = styled(Select)(() => ({
    width: '100%',
    marginBottom: '16px',
}))


const useStyles = makeStyles(()=>
    createStyles({
        logo: {
            marginLeft:'100px',
            marginTop:'20px',
            '& img': {
                width: '300px',
                border: 'inset',
                height: '300px'
            }
        }
    })
)

const defaultClient = {
        clientName: '',
        clientLogo: "",
        phoneNumber: '',
        active: true,
        createDate: '',
        email: '',
        lastUpdate: '',
        clientType:'',
        sector:'',
        address1:'',
        address2:'',
        city:'',
        state:'',
        country: [],
        pinCode:''
}

const defaultError = {
    clientName: '',
    email: '',
    phoneNumber: '',
    clientLogo: '',
    clientType:'',
    sector:'',
    address1:'',
    city:'',
    state:'',
    country: '',
    pinCode:''
}

const fieldRequiredText = 'this field is required';

const ClientView = (props) => {
    const {match, currentClient, viewClient_action, deleteClient_action, updateClient_action ,sector} = props;
    const {id} = match.params;
    const history = useHistory();
    const classes = useStyles();
    const [client, setClient] = useState({...defaultClient});
    const [isEdit, setIsEdit] = useState(false)
    const [errors, setErrors] = useState({...defaultError});
    const [isModalOpen,setIsModalOpen] = useState(false);

    const clientTypeList = config.Privilege;
    const countryList = countries;

    useEffect(() => {
        if(id) {
            viewClient_action(id);
        }
    }, [])

    useEffect(() => {
        if(currentClient) {
            console.log('currentClient', currentClient)
            setClient({...currentClient});
        }
    }, [currentClient])

    const handleSubmit = () => {
        console.log("silna update ",client);  
        if(validateData(client)) {
            setIsEdit(false);
            updateClient_action(client)
            props.history.push("/clients");
        } 
    }

    const handleDelete = () => {
        console.log(id)

        deleteClient_action(client);
        props.history.push("/clients");
    }

    const handleChange = (key, event) => {
        console.log(key, event)
        const clientProxy = {...client};
        clientProxy[key] = event.target.value;
        setClient(clientProxy);
    }

    const handleEdit = () => {
        setIsEdit(!isEdit);
        if(isEdit) {
            setClient({...currentClient});
            setErrors({...defaultError})
        }
    }

    const handleBack = () => {
        history.goBack();
    }

    const handleCancel = () => {
        setIsModalOpen(false);
    }


    const validateData = (data) => {
        const errorProxy = {...errors};
        let valid = true;
        errorProxy.clientName = !data.clientName ? fieldRequiredText : '';
        errorProxy.locationId = !data.locationId ? fieldRequiredText : '';
        errorProxy.email = !data.email ? fieldRequiredText : validateEmail(data.email) ? '' : 'email is not valid';
        errorProxy.phoneNumber = !data.phoneNumber ? fieldRequiredText : '';
        console.log(errorProxy);
        console.log("validate before update",data);
        setErrors(errorProxy);
        Object.values(errorProxy).forEach(item => {
            if(item && valid) {
                valid = false
            }
        })
        return valid;
    }

    const validateEmail = (email) => {
        var re = /\S+@\S+\.\S+/;
        return re.test(email);
    }

    return (
        <div>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
                marginTop:'50px'
              }}
            >
              <Typography
                sx={{ m: 1,color:'#19b4dd',fontWeight: 600 }}
                variant="h4"
              >
                {currentClient?.clientName || ''}
              </Typography>
              <Button onClick={handleBack} style={{color:"#19b4dd",mr: 1}} variant="outlined" startIcon={<ArrowBackIcon />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Go Back
                    </Typography>
                </Button>
            </Box>
            <Card>
            {/* <ValidatorForm onSubmit={handleSubmit} onError={() => null}> */}
                <Grid container spacing={2}>
                    <Grid item lg={6} md={6} sm={12} xs={12}>
                        <div className={classes.logo} >
                            <img src={client.clientLogo} alt="logo" />
                        </div>
                    </Grid>
                    <Grid item lg={6} md={6} sm={12} xs={12} sx={{ mt: 2 }}>
                        <TextInput
                            type="text"
                            name="clientName"
                            onChange={(e) => handleChange('clientName', e)}
                            value={client.clientName}
                            label="ClientName (Min length 4, Max length 9)"
                            disabled={!isEdit}
                            error={!!errors.clientName}
                            helperText={errors.clientName}
                        />
                        <TextInput
                            type="text"
                            name="address1"
                            onChange={(e) => handleChange('address1', e)}
                            value={client.address1}
                            label="Address 1"
                            disabled={!isEdit}
                            error={!!errors.address1}
                            helperText={errors.address1}
                        />
                        <TextInput
                            type="text"
                            name="address2"
                            onChange={(e) => handleChange('address2', e)}
                            value={client.address1}
                            label="Address 2"
                            disabled={!isEdit}
                            error={!!errors.address2}
                            helperText={errors.address2}
                        />
                        <TextInput
                            type="text"
                            name="city"
                            onChange={(e) => handleChange('city', e)}
                            value={client.address1}
                            label="City "
                            disabled={!isEdit}
                            error={!!errors.city}
                            helperText={errors.city}
                        />
                        <TextInput
                            type="text"
                            name="state"
                            onChange={(e) => handleChange('state', e)}
                            value={client.state}
                            label="State"
                            disabled={!isEdit}
                            error={!!errors.state}
                            helperText={errors.state}
                        />
                       {/* <TextInput
                            label="Address 1"
                            value={client.address1}
                            type="text"
                            name="clientId"
                            disabled
                       />*/}
                        <TextInput
                            label="Email"
                            onChange={(e) => handleChange('email', e)}
                            type="email"
                            name="email"
                            value={client.email}
                            disabled={!isEdit}
                            error={errors.email}
                            helperText={errors.email}
                        />
                         <TextInput
                            label="Mobile Nubmer"
                            onChange={(e) => handleChange('phoneNumber', e)}
                            type="number"
                            name="phoneNumber"
                            value={client.phoneNumber}
                            disabled={!isEdit}
                            error={errors.phoneNumber}
                            helperText={errors.phoneNumber}
                        />
                         <TextInput
                            label="Pin code"
                            onChange={(e) => handleChange('pinCode', e)}
                            type="number"
                            name="pinCode"
                            value={client.pinCode}
                            disabled={!isEdit}
                            error={errors.pinCode}
                            helperText={errors.pinCode}
                        />
                       <InputLabel id="demo-simple-select-label">Client Type</InputLabel>
                        <CustomSelect
                            value={client.clientType}
                            label="Client Type"
                            name='clientType'
                            id="demo-simple-select"
                            disabled={!isEdit}
                            onChange={(e) => handleChange('clientType',e)}
                        >
                            {clientTypeList.map(item => 
                                <MenuItem value={item}>{item}</MenuItem>
                            )}
                        </CustomSelect>
                        <InputLabel id="demo-simple-select-label">Sector</InputLabel>
                        <CustomSelect
                            value={client.sector}
                            name='sector'
                            variant='outlined'
                            id="demo-simple-select"
                            disabled={!isEdit}
                            onChange={(e) => handleChange('sector',e)}
                        >
                            {sector?.map(item => {
                                return (
                                    <MenuItem key={item.sectorId} value={item.sectorId}>{item.name}</MenuItem>
                                )
                            })}
                        </CustomSelect>
                        <InputLabel id="demo-simple-select-label">Country</InputLabel>
                        <CustomSelect
                            value={client.country}
                            label="Country"
                            multiple
                            disabled={!isEdit}
                            onChange={(e) => handleChange('country',e)}
                        >
                            {countryList.map(item => 
                                <MenuItem value={item.code}>{item.name}</MenuItem>
                            )}
                            </CustomSelect>
                <Box sx={{ m: 10,alignItems:'right' }}>
                <Button onClick={handleEdit} style={{color:"#19b4dd",mr: 1}}  variant="outlined" startIcon={!isEdit ? <EditIcon /> : <CancelIcon/>}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        {!isEdit ? "Edit" : "Cancel"}
                    </Typography>
                </Button>
                {isEdit &&
                    <Button onClick={handleSubmit} style={{color:"#19b4dd",mr: 1}}  variant="outlined" startIcon={<SaveIcon />}>
                        <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                            Save
                        </Typography>
                    </Button>
                }
                
                <Button onClick={() => setIsModalOpen(true)} style={{color:"#19b4dd",mr: 1}} variant="outlined" startIcon={<DeleteIcon />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Delete
                    </Typography>
                </Button>
                </Box>   
                    </Grid>
                    
                </Grid>
                 
            {/* </ValidatorForm> */}
            </Card>
            <Dialog onClose={handleCancel} open={isModalOpen}>
              <DialogTitle>Alert</DialogTitle>
              <DialogContent style={{paddingTop: '20px'}}>
                Are you sure ,you want to delete the client?
              </DialogContent>
              <DialogActions>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={handleDelete} startIcon={<CheckIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Confirm
                    </Typography>
                </Button>
                <Button style={{color:"#19b4dd",mr: 1 }} variant="outlined" onClick={handleCancel} startIcon={<CancelIcon  />}>
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Cancel
                    </Typography>
                </Button>
              </DialogActions>
            </Dialog>
        </div>
    )
}

ClientView.propTypes = {
    selectedClient: PropTypes.string,
    clientsarray: PropTypes.array,
    addClient_action:PropTypes.func,
    processInProgress_action: PropTypes.func,
}

const mapStateToProps = (state) => {
    console.log("state of clients",state);
    return {
        privilege: state.auth && state.auth.user ? state.auth.user.access : undefined,
        clientsarray: state.client.value,
        currentClient: state.client.currentClient,
        sector: state.client.sector
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        addClient_action:(clientsarray)=>dispatch(addClient(clientsarray)),
        processInProgress_action: (status) => dispatch(processInProgress(status)),
        viewClient_action: (id) => dispatch(viewClient(id)),
        deleteClient_action: (client) => dispatch(deleteClient(client)),
        updateClient_action: (client) => dispatch(updateClient(client))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ClientView);

