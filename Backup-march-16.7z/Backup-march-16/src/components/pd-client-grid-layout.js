// ********Main imports**************
import React, { useEffect } from "react";
import PropTypes from "prop-types";
import { config } from "../config";
import { FetchAPI } from "../fetch.js";

// ********Material ui imports**************

import TablePagination from "@material-ui/core/TablePagination";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Divider from "@material-ui/core/Divider";
import Fab from "@material-ui/core/Fab";
import cloneDeepWith from "lodash/cloneDeepWith";
import Container from '@material-ui/core/Container';
import { styled } from '@mui/material/styles';
import clsx from 'clsx';
import PerfectScrollbar from 'react-perfect-scrollbar';
import {
  Avatar,
  Box,
  Checkbox,
  Typography
} from '@mui/material';
import { getInitials } from './utils/get-initials';



// ********Component imports**************
import { connect } from "react-redux";
import FileUpload from "./pd-file-upload";
import PartPrediction from "./pd-part-prediction";
import TablePaginationActions from "./pd-pagination";
import { useStyles2 } from "../Styles/dahboardLayout_styles";
import {
  fetchClients,
  deleteClient,
  addClient,
  updateClient,
} from "../store/actions/client_action";
import {
  searchInProgress,
  getPartsData,
  getTotalPartsCount,
  totalPartsCount,
} from "../store/actions/part_action";
import {
  processInProgress,
  setSelectedClient,
} from "../store/actions/misc_action";
import color from "@material-ui/core/colors/amber";
import { Button,Modal,Form,Spinner,Alert } from 'react-bootstrap';
import {
  Card,
  CardActions,
  CardHeader,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableRow,
} from '@material-ui/core';
import {
    TextField,
    InputAdornment,
    SvgIcon
  } from '@mui/material';
import TableHead from '@mui/material/TableHead';
import ArrowRightIcon from '@material-ui/icons/ArrowRight';
import Scrollbar from 'react-scrollbar';
import { Link } from 'react-router-dom';
import ButtonBase from '@mui/material/ButtonBase';




const axios = require("axios");
const Img = styled('img')({
    margin: 'auto',
    display: 'block',
    maxWidth: '100%',
    maxHeight: '100%',
  });


const useStyles = theme => ({
  root: {},
  content: {
    padding: 0,
    marginTop:'100px'
  },
  inner: {
    minWidth: 350,
    overflow: 'auto',
    height: 350,
  },
  statusContainer: {
    display: 'flex',
    alignItems: 'center'
  },
  status: {
    marginRight: theme.spacing(1)
  },
  actions: {
    justifyContent: 'flex-end'
  },
  "&.MuiGrid-grid-sm-true": {
    maxWidth :'100px'
  }
  
});


function ClientLayoutGrid(props) {
  
  const {
    clientsarray,
    updateClient_action,
    fetchClients_action,
    deleteClient_action,
    addClient_action,
    privilege,
    client,
    parts,
    clientList,
    className, 
    ...rest
  } = props;

 
  const [clients, setClients] = React.useState(client);
  //called First time when component mounts and every other time when part add is called


  //create REF to call child function from parent
  const child = React.createRef();

  const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    width:'200px',
    height:'200px',
    color: theme.palette.text.secondary,

  }));

  const handleChange = (event) => {
    setClients(event.target.value);
  };


  // {/* Searchbar with camera icon button */}
  return (
    
    <React.Fragment>

      <Box
      sx={{
        p: 2,
        margin: 'auto',
        //maxWidth: 500,
        flexGrow: 1,
        marginTop:'50px',
        backgroundColor: (theme) =>
          theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
          boxShadow: "0 8px 40px -12px rgba(0,0,0,0.3)",
          "&:hover": {
          boxShadow: "0 16px 70px -12.125px rgba(0,0,0,0.3)"
          },
      }}
        >
<Grid container xs={12} sm={12} lg={12} 
  sx={{marginTop:'100px'}} spacing={8}>

{ clientsarray && clientsarray.map((client) => (
  
	<Grid item xs={12} sm={6} lg={4} spacing={8} sx={{transition: "0.3s cubic-bezier(.47,1.64,.41,.8)",
  boxShadow: "0 4px 20px 0 rgba(49, 62, 72, 1)",
  borderRadius: 0,
  "& button": {
      marginLeft: 0
  },
  "&:hover": {
      transform: "scale(1.04)",
      boxShadow: "0 4px 20px 0 rgba(0,0,0,0.12)",
      cursor: "pointer"
  },}}>
    <Card
    sx={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      boxShadow: "0 8px 40px -12px rgba(0,0,0,0.3)",
          "&:hover": {
          boxShadow: "0 16px 70px -12.125px rgba(0,0,0,0.3)"
          },
    }}
    {...rest}
  >
    <CardContent>
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          pb: 3,
          boxShadow: "0 20px 40px -12px rgba(0,0,0,5)",
          "&:hover": {
          boxShadow: "0 16px 70px -12.125px rgba(0,0,0,5)"
          },
        }}
      >
        
      </Box>
      <Typography
        align="center"
        color="textPrimary"
        gutterBottom
        variant="h5"
      >
      	<ButtonBase sx={{ width: 150, height: 150 ,alignItems:'center',border: 'inset' }} component={Link} to={`client/edit/${client.id}`} >
				<Img alt="complex" src={client.clientLogo} />
				</ButtonBase>
      </Typography>
    </CardContent>
    <Box sx={{ flexGrow: 1 }} />
    <Divider />
    <Box sx={{ p: 2 }}>
      <Grid
        container
        spacing={2}
        sx={{ justifyContent: 'space-between' }}
      >
        <Grid
          item
          sx={{
            alignItems: 'center',
            display: 'flex'
          }}
        >
         <Divider/>
                        <Typography variant="overline" display="block"   color={"textPrimary"} gutterBottom noWrap>
                            Name: {client.clientName}
                        </Typography>
                        <Divider/>
                        <Typography variant="overline" display="block"  color={"textPrimary"} gutterBottom noWrap>
                            Email : {client.email}
                        </Typography>
                        <Divider/>
                        <Typography variant="overline" display="block"  color={"textPrimary"} gutterBottom>
                            Phone Number : {client.phoneNumber}
                        </Typography>
        </Grid>
      </Grid>
    </Box>
  </Card>
      </Grid>))}
 
    </Grid>
    </Box>
      
    </React.Fragment>
  );
}

ClientLayoutGrid.propTypes = {
  partData: PropTypes.array,
  searchProgress_action: PropTypes.func,
  processInProgress_action: PropTypes.func,
  getPartsData_action: PropTypes.func,
  getTotalPartCount_action: PropTypes.func,
  setSelectedClient_action: PropTypes.func,
  setTotalpartCount_action: PropTypes.func,
  lastEvaluatedKey: PropTypes.any,
  organization: PropTypes.string,
  selectedClient: PropTypes.string,
  client: PropTypes.string,
  privilege: PropTypes.any,
  parts: PropTypes.object,
  clientList: PropTypes.any,
  clientsarray:PropTypes.array,
  fetchClients:PropTypes.func,
  updateClient:PropTypes.func,
};

const mapStateToProps = (state) => {
  return {
    parts: state.parts,
    selectedClient: state.misc.selectedClient
      ? state.misc.selectedClient
      : undefined,
    clientList: state.misc.clients,
    lastEvaluatedKey: state.parts.LastEvaluatedKey,
    privilege: state.auth.user ? state.auth.user.access : undefined,
    organization: state.auth.user ? state.auth.user.organization : undefined,
   
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    searchProgress_action: (status) => dispatch(searchInProgress(status)),
    processInProgress_action: (status) => dispatch(processInProgress(status)),
    getPartsData_action: (organization) =>
      dispatch(
        getPartsData({ lastEvaluatedKey: null, organization: organization })
      ),
    setSelectedClient_action: (client) => dispatch(setSelectedClient(client)),
    setTotalpartCount_action: (count) => dispatch(totalPartsCount(count)),
    getTotalPartCount_action: (organization) =>
    dispatch(getTotalPartsCount(organization)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ClientLayoutGrid);
