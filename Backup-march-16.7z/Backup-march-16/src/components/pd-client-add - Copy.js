import {
    Button,
    Icon,
    Grid,
    Radio,
    RadioGroup,
    ValidatorFormControlLabel,
    Checkbox,
    Box,
    Card
} from '@mui/material'
import React, { Suspense, lazy } from "react";
import { styled } from '@mui/system'
import { useState, useEffect } from 'react'
import { ValidatorForm, TextValidator } from 'react-material-ui-form-validator'
import AdapterDateFns from '@mui/lab/AdapterDateFns'
import LocalizationProvider from '@mui/lab/LocalizationProvider'
import { DatePicker } from '@mui/lab'
import Typography from '@mui/material/Typography';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom'
import {
    fetchClients,
    deleteClient,
    addClient,
    updateClient,
  } from "../store/actions/client_action";
  import { processInProgress } from '../store/actions/misc_action';
  import { BrowserRouter as Router,NavLink, Link, Route, Switch } from 'react-router-dom';
  const Clients = lazy(() => import('./pd-clients'));

const TextField = styled(TextValidator)(() => ({
    width: '100%',
    marginBottom: '16px',
}))

class ClientAdd extends React.Component {

    constructor(props) {
        super(props);
        this.clientObj = React.createRef();
        this.state = {
            isValidated: false,
            isValuesNegative: false
        }
        this.emptyClientObj = { ...this.client };
    }

    client = {
        clientName: '',
        clientId: '',
        clientLogo: " ",
        phoneNumber: 123,
        active: true,
        createDate: '',
        locationId: '',
        email: 'developer@immensalabs.com',
        lastUpdate: ''
    }

    

    componentDidMount() {
       // this.props.processInProgress_action(true);
    }

    vaidateData = (data) => {
        /*for (const element in data) {
            if (data.hasOwnProperty(element)) {
                if (element === 'size') {
                    let sizeObj = data[element];
                    for (const item in sizeObj) {
                        if (this.isEmpty(sizeObj[item]) && Number(sizeObj[item]) < 0) {
                            this.setState({ isValuesNegative: true });
                            return false;
                        }
                        else if (!this.isEmpty(sizeObj[item])) {
                            this.setState({ isValuesNegative: false });
                            return false;
                        }
                    }
                }
                if (!this.isEmpty(data[element]))
                    return false;
            }
        }*/
        this.setState({ isValuesNegative: false });
        return true;
    }

    handleSubmit = () => {
        console.log("silan printer",this.client);
        this.setState({ isValidated: true });
        if (this.vaidateData(this.client)) {
            this.setState({ isValidated: false });
            this.props.addClient_action(this.client);
            this.client = { ...this.emptyClientObj };
        }
          
      
    }

    handleChange = (key) => (event) => {
       
            this.client = { ...this.client, [key]:event.target.value };
        }
    
    render(){
        const { client,clientsarray } = this.props;
    return (
        <div>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                m: -1,
                marginTop:'50px'
              }}
            >
              <Typography
                sx={{ m: 1,color:'#19b4dd',fontWeight: 600 }}
                variant="h6"
              >
                Add new Client
              </Typography>
            </Box>
            <Card>
            <ValidatorForm onSubmit={this.handleSubmit} onError={() => null}>
                <Grid container spacing={6}>
                    <Grid item lg={6} md={6} sm={12} xs={12} sx={{ mt: 2 }}>
                        <TextField
                            type="text"
                            name="clientName"
                            onChange={this.handleChange('clientName')}
                            
                            label="ClientName (Min length 4, Max length 9)"
                            errorMessages={['this field is required']}
                        />
                        <TextField
                            label="ClienId"
                            onChange={this.handleChange('clientId')}
                            type="text"
                            name="clientId"
                            
                            errorMessages={['this field is required']}
                        />
                        <TextField
                            label="Email"
                            onChange={this.handleChange('email')}
                            type="email"
                            name="email"
                           
                            errorMessages={[
                                'this field is required',
                                'email is not valid',
                            ]}
                        />

                        <TextField
                            label="Create Date"
                            placeholder='MM/DD/YYYY'
                            onChange={this.handleChange('createDate')}
                            type="text"
                            name="createDate"
                           
                            errorMessages={['this field is required']}
                        />

                        <TextField
                            sx={{ mb: 4 }}
                            label="Location"
                            onChange={this.handleChange('locationId')}
                            type="text"
                            name="locationId"
                           
                            errorMessages={['this field is required']}
                        />
                    </Grid>

                    <Grid item lg={6} md={6} sm={12} xs={12} sx={{ mt: 2 }}>
                        <TextField
                            label="Mobile Nubmer"
                            onChange={this.handleChange('phoneNumber')}
                            type="number"
                            name="phoneNumber"
                            
                            errorMessages={['this field is required']}
                        />
                        <TextField
                            label="Client Logo"
                            onChange={this.handleChange('clientLogo')}
                            type="string"
                            name="clientLogo"
                            
                            errorMessages={['this field is required']}
                        />
                        <TextField
                            label="Active"
                            onChange={this.handleChange('active')}
                            type="boolean"
                            name="active"
                            
                            errorMessages={['this field is required']}
                        />
                        <TextField
                            label="Last Update"
                            placeholder='MM/DD/YYYY'
                            onChange={this.handleChange('lastUpdate')}
                            type="text"
                            name="lastUpdate"
                           
                            errorMessages={['this field is required']}
                        />
                        
                        
                    </Grid>
                </Grid>
                <Button color="primary" variant="contained" type="submit">
                   
                    <Typography sx={{ pl: 1, textTransform: 'capitalize' }}>
                        Add
                    </Typography>
                </Button>
            </ValidatorForm>
            </Card>
        </div>
    )
    }
}
ClientAdd.propTypes = {
    selectedClient: PropTypes.string,
    clientsarray: PropTypes.array,
    fetchClients_action: PropTypes.func,
    addClient_action:PropTypes.func,
    processInProgress_action: PropTypes.func,
}

const mapStateToProps = (state) => {
    console.log("state of clients",state);
    return {
        privilege: state.auth && state.auth.user ? state.auth.user.access : undefined,
        clientsarray: state.client.value
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        addClient_action:(clientsarray)=>dispatch(addClient(clientsarray)),
        processInProgress_action: (status) => dispatch(processInProgress(status))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ClientAdd);

