//es6 provide default value like if state is not set it is set to initial state
const initialSatte={
  progressVal:'0'
}
const progress = (state = initialSatte, action) => {
  const newState = { ...state };

  switch (action.type) {
    case "UPDATE_PROGRESS_VALUE":
      return {
        ...state,
        progressVal: action.payload,
      };
    default:
      break;
  }
  return newState;
};

export default progress;
