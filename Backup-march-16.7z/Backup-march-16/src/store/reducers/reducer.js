import { combineReducers } from 'redux'
import parts from './part_reducer'
import users from './user_reducer'
import auth from './auth_reducer'
import printer from './printer_reducer'
import misc from './misc_reducer'
import automl from './automl_reducer'
import progress from './progress'
import client from './client_reducer'
import location from './location_reducer'
import project from './project_reducer'
import menuaccess from './menuAccess_reducer'

export default combineReducers({
    parts,
    users,
    auth,
    printer,
    misc,
    automl,
    progress,
    client,
    location,
    project,
    menuaccess
});