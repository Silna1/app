
const client_reducer = (state = {}, action) => {
    switch (action.type) {
        case 'RECEIVE_CLIENTS':
            return {
                ...state,
                value: action.value
            }
        case 'FAIL_CLIENTS':
            return {
                ...state
            };
        case 'REMOVE_CLIENT':
            console.log(state);
            return {
                ...state,
                value: state.value.filter((ele) => ele.clientName !== action.value.clientName)
            };
        case 'ADD_CLIENT':
            console.log("ADD CLIENT REDUCER",state);
            return {
                ...state,
                value: state.value.splice(0, 0, action.value[0])
            };
        case 'UPDATE_CLIENT':
            return {
                ...state,
                value: state.value.map((ele, index) => {
                    if (ele.clientName !== action.value.clientName)
                        return ele;
                    return {
                        ...action.value
                    }
                })
            };
        case 'VIEW_CLIENT':
            return {
                ...state,
                currentClient: action.value
            }
        case "SELECTED_CLIENT":
            return {
                ...state,
                ...state.client,
                selectedClient: action.value.Items[0],
      };
        case "CLIENT_SECTOR":
            return {
                ...state,
                sector: action.value
            }
        default:
            return state;
    }
}

export default client_reducer;