//es6 provide default value like if state is not set it is set to initial state
const automl_reducer = (state = {}, action) => {

    const newState = { ...state };

    switch (action.type) {
        case 'TRAINING_INFO':
            return {
                ...state,
                lastTrainingInfo: action.value
            };
        default: break;
    }
    return newState;
}

export default automl_reducer;