
const auth_reducer = (state = {}, action) => {
    switch (action.type) {
        case 'AUTH_INITIALIZED':
            return {
                ...state,
                initialized: action.value
            }
        case 'SET_USER':
            return {
                ...state,
                user: action.value
            }
        case 'UPDATE_USER_AUTH':
            return {
                ...state,
                user: action.value
            }
        case 'SET_COGNITO_USER':
            return {
                ...state,
                cognitoUser: action.value
            }
        default:
            return state;
    }
}
export default auth_reducer;