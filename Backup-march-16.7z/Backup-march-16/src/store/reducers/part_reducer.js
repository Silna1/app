//es6 provide default value like if state is not set it is set to initial state
const part_reducer = (state = {}, action) => {
  const newState = { ...state };

  switch (action.type) {
    case "PARTS_DATA":
      // eslint-disable-next-line no-case-declarations
      let newParts;
      if (action.value.setNewParts) {
        newParts = [...action.value.Items];
      } else if (
        state &&
        state.Items &&
        Object.entries(state.Items).length > 0 &&
        action.value.Items &&
        Object.entries(action.value.Items).length > 0 &&
        state.Items[0].organization === action.value.Items[0].organization
      )
        newParts = [...state.Items, ...action.value.Items];
      else newParts = [...action.value.Items];
      return {
        ...state,
        ...action.value,
        Items: [...newParts],
        LastEvaluatedKey: action.value.LastEvaluatedKey
          ? action.value.LastEvaluatedKey
          : {},
      };

      case "PARTS_DATA2":
        // eslint-disable-next-line no-case-declarations
        console.log("Inside reducer",action.value.Items);
        let newParts2;
        if (action.value.setNewParts) {
          console.log("Inside reducer",action.value.Items);
          newParts2 = [...action.value.Items];
        } else if (
          state &&
          state.Items &&
          Object.entries(state.Items).length > 0 &&
          action.value.Items &&
          Object.entries(action.value.Items).length > 0 &&
          state.Items[0].organization === action.value.Items[0].organization
        )
          newParts2 = [...state.Items, ...action.value.Items];
        else newParts2 = [...action.value.Items];
        return {
          ...state,
          ...action.value,
          Items2: [...newParts2],
          LastEvaluatedKey: action.value.LastEvaluatedKey
            ? action.value.LastEvaluatedKey
            : {},
        };

  
        case "GRAPH_PARTS_DATA":
          return {
            ...state,
            ...state.parts,
            GraphItems: [...action.value],
          };

          case "MATERIALS_PARTS_DATA":
            return {
              ...state,
              ...state.parts,
              MaterialsParts: [...action.value],
            };
          

    case "SELECTED_PART":
      return {
        ...state,
        ...state.parts,
        selectedPart: action.value.Items[0],
      };
    case "EMPTY_SELECTED_PART":
      return {
        ...state,
        ...state.parts,
        selectedPart: {},
      };
    case "Add_NEW_PART":
      // eslint-disable-next-line no-case-declarations
      let parts;
      if (state.Items[0].organization === action.value.organization)
        parts = {
          ...state,
          ...state.Items.unshift(action.value),
        };
      else
        parts = {
          ...state,
          ...state.Items,
        };
      return parts;
    case "PART_MATERIALS":
      return {
        ...state,
        materials: action.value,
      };
  


        case "PYRAMID_DATA":
          return {
            ...state,
            ...state.parts,
            PyramidData: [...action.value],
          };


        case 'PART_CATEGORIES':
            return {
                ...state,
                categories:action.value
            };

            case ' PART_ALL_CATEGORIES':
              return {
                  ...state,
                  allcategories:["1","2"]
              };

              
           

            case 'GET_COMMENTS':
              return{
                  ...state,
                  allcomments: [...action.value]
              };
            
    case "PART_UPDATE": {
      let filteredPart;
      if (state && state.Items) {
        filteredPart = state.Items.filter((ele) => ele.id !== action.value.id);
        filteredPart.unshift(action.value);
      } else {
        filteredPart = [action.value];
      }
      return {
        ...state,
        Items: [...filteredPart],
      };
    }
    case "PART_DELETE": {
      let filteredPart;
      if (state && state.Items) {
        filteredPart = state.Items.filter((ele) => ele.id !== action.value.id);
      }
      return {
        ...state,
        Items: [...filteredPart],
      };
    }
    case "SEARCH_PROGRESS": {
      return {
        ...state,
        searchStatus: action.value,
      };
    }
    case "TOTAL_PARTS_COUNT": {
      return {
        ...state,
        totalPartsCount: action.value,
      };
    }
    case "DUPLICATES_FOUND": {
      return {
        ...state,
        duplicateParts: [...action.value],
      };
    }
    case "DASHBOARD_CHART_DATA": {
      return {
        ...state,
        dashboardChartData: action.value,
      };
    }
    default:
      break;
  }
  return newState;
};

export default part_reducer;
