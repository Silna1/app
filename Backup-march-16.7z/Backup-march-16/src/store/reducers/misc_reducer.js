const misc_reducer = (state = {}, action) => {

    const newState = { ...state };

    switch (action.type) {
        case 'PROGRESSBAR_STATUS':
            return {
                ...state,
                processInProgress: action.value
            }
        case 'NOTIFICATION_STATUS':
            return {
                ...state,
                notification: action.value
            }
        case 'CLIENT_LIST':
            return {
                ...state,
                clients: action.value
            }
        case 'SELECTED_ClIENT': {
            return {
                ...state,
                selectedClient: action.value
            }
        }
        default: break;
    }
    return newState;
}

export default misc_reducer;