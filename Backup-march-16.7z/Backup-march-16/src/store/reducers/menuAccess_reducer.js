const menuaccess_reducer = (state = {}, action) => {

    switch (action.type) {
        case 'CURRENT_MENU_ACCESS':
            return {
                ...state,
                currentMenuAccess: action.value
            }
        default: {
            return {
                ...state,
            }
        }
    }
}

export default menuaccess_reducer;