
const initialState  = {
    projects : []
};

const  project_reducer = (state = initialState, action) => {
    switch (action.type) {
        case 'ADD_PROJECT':
            return {
                ...state,
                projects: state.projects.concat(action.value)
            }
        case 'RECEIVE_PROJECT':
            return {
                ...state,
                projects: action.value
            }
        case 'UPDATE_PROJECT':
            return {
                ...state,
                projects: state.projects.map((ele) => {
                    if (ele.projectId !== action.value.projectId)
                        return ele;
                    return {
                        ...action.value
                    }
                })
            };
        case 'REMOVE_PROJECT':
            return {
                ...state,
                projects: state.projects.filter((ele) => ele.projectId !== action.value.projectId)
            };
        case 'RECEIVE_CLIENT_PROJECT':
                return {
                    ...state,
                    clientProject: action.value
                }
        case 'RECEIVE_PROJECT_LOCATION':
                    return {
                        ...state,
                        projectLocation: action.value
            }
        default:
            return state;
    }
}

export default  project_reducer;