
//es6 provide default value like if state is not set it is set to initial state
const user_reducer = (state = {}, action) => {

    const newState = { ...state };

    switch (action.type) {
        case 'RECEIVE_USERS':
            return {
                ...state,
                usersdata: action.value
            };
        case 'USER_DATA':
            return {
                ...state,
                usersdata: [...action.value]
            };
        case 'FAIL_USERS':
            return {
                ...state
            };
        case 'FAIL_GROUP':
            return {
                ...state
            };
        case 'REMOVE_USER':
            return {
                ...state,
                usersdata: state.usersdata.filter((ele) => ele.email !== action.value.email)
            };
        case 'ADD_USER':
            return {
                ...state,
                usersdata: state.usersdata.concat(action.value)
            };
        case 'UPDATE_USER':
            return {
                ...state,
                usersdata: state.usersdata.map((ele, index) => {
                    if (ele.email !== action.value.email)
                        return ele;
                    return {
                        ...ele,
                        "privilege": action.value.privilege,
                        'name': action.value.name
                    }
                })
            };
        case 'ADD_GROUP':
            return {
                ...state,
                groupdata: state.groupdata?.concat(action.value)
            };              
        default: break;
    }
    return newState;
}

export default user_reducer;