
const initialState  = {
    locations : [],
    clientLocations : [],
};

const location_reducer = (state = initialState, action) => {
    switch (action.type) {
        case 'ADD_LOCATION':
            return {
                ...state,
                locations: state.locations.concat(action.value)
            }
        case 'RECEIVE_LOCATION':
            return {
                ...state,
                locations: action.value
            }
        case 'RECEIVE_CLIENT_LOCATION':
            return {
                ...state,
                clientLocations: action.value
            }
        case 'RECEIVE_LOCATION_BYID':
            return {
                ...state,
                locationbyid: action.value
            }
            case 'DELETE_LOCATION':
                console.log(state);
                return {
                    ...state,
                    locations: state.locations.filter((ele) => ele.id !== action.value.id)
                };
                case 'UPDATE_LOCATION':
                    return {
                        ...state,
                        locations: state.locations.map((ele, index) => {
                            if (ele.id !== action.value.id)
                                return ele;
                            return {
                                ...action.value
                            }
                        })
                    };    
        default:
            return state;
    }
}

export default location_reducer;