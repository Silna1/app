
const printer_reducer = (state = {}, action) => {
    switch (action.type) {
        case 'RECEIVE_PRINTERS':
            return {
                ...state,
                value: action.value
            }
        case 'FAIL_PRINTERS':
            return {
                ...state
            };
        case 'REMOVE_PRINTER':
            return {
                ...state,
                value: state.value.filter((ele) => ele.name !== action.value.name)
            };
        case 'ADD_PRINTER':
            return {
                ...state,
                value: state.value.concat(action.value)
            };
        case 'UPDATE_PRINTER':
            return {
                ...state,
                value: state.value.map((ele, index) => {
                    if (ele.name !== action.value.name)
                        return ele;
                    return {
                        ...action.value
                    }
                })
            };
        default:
            return state;
    }
}

export default printer_reducer;