import { createStore, applyMiddleware } from 'redux';
import reducer from "./reducers/reducer";
import thunk from "redux-thunk";
import { composeWithDevTools } from 'redux-devtools-extension';
import storage from "redux-persist/lib/storage";
import { persistStore, persistReducer } from "redux-persist";

const persistConfig = {
    key: "root",
    storage,
    blackList: [reducer.misc, reducer.auth]
};

const reducers = persistReducer(persistConfig, reducer);
const store = createStore(reducers, composeWithDevTools(applyMiddleware(thunk)));
export const persistor = persistStore(store);
export default store;