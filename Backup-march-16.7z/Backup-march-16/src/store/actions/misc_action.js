import { FetchAPI } from '../../fetch.js';
import { config } from '../../config'

// **************actions**************

export const processInProgress = (data) => {
    return {
        type: "PROGRESSBAR_STATUS",
        value: data
    }
}

export const notificationStatus = (data) => {
    return {
        type: "NOTIFICATION_STATUS",
        value: data
    }
}

export const clientList = (data) => {
    return {
        type: "CLIENT_LIST",
        value: data
    }
}

export const setSelectedClient = (data) => {
    return {
        type: 'SELECTED_ClIENT',
        value: data
    }
}

// **************actions creator**************

export const notification = (status, delay = 0) => {
    return dispatch => {
        setTimeout(() => {
            dispatch(notificationStatus(status));
        }, delay)
    }
}

export const clients = (organization) => {
    return dispatch => {
      
            var params = {
                "userPoolId": config.CognitoCredentials.UserPoolId,
            };

            FetchAPI.postData(config.HostURL + "/user/getClients", params)
                .then(data => {
                    if (data)
                        dispatch(clientList(data.List));
                })
                .catch(error => {
                    console.error(error);
                });
       
    }
}