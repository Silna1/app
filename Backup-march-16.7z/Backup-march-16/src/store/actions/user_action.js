import { FetchAPI } from '../../fetch.js';
import { config } from '../../config'
import { notificationStatus, notification, processInProgress } from './misc_action'


// **************actions**************
export const userData = (data) => {
    return {
        type: "USER_DATA",
        value: data
    }
}

const userUpdate = (user) => {
    return {
        type: 'UPDATE_USER',
        value: user
    };
};

const failUsers = () => {
    return {
        type: 'FAIL_USERS'
    };
};
const failGroup = () => {
    return {
        type: 'FAIL_GROUP'
    };
};

const userDelete = (user) => {
    return {
        type: 'REMOVE_USER',
        value: user
    };
};

const userAdd = (user) => {
    return {
        type: 'ADD_USER',
        value: user
    };
};

const groupAdd = (group) => {
    return {
        type: 'ADD_GROUP',
        value: group
    };
};

// **************actions creator handlers**************
export const getUsersdata = (organization) => {
    return async dispatch => {
        var params = {
            "userPoolId": config.CognitoCredentials.UserPoolId,
            'organization': organization
        };

        const url = config.HostURL + '/user/getUsers';
        FetchAPI.postData(url, params)
            .then(data => {
                dispatch(userData(data));
                dispatch(processInProgress(false));
            })
            .catch(error => {
                dispatch(processInProgress(false));
                console.error(error);

            });
    }
}

export const updateUser = (user) => {
    return async dispatch => {
        let param = {
            "username": user.username,
            "privilege": undefined,
            "privilegeToChange": undefined,
            "userPoolId": config.CognitoCredentials.UserPoolId,
            "name": user.name
        };

        if (user.privilege !== user.privilegeToChange) {
            param.privilege = user.privilege
            param.privilegeToChange = user.privilegeToChange
        }

        FetchAPI.postData(config.HostURL + "/user/updateUser", param)
            .then(data => {
                dispatch(userUpdate(user))
                dispatch(notification({ 'variant': 'success', 'message': 'User updated successfully' }))
            })
            .catch((err) => {
                dispatch(processInProgress(false));
                console.log(err);
                dispatch(failUsers())
                dispatch(notification({ 'variant': 'error', 'message': 'Fail to update user' }))
            });
    }
}

export const createUser = (user) => {
    return async dispatch => {
        let param = {
            "email": user.email,
            "privilege": user.privilege,
            "userPoolId": config.CognitoCredentials.UserPoolId,
            "name": user.name,
            "organization": user.organization
        };

        FetchAPI.postData(config.HostURL + "/user/createUser", param)
            .then(data => {
                console.log(data);
                if (data && data.message) {
                    dispatch(failUsers())
                    if (data.message.includes('exist'))
                        dispatch(notification({ 'variant': 'error', 'message': data.message }))
                    else
                        dispatch(notification({ 'variant': 'error', 'message': 'Fail to create user' }))
                } else {
                    dispatch(userAdd(user));
                    dispatch(notification({ 'variant': 'success', 'message': 'User create successfully' }))
                }
            })
            .catch((err) => {
                console.log(err);
                dispatch(failUsers())
                dispatch(notification({ 'variant': 'error', 'message': 'Fail to create user' }))
            });
    }
}

export const createGroup = (group) => {
    return async dispatch => {
        let param = {
            "groupName": group.groupName,
            "description": group.description,
            "userPoolId": config.CognitoCredentials.UserPoolId
        };

        FetchAPI.postData(config.HostURL + "/user/createGroup", param)
            .then(data => {
                console.log(data);
                if (data && data.message) {
                    dispatch(failGroup())
                    if (data.message.includes('exist'))
                        dispatch(notification({ 'variant': 'error', 'message': data.message }))
                    else
                        dispatch(notification({ 'variant': 'error', 'message': 'Fail to create Group' }))
                } else {
                    dispatch(groupAdd(data));
                    dispatch(notification({ 'variant': 'success', 'message': 'Group created successfully' }))
                }
            })
            .catch((err) => {
                console.log(err);
                dispatch(failGroup())
                dispatch(notification({ 'variant': 'error', 'message': 'Fail to create user' }))
            });
    }
}


export const deleteUser = (user) => {
    return async dispatch => {
        let param = {
            "username": user.username,
            "userPoolId": config.CognitoCredentials.UserPoolId,
        };

        FetchAPI.postData(config.HostURL + "/user/deleteUser", param)
            .then(data => {
                console.log(data);
                dispatch(userDelete(user));
                dispatch(processInProgress(false));
                dispatch(notificationStatus({ 'variant': 'success', 'message': 'User deleted successfully' }))
            })
            .catch((err) => {
                dispatch(processInProgress(false));
                console.log(err);
                dispatch(failUsers())
                dispatch(notification({ 'variant': 'error', 'message': 'Fail to delete user' }))
            });
    }
}

export const addUser = (user) => {
    return async dispatch => {
        FetchAPI.postData(config.HostURL + "/user/update", { "email": user.email, "privilege": user.privilege })
            .then(data => {
                console.log(data);
                if (!data) {
                    dispatch(notification({ 'variant': 'error', 'message': 'Unable to add user' }))
                } else {
                    dispatch(userAdd(data));
                    dispatch(notification({ 'variant': 'success', 'message': 'User added successfully' }))
                }
            }).catch(err => {
                dispatch(processInProgress(false));
                console.log(err);
                dispatch(notification({ 'variant': 'error', 'message': 'Unable to add user' }))
            })
    }
}