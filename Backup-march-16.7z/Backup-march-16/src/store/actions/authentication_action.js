import { CognitoAuth } from 'amazon-cognito-auth-js';
import { CognitoUserPool } from 'amazon-cognito-identity-js';

import { config } from "../../config.js";
import { FetchAPI } from "../../fetch.js";
import { clients } from './misc_action'
import store from '../store'

let auth;

export const authInitialized = (auth) => {
    return {
        type: 'AUTH_INITIALIZED',
        value: auth
    }
}

export const updateUserAuth = user => {
    return {
        type: 'UPDATE_USER_AUTH',
        value: user
    };
};

export const setUser = (user) => {
    return {
        type: 'SET_USER',
        value: user
    };
};

export const signout = () => {
    return dispatch => {
        if (auth === undefined) {
           initialiseAuth(dispatch);
        }
        auth.signOut();
        dispatch(authInitialized());
    }
}

const initialiseAuth = (dispatch) => {
    try {
        auth = new CognitoAuth(config.CognitoCredentials);
        auth.useCodeGrantFlow();

        let userPoolData = {
            ClientId: config.CognitoCredentials.ClientId, // Your client id here
            UserPoolId: config.CognitoCredentials.UserPoolId, // Your user pool id here
        }
        const userPool = new CognitoUserPool(userPoolData);
        userPool.CognitoUser = userPool.getCurrentUser();

        auth.userhandler = {
            onSuccess: async function (session) {
                console.log("Sign in success");
                let accessToken = session.getAccessToken().getJwtToken();
                if (accessToken) {
                    let payload = session.getIdToken().payload;
                    let userData = await setPrivilege(payload);
                    let token = await authenticateUser(userData);
                    dispatch(authInitialized(token));
                    dispatch(setUser(userData));
                    dispatch(clients((userData.organization)));
                }
                window.history.pushState({}, document.title, window.location.pathname);
            },
            onFailure: function (err) {
                if (JSON.parse(err).error === "invalid_grant")
                    store.dispatch(signout);
                console.log(err);
            }
        };
    } catch (error) {
        console.error(error);
    }
}

export const setCognitoUser = (data) => {
    return {
        type: 'SET_COGNITO_USER',
        value: data
    }
}

export const login = (payload) => {
    return dispatch => {
        // let payload = auth.getSignInUserSession().idToken.payload;
        let userData = async () => await setPrivilege(payload);
        userData()
            .then(async data => {
                dispatch(setUser(data));
                // dispatch(clients((data.organization)));
                let token = await authenticateUser(payload);
                dispatch(authInitialized(token));
            })
            .catch(err => {
                console.log(err);
            })
    }
}

export const signIn = () => {
    return dispatch => {
        if (auth === undefined) {
            initialiseAuth(dispatch);
        }
        auth.parseCognitoWebResponse(window.location.href);
        if (getQueryString('code') === null) {
            if (auth.getSignInUserSession().accessToken.jwtToken === '') {
                auth.getSession();
            } else if (!store.getState().auth) {
                let payload = auth.getSignInUserSession().idToken.payload;
                let userData = async () => await setPrivilege(payload);
                userData()
                    .then(async data => {
                        dispatch(setUser(data));
                        dispatch(clients((data.organization)));
                        let token = await authenticateUser(payload);
                        dispatch(authInitialized(token));
                    })
                    .catch(err => {
                        console.log(err);
                    })
            } else {
                dispatch(clients((store.getState().auth.user?.organization)));
            }
        }
    }
}

export const checkForToken = () => {
    return dispatch => {
        if (auth.getSignInUserSession().accessToken.jwtToken === '') {
            auth.getSession();
        }
    }
}

const authenticateUser = (payload) => {
    return new Promise((resolve, reject) => {
        let params = {
            name: payload.name,
            email: payload.email,
            privilege: payload.privilege
        }

        const url = config.HostURL + "/auth/authenticateUser";
        FetchAPI.postData(url, params)
            .then(data => {
                resolve(data.token);
            })
            .catch(err => {
                reject(err);
            })
    })
}

const setPrivilege = (payload) => {
    return new Promise((resolve, reject) => {
        let userData = {
            name: payload.name,
            email: payload.email
        }

        if (payload['cognito:groups'] !== undefined) {
            // eslint-disable-next-line no-unused-vars
            for (const item of payload['cognito:groups']) {
                if (config.Privilege.includes(item)) {
                    let index = config.Privilege.indexOf(item);
                    userData.privilege = config.Privilege[index];
                } else {
                    userData.organization = item;
                }
            }
            if (userData.privilege) {
                FetchAPI.postData(config.HostURL + "/user/privilege", { role: userData.privilege })
                    .then(result => {
                        userData.access = result.Items[0];
                        resolve(userData);
                    })
                    .catch(err => {
                        console.log(err);
                        reject(err);
                    });
            }
        } else {
            resolve(userData);
        }
    })
}

const getQueryString = (key) => {
    key = key.replace(/[*+?^$.[\]{}()|\\/]/g, "\\$&"); // escape RegEx meta chars
    let match = window.location.search.match(new RegExp("[?&]" + key + "=([^&]+)(&|$)"));
    return match && decodeURIComponent(match[1].replace(/\+/g, "+"));
}


