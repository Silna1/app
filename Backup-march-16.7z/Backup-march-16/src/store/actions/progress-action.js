import { config } from "../../config";
import axios from "axios";

// **************actions creator handlers**************
export const progressVal = (formData) => {
  console.log("actions creator handlers ", formData);

  return async (dispatch, getState) => {
    const url = config.HostURL + "/part/importParts";
    console.log('url',url)
    let token = getState().auth.initialized
      ? getState().auth.initialized
      : undefined;

    console.log("token", token);
    console.log('url',url)
    const header = {
      Authorization: token,
      Accept: "application/json",
    }; // DO NOT ADD CONTENT-TYPE TO HEADER.

    axios.post(url, formData, {
      headers: header,
      onUploadProgress: (event) => {
        const progress = Math.round((100 * event.loaded) / event.total);
        dispatch({
          type: "UPDATE_PROGRESS_VALUE",
          payload: progress,
        });
        console.log("progress", progress);
      },
    });
  };
};

export const updateProgressVal = (newVal) => {
  return (dispatch) => {
    dispatch({
      type: "UPDATE_PROGRESS_VALUE",
      payload: newVal,
    });
  };
};
