import { FetchAPI } from '../../fetch.js';
import { config } from '../../config'
import { notification, processInProgress } from "./misc_action"

const addNewLocation = (location) => {
    console.log("addNewlocation location_Action");
    return {
        type: 'ADD_LOCATION',
        value: location
    };
};

const receiveLocation = (data) => {
    console.log("inside receivelocation");
    return {
        type: 'RECEIVE_LOCATION',
        value: data
    };
};

const receiveClientLocation = (data) => {
    console.log("inside receivelocation");
    return {
        type: 'RECEIVE_CLIENT_LOCATION',
        value: data
    };
};

const locationDelete = (data) => {
    return {
        type: 'DELETE_LOCATION',
        value: data
    };
}

const locationUpdate = (data) => {
    return {
        type: 'UPDATE_LOCATION',
        value: data
    };
}

const receiveLocationbyId = (data) => {
    
    console.log("inside receivelocation");
    return {
        type: 'RECEIVE_LOCATION_BYID',
        value: data
    };
};

export const addLocation = (location) => {
    console.log("location silna",location);
    return dispatch => 
        new Promise(async (resolve, reject) => {
            FetchAPI.postData(config.HostURL + "/location/add", { "location": location })
            .then(data => {
                if(data.statusCode && data.statusCode >400)
                {
                    dispatch(notification({ "variant": 'error', "message": data.message, "autoHideDuration": 3000 }));
                    reject(data);
                }
                else
                {
                    console.log("location added", data);
                    dispatch(addNewLocation(data.location));
                    dispatch(notification({ "variant": 'success', "message": 'Location added successfully', "autoHideDuration": 3000 }));
                    resolve();
                }
                
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to add location', "autoHideDuration": 3000 }));
                // dispatch(failClients());
                reject();
            });
        })
}

export const fetchLocation = (query='') => {
    return async dispatch => {
        console.log("fetch location");
        FetchAPI.get(config.HostURL + "/location/all"+query)
            .then(data => {
                console.log("fetch location data",data);
                if (!data)
                    // eslint-disable-next-line no-throw-literal
                    throw "Fetching location failed in /location/all API.";
                dispatch(receiveLocation(data.Items))
                dispatch(processInProgress(false));
            })
            .catch((error) => {
                console.log("fetch location error");
                console.error(error);
             //   dispatch(failClients());
            });
    }
};

export const fetchClientLocation = () => {
    return async dispatch => {
        console.log("fetch location");
        FetchAPI.get(config.HostURL + "/location/clientlocation")
            .then(data => {
                console.log("fetch location data",data);
                if (!data)
                    // eslint-disable-next-line no-throw-literal
                    throw "Fetching location failed in /location/clientlocation API.";
                dispatch(receiveClientLocation(data))
                dispatch(processInProgress(false));
            })
            .catch((error) => {
                console.log("fetch location error");
                console.error(error);
             //   dispatch(failClients());
            });
    }
};

export const fetchLocationById = (id) => {
    return dispatch => 
        new Promise(async (resolve, reject) => {
            console.log("fetch location");
            FetchAPI.postData(config.HostURL + "/location/byId", {"id": id})
                .then(data => {
                    console.log("fetch location data",data);
                    if (!data)
                        // eslint-disable-next-line no-throw-literal
                        throw "Fetching location failed in /location/byId API.";
                   // dispatch(receiveLocationbyId(data))
                    resolve(data)
                    dispatch(processInProgress(false));
                })
                .catch((error) => {
                    console.log("fetch location error");
                    console.error(error);
                    reject(error);
                 //   dispatch(failClients());
                });
        })
};

export const updateLocation = (location) => {
    return dispatch => 
    new Promise(async (resolve, reject) => {
        FetchAPI.put(config.HostURL + "/location/update", { "location": location })
            .then(data => {
                if (data.error) {
                    throw data.error;
                }
                dispatch(locationUpdate(location))
                dispatch(notification({ "variant": 'success', "message": 'Location updated successfully', "autoHideDuration": 3000 }));
                resolve(data);
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to update client', "autoHideDuration": 3000 }));
                reject();
            });
    })
}

export const deleteLocation = (location) => {
    return dispatch => 
        new Promise(async (resolve, reject) => {
            FetchAPI.put(config.HostURL + "/location/deletes", { "location": location })
                .then(data => {
                    if (!data) {
                        throw "Deleting location failed in /location/delete API.";
                    }
                    dispatch(notification({ "variant": 'success', "message": 'Location deleted successfully', "autoHideDuration": 3000 }));
                    dispatch(locationDelete(location));
                    resolve();
                })
                .catch((error) => {
                    console.error(error);
                    dispatch(notification({ "variant": 'error', "message": 'Failed to delete location', "autoHideDuration": 3000 }));
                    reject();
                });
    })
}

export const fetchdataaccessLocation = (clients) => {
    return async dispatch => {
        console.log("fetchdataaccessLocation location");
        FetchAPI.postData(config.HostURL + "/location/dataaccesslocation",{ "clients" : clients})
            .then(data => {
                console.log("fetch location data",data);
                if (!data)
                    // eslint-disable-next-line no-throw-literal
                    throw "Fetching location failed in /location/all API.";
                dispatch(receiveLocation(data.Items))
                dispatch(processInProgress(false));
            })
            .catch((error) => {
                console.log("fetch location error");
                console.error(error);
             //   dispatch(failClients());
            });
    }
};
