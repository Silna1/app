import { FetchAPI } from '../../fetch.js';
import { config } from '../../config'
import { notification, processInProgress } from "./misc_action"

const receiveClients = (data) => {
    console.log("inside receiveclients");
    return {
        type: 'RECEIVE_CLIENTS',
        value: data
    };
};

const failClients = () => {
    console.log("inside failclients");
    return {
        type: 'FAIL_CLIENTS'
    };
};

const clientDelete = (client) => {
    return {
        type: 'REMOVE_CLIENT',
        value: client
    };
};

const clientUpdate = (client) => {
    return {
        type: 'UPDATE_CLIENT',
        value: client
    };
};

const addNewClient = (client) => {
    console.log("addNewClient client_Action");
    return {
        type: 'ADD_CLIENT',
        value: client
    };
};

const fetchClient = (client) => {
    return {
        type: 'VIEW_CLIENT',
        value: client
    };
}

export const selectedClient = (data) => {
    return {
      type: "SELECTED_CLIENT",
      value: data,
    };
  };

export const receiveSectors = (data)=>{
    return {
        type: "CLIENT_SECTOR",
        value: data,
      };
}

export const setSelectedClient = (clientId) => {
    return (dispatch) => {
      FetchAPI.postData(config.HostURL + "/client/getclientbyid", { id: clientId })
        .then((data) => {
          dispatch(selectedClient(data));
          dispatch(processInProgress(false));
        })
        .catch((error) => console.error(error));
    };
  };

export const updateClient = (client) => {
    console.log("update client action",client);
    return dispatch => 
    new Promise(async (resolve, reject) => {
        FetchAPI.put(config.HostURL + "/client/update", { "client": client })
            .then(data => {
                if (data.error) {
                    throw data.error;
                }
                dispatch(clientUpdate(client))
                dispatch(notification({ "variant": 'success', "message": 'Client updated successfully', "autoHideDuration": 3000 }));
                resolve(data);
            })
            .catch((error) => {
                console.error(error);
                if(error.statusCode && error.statusCode >400)
                {
                    dispatch(notification({ "variant": 'error', "message": error.message, "autoHideDuration": 3000 }));
                    reject(error);
                }
                else{
                dispatch(notification({ "variant": 'error', "message": 'Failed to update client', "autoHideDuration": 3000 }));
                dispatch(failClients());
                reject();
                }
            });
    })
}

export const fetchClients = (query='') => {
    return async dispatch => {
        console.log("fetch clients");
        FetchAPI.get(config.HostURL + "/client/all"+query)
            .then(data => {
                console.log("fetch clients data",data);
                if (!data)
                    // eslint-disable-next-line no-throw-literal
                    throw "Fetching clients failed in /client/all API.";
                dispatch(receiveClients(data.Items))
                dispatch(processInProgress(false));
            })
            .catch((error) => {
                console.log("fetch clients error");
                console.error(error);
                dispatch(failClients());
            });
    }
};

export const deleteClient = (client) => {
    console.log("deleteclient",client);
    return async dispatch => {
        FetchAPI.put(config.HostURL + "/client/deletes", { "client": client })
            .then(data => {
                if (!data) {
                    throw "Deleting client failed in /client/delete API.";
                }
                dispatch(notification({ "variant": 'success', "message": 'Client deleted successfully', "autoHideDuration": 3000 }));
                dispatch(clientDelete(client));
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to delete client', "autoHideDuration": 3000 }));
                dispatch(failClients());
            });
    }
}

export const addClient = (client) => {
    console.log("addclient silna",client);
    return dispatch => 
    new Promise(async (resolve, reject) => {
        FetchAPI.postData(config.HostURL + "/client/add", { "client": client })
            .then(data => {
                console.log("client added", data);
                if(data.statusCode && data.statusCode >400)
                {
                    dispatch(notification({ "variant": 'error', "message": data.message, "autoHideDuration": 3000 }));
                    reject(data);
                }
                else{
                dispatch(addNewClient(data.clients));
                dispatch(notification({ "variant": 'success', "message": 'Client added successfully', "autoHideDuration": 3000 }));
                resolve();
                }
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to add client', "autoHideDuration": 3000 }));
                dispatch(failClients());
                reject();
            });
        })
}

export const viewClient = (id) => {
    console.log("viewclient silna",id);
    return  dispatch => 
    new Promise(async (resolve, reject) => {
        FetchAPI.postData(config.HostURL + "/client/getclientbyid", { "id": id })
            .then(data => {
                console.log("client fetched", data);
                dispatch(fetchClient(data));
                dispatch(notification({ "variant": 'success', "message": 'Client fetched successfully', "autoHideDuration": 3000 }));
                resolve(data);
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to fetch client', "autoHideDuration": 3000 }));
                dispatch(failClients());
                reject();
            });
   })
}

export const getSector = () => {
    return async dispatch => {
        console.log("fetch client sector");
        FetchAPI.get(config.HostURL + "/client/sector")
            .then(data => {
                console.log("fetch clients data",data);
                if (!data)
                    // eslint-disable-next-line no-throw-literal
                    throw "Fetching client sector failed in /client/all API.";
                dispatch(receiveSectors(data.Items))
                dispatch(processInProgress(false));
            })
            .catch((error) => {
                console.log("fetch client sector error");
                console.error(error);
                dispatch(failClients());
            });
    }
};

