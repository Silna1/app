import { FetchAPI } from '../../fetch.js';
import { config } from '../../config'
import { notification, processInProgress } from "./misc_action"

const receivePrinters = (data) => {
    return {
        type: 'RECEIVE_PRINTERS',
        value: data
    };
};

const failPrinters = () => {
    return {
        type: 'FAIL_PRINTERS'
    };
};

const printerDelete = (printer) => {
    return {
        type: 'REMOVE_PRINTER',
        value: printer
    };
};

const printerUpdate = (printer) => {
    return {
        type: 'UPDATE_PRINTER',
        value: printer
    };
};

const addNewPrinter = (printer) => {
    return {
        type: 'ADD_PRINTER',
        value: printer
    };
};

export const updatePrinter = (printer) => {
    return async dispatch => {
        FetchAPI.put(config.HostURL + "/printer/update", { "printer": printer })
            .then(data => {
                if (data.error) {
                    throw data.error;
                }
                dispatch(printerUpdate(printer))
                dispatch(notification({ "variant": 'success', "message": 'Printer updated successfully', "autoHideDuration": 3000 }));
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to update printer', "autoHideDuration": 3000 }));
                dispatch(failPrinters());
            });
    }
}

export const fetchPrinters = () => {
    return async dispatch => {
        FetchAPI.get(config.HostURL + "/printer/all")
            .then(data => {
                console.log("fetch printer data",data.Items);
                if (!data)
                    // eslint-disable-next-line no-throw-literal
                    throw "Fetching printers failed in /printer/all API.";
                dispatch(receivePrinters(data.Items))
                dispatch(processInProgress(false));
            })
            .catch((error) => {
                console.error(error);
                dispatch(failPrinters());
            });
    }
};

export const deletePrinter = (printer) => {
    return async dispatch => {
        FetchAPI.delete(config.HostURL + "/printer/delete", { "id": printer.id })
            .then(data => {
                if (!data) {
                    throw "Deleting printer failed in /printer/delete API.";
                }
                dispatch(notification({ "variant": 'success', "message": 'Printer deleted successfully', "autoHideDuration": 3000 }));
                dispatch(printerDelete(printer));
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to delete printer', "autoHideDuration": 3000 }));
                dispatch(failPrinters());
            });
    }
}

export const addPrinter = (printer) => {
    return async dispatch => {
        FetchAPI.postData(config.HostURL + "/printer/add", { "printer": printer })
            .then(data => {
                console.log("printer added", data);
                dispatch(addNewPrinter(data.printer));
                dispatch(notification({ "variant": 'success', "message": 'Printer added successfully', "autoHideDuration": 3000 }));
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to add printer', "autoHideDuration": 3000 }));
                dispatch(failPrinters());
            });
    }
}

export const sendForPrint = (partDetails) => {
    return async dispatch => {
        FetchAPI.postFormData(config.HostURL + "/part/sendEmailForPrinting", partDetails)
            .then(Response => {
                dispatch(notification({ "variant": Response.variant, "message": Response.status, "autoHideDuration": 3000 }))
            })
            .catch(err => {
                console.log("err", err);
            });
    }
}