import { FetchAPI } from '../../fetch.js';
import { config } from '../../config'

// **************actions**************
export const triningInfo = (data) => {
    return {
        type: "TRAINING_INFO",
        value: data
    }
}

// **************actions creator handlers**************
export const getLastModelInfo = () => {
    return async dispatch => {
        const url = config.HostURL + "/part/downloadForAutoml";

        FetchAPI.postData(url)
            .then(data => {
                dispatch(triningInfo(data["modelTrainingTimestamp"])) ;
            })
            .catch(error => {
                console.error(error);
            });
    }
}