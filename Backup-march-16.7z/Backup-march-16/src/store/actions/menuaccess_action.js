import { FetchAPI } from '../../fetch.js';
import { config } from '../../config'
import { notification, processInProgress } from "./misc_action";

const currentMenuAccess = (data) => {
    return {
        type: 'CURRENT_MENU_ACCESS',
        value: data.Items[0],
    }
}

export const fetchMenuAccess = (previlegeName) => {
    console.log("fetchMenuAccess silna",previlegeName);
    return  dispatch => 
    new Promise(async (resolve, reject) => {
        const query = '?previlegeName='+previlegeName;
                FetchAPI.get(config.HostURL + "/menuaccess/fetch" + query)
            .then(data => {
                console.log("fetchMenuAccess fetched", data);
                dispatch(notification({ "variant": 'success', "message": 'Menu fetched successfully', "autoHideDuration": 3000 }));
                dispatch(currentMenuAccess(data))
                resolve(data);
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to fetch menu', "autoHideDuration": 3000 }));
                reject();
            });
   })
}

export const update_MenuAccess = (accessData) => {
    console.log("fetchMenuAccess silna",accessData);
    return  dispatch => 
    new Promise(async (resolve, reject) => {
                FetchAPI.put(config.HostURL + "/menuaccess/update",{'accessData': accessData})
            .then(data => {
                console.log("update Menu fetched", data);
                dispatch(notification({ "variant": 'success', "message": 'Menu Updated successfully', "autoHideDuration": 3000 }));
                resolve(data);
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to udpate menu', "autoHideDuration": 3000 }));
                reject();
            });
   })
}

export const fetchall_MenuAccess = () => {
    console.log("fetchMenuAccess silna");
    return  dispatch => 
    new Promise(async (resolve, reject) => {
                FetchAPI.get(config.HostURL + "/menuaccess/all",)
            .then(data => {
                console.log("update Menu fetch", data);
                dispatch(notification({ "variant": 'success', "message": 'Menu Updated successfully', "autoHideDuration": 3000 }));
                resolve(data);
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to udpate menu', "autoHideDuration": 3000 }));
                reject();
            });
   })
}


