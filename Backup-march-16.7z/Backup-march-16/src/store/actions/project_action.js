import { FetchAPI } from '../../fetch.js';
import { config } from '../../config'
import { notification, processInProgress } from "./misc_action"

const addNewProject = (project) => {
    console.log("addNewproject project_Action");
    return {
        type: 'ADD_PROJECT',
        value: project
    };
};

const receiveProject = (data) => {
    console.log("inside receiveProject");
    return {
        type: 'RECEIVE_PROJECT',
        value: data
    };
};

const projectUpdate = (data) => {
    return {
        type: 'UPDATE_PROJECT',
        value: data
    };
};

const projectDelete = (data) => {
    return {
        type: 'REMOVE_PROJECT',
        value: data
    }
}

const receiveClientProject = (data) => {
    console.log("inside receiveClientProject");
    return {
        type: 'RECEIVE_CLIENT_PROJECT',
        value: data
    };
};

const receiveProjectLocation = (data) => {
    console.log("inside receiveProjectLocation");
    return {
        type: 'RECEIVE_PROJECT_LOCATION',
        value: data
    };
};


export const addProject = (project) => {
    console.log("project silna",project);
    return dispatch => 
        new Promise(async (resolve, reject) => {
            FetchAPI.postData(config.HostURL + "/project/add", { "project": project })
            .then(data => {
                if(data.statusCode && data.statusCode >400)
                {
                    dispatch(notification({ "variant": 'error', "message": data.message, "autoHideDuration": 3000 }));
                    reject(data);
                }
                else
                {
                console.log("location added", data);
                dispatch(addNewProject(data.project));
                dispatch(notification({ "variant": 'success', "message": 'project added successfully', "autoHideDuration": 3000 }));
                resolve();
                }
            })
            .catch((error) => {
                console.error(error);
                dispatch(notification({ "variant": 'error', "message": 'Failed to add project', "autoHideDuration": 3000 }));
                // dispatch(failClients());
                reject();
            });
        })
}

export const fetchProject = (query='') => {
    return async dispatch => {
        console.log("fetch project");
        FetchAPI.get(config.HostURL + "/project/all"+query)
            .then(data => {
                console.log("fetch project data",data);
                if (!data)
                    // eslint-disable-next-line no-throw-literal
                    throw "Fetching project failed in /project/all API.";
                dispatch(receiveProject(data.Items))
                dispatch(processInProgress(false));
            })
            .catch((error) => {
                console.log("fetch project error");
                console.error(error);
             //   dispatch(failClients());
            });
    }
};

export const fetchProjectById = (id) => {
    return dispatch => 
        new Promise(async (resolve, reject) => {
            console.log("fetch project");
            FetchAPI.postData(config.HostURL + "/project/byId", {"id": id})
                .then(data => {
                    console.log("fetch project data",data);
                    if (!data)
                        // eslint-disable-next-line no-throw-literal
                        throw "Fetching project failed in /project/byId API.";
                    resolve(data)
                    dispatch(processInProgress(false));
                })
                .catch((error) => {
                    console.log("fetch project error");
                    console.error(error);
                    reject(error);
                 //   dispatch(failClients());
                });
        })
};

export const updateProject = (project) => {
    return dispatch => 
        new Promise(async (resolve, reject) => {
            console.log("update project", project);
            FetchAPI.put(config.HostURL + "/project/update", {"project": project})
                .then(data => {
                    console.log("fetch project data",data);
                    if (!data)
                        // eslint-disable-next-line no-throw-literal
                        throw "Updating project failed in /project/byId API.";
                    dispatch(projectUpdate(project))
                    dispatch(notification({ "variant": 'success', "message": 'project updated successfully', "autoHideDuration": 3000 }));
                    dispatch(processInProgress(false));
                    resolve()
                })
                .catch((error) => {
                    console.log("fetch project error");
                    console.error(error);
                    reject(error);
                 //   dispatch(failClients());
                });
        })
};

export const deleteProject = (project) => {
    return dispatch => 
    new Promise(async (resolve, reject) => {
        console.log("update project", project);
        FetchAPI.put(config.HostURL + "/project/deletes", {"project": project})
            .then(data => {
                console.log("fetch project data",data);
                if (!data)
                    // eslint-disable-next-line no-throw-literal
                    throw "Deleting project failed in /project/delete API.";
                dispatch(projectDelete(project))
                dispatch(notification({ "variant": 'success', "message": 'project deleted successfully', "autoHideDuration": 3000 }));
                resolve()
            })
            .catch((error) => {
                console.log("fetch project error");
                console.error(error);
                reject(error);
             //   dispatch(failClients());
            });
    })
}

export const fetchprojectClient = () => {
    return async dispatch => {
        console.log("fetch receiveClientProject");
        FetchAPI.get(config.HostURL + "/project/clientproject")
            .then(data => {
                console.log("fetch receiveClientProject data",data);
                if (!data)
                    // eslint-disable-next-line no-throw-literal
                    throw "Fetching location failed in /location/clientlocation API.";
                dispatch(receiveClientProject(data))
                dispatch(processInProgress(false));
            })
            .catch((error) => {
                console.log("fetch receiveClientProject error");
                console.error(error);
             //   dispatch(failClients());
            });
    }
};

export const fetchProjectLocation = () => {
    return async dispatch => {
        console.log("fetch fetchProjectLocation");
        FetchAPI.get(config.HostURL + "/project/projectlocation")
            .then(data => {
                console.log("fetch fetchProjectLocation data",data);
                if (!data)
                    // eslint-disable-next-line no-throw-literal
                    throw "Fetching location failed in /location/clientlocation API.";
                dispatch(receiveProjectLocation(data))
                dispatch(processInProgress(false));
            })
            .catch((error) => {
                console.log("fetch fetchProjectLocation error");
                console.error(error);
             //   dispatch(failClients());
            });
    }
};