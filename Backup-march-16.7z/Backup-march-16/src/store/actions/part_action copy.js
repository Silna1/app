// import { fetchPartsData } from '../../fetch.js'
import { FetchAPI } from "../../fetch.js";
import { config } from "../../config";
import {
  processInProgress,
  notification,
  setSelectedClient,
} from "./misc_action";
import store from "../store";

// **************actions**************
export const partsData = (data) => {
  return {
    type: "PARTS_DATA",
    value: data,
  };
};

export const partsData2 = (data) => {
  return {
    type: "PARTS_DATA2",
    value: data,
  };
};
export const graphpartsData = (data) => {
  return {
    type: "GRAPH_PARTS_DATA",
    value: data,
  };
};


export const materialspartsData = (data) => {
  return {
    type: "MATERIALS_PARTS_DATA",
    value: data,
  };
};


export const pyrmiddata = (data) => {
  return {
    type: "PYRAMID_DATA",
    value: data,
  };
};


export const getCategories = (data) => {
  return {
    type: "PART_CATEGORIES",
    value: data,
  };
};

export const getAllCategories = (data) => {
  return {
    type: "PART_ALL_CATEGORIES",
    value: data,
  };
};

export const selectedPart = (data) => {
  return {
    type: "SELECTED_PART",
    value: data,
  };
};

export const emptySelectedPart = () => {
  return {
    type: "EMPTY_SELECTED_PART",
    value: {},
  };
};

export const addNewPart = (data) => {
  return {
    type: "Add_NEW_PART",
    value: data,
  };
};

export const getMaterials = (data) => {
  return {
    type: "PART_MATERIALS",
    value: data,
  };
};


export const updatepart = (data) => {
  return {
    type: "PART_UPDATE",
    value: data,
  };
};

export const removePart = (data) => {
  return {
    type: "PART_DELETE",
    value: data,
  };
};

export const searchInProgress = (data) => {
  return {
    type: "SEARCH_PROGRESS",
    value: data,
  };
};

export const totalPartsCount = (data) => {
  return {
    type: "TOTAL_PARTS_COUNT",
    value: data,
  };
};

export const duplicates = (data) => {
  return {
    type: "DUPLICATES_FOUND",
    value: data,
  };
};

export const dashboardChartData = (data) => {
  return {
    type: "DASHBOARD_CHART_DATA",
    value: data,
  };
};

export const getCommentsData = (data) => {
  return {
      type: "GET_COMMENTS",
      value: data
  }
}
// **************actions creator handlers**************
export const getPartsData = (data) => {


  console.log("Changed....");
  return async (dispatch) => {

   
    const urlx = config.HostURL + '/part/play';
    var paramsx = { orga: data.organization };
    FetchAPI.postData(urlx,paramsx ).then((data) => {console.log("WORKS");});


    let partDataAvailable = store.getState().parts
      ? store.getState().parts
      : undefined;
    if (
      partDataAvailable.Items &&
      Object.entries(partDataAvailable.Items).length > 0 &&
      partDataAvailable.Items[0].organization === data.organization &&
      data.lastEvaluatedKey === null
    ) {
      dispatch(processInProgress(false));
      return;
    }

    let proceedflag = false;
    const url = config.HostURL + "/part/getPartData";
    let body = {};
    let count = 0;

    if (data.lastEvaluatedKey) {
      body = { LastEvaluatedKey: data.lastEvaluatedKey };
      count = Number(partDataAvailable.Items.length);
      if (
        Number(partDataAvailable.Items.length) <
        partDataAvailable.totalPartsCount
      ) {
        if (
          Number(partDataAvailable.Items.length) + 100 <=
          partDataAvailable.totalPartsCount
        ) {
          body.limit = 100;
        } else {
          body.limit =
            partDataAvailable.totalPartsCount -
            Number(partDataAvailable.Items.length);
        }
      }
      proceedflag = true;
    } else if (data.lastEvaluatedKey === null) {
      proceedflag = true;
    } else {
      proceedflag = false;
    }

    if (data.organization) {
      body.organization = data.organization;
    }
    body.isDashboardChart = false;
    if (proceedflag) {
      FetchAPI.postData(url, body)
        .then(async (data) => {
          if (data.error === undefined || data.Items !== undefined) {
            dispatch(setSelectedClient(body.organization));
            if (data.Count > 0) {
              dispatch(getTotalPartsCount(body.organization));
            } else {
              dispatch(totalPartsCount(0));
            }
            data.Count = count + data.Items.length;
            dispatch(partsData(data));
          } else 
          dispatch(processInProgress(false));
        })
        .catch((error) => {
          dispatch(processInProgress(false));
          console.error(error);
        });
        dispatch(processInProgress(false));
    }
  };
  
};

export const setSelectedPart = (partId) => {
  return (dispatch) => {
    FetchAPI.postData(config.HostURL + "/part/getpartbyid", { id: partId })
      .then((data) => {
        dispatch(selectedPart(data));
        dispatch(processInProgress(false));
      })
      .catch((error) => console.error(error));
  };
};

export const partAdd = (partFormData, historyData,organization) => {
  console.log("organization part add",organization);
  return async (dispatch) => {
    //upload part to database
    const url = config.HostURL + "/part/uploadpartdata";
    FetchAPI.postFormData(url, partFormData)
      .then((response) => {

        dispatch(processInProgress(false));

        const urlx = config.HostURL + '/part/play';
        var paramsx = { orga: organization };
        FetchAPI.postData(urlx,paramsx ).then((data) => {console.log("");});


        
   
        /*if (response && response !== undefined) {
          historyData.push("/");
          dispatch(processInProgress(false));
          dispatch(
            notification({
              variant: "warning",
              message: response.message,
              autoHideDuration: 3000,
            })
          );
        } else {
          if (response.Items) {
            const id = {
              id: response.Items[0].id,
            };
            //get part by id of uploaded part
            //we make api call for same part we created just now because we want signed url for its thumbnail image
            const partURL = config.HostURL + "/part/getpartbyid";
            FetchAPI.postData(partURL, id)
              .then((part) => {
                const newPart = part.Items.shift();
                newPart.signedUrls = newPart.signedUrls[0].url;
                dispatch(addNewPart(newPart));
                dispatch(processInProgress(false));

                const urlx = config.HostURL + '/part/play';
                var paramsx = { orga: newPart.organization };
                FetchAPI.postData(urlx,paramsx ).then((data) => {console.log("");});


                dispatch(
                  notification({
                    variant: "success",
                    message: newPart.name + " part Added Successfully",
                    autoHideDuration: 3000,
                  })
                );
                dispatch(getTotalPartsCount(newPart.organization));
                historyData.push("/");
              })
              .catch((error) => {
                console.error(error);
                dispatch(processInProgress(false));
              });
          }
        }*/

        
        const urltop = config.HostURL + '/part/runtopcatsthread';
        var paramstop = { orga: organization };
        FetchAPI.postData(urltop,paramstop ).then((data) => {console.log("");});


       
       

        dispatch(getTotalPartsCount(organization));
        const urlxps = config.HostURL + '/part/playps';
        var paramsxps = { orga: organization };
        FetchAPI.postData(urlxps,paramsxps ).then((data) => {console.log("");});


      
        dispatch(
          notification({
            variant: "success",
            message:"New Part Added Successfully",
            autoHideDuration: 3000,
          })
        );
        historyData.push("/");
        //window.location.reload();
      })
      .catch((error) => {
        console.error(error);
        dispatch(processInProgress(false));
      });


    
  };
};

export const importParts = (formData) => {
 
  return (dispatch) => {
    const url = config.HostURL + "/part/importParts";

    FetchAPI.postFormData(url, formData)
      .then((data) => {
        
      
        const urlx = config.HostURL + '/part/play';
        var paramsx = { orga: "ImmensaLab" };
        FetchAPI.postData(urlx,paramsx ).then((data) => {console.log("");});


        const urltop = config.HostURL + '/part/runtopcatsthread';
        var paramstop = { orga: "organization" };
        FetchAPI.postData(urltop,paramstop ).then((data) => {console.log("");});


        const urlxps = config.HostURL + '/part/playps';
        var paramsxps = { orga: "organization" };
        FetchAPI.postData(urlxps,paramsxps ).then((data) => {console.log("");});
        
    
      })
      .catch((error) => {
        console.error(error);
      });
  };

  
};
export const fetchMaterials = () => {
  return (dispatch) => {
    const url = config.HostURL + "/part/getMaterialsData";
    FetchAPI.get(url)
      .then((data) => {
        dispatch(getMaterials(data.materials));
      })
      .catch((error) => {
        console.error(error);
      });
  };
};
/* task 3
export const fetchCategories = () => {
  return (dispatch) => {
    const url = config.HostURL + "/part/getCategoriesData";
    FetchAPI.get(url)
      .then((data) => {
        dispatch(getCategories(data.categories));
      })
      .catch((error) => {
        console.error(error);
      });
  };
};
*/
export const partUpdate = (formData, historyData) => {
  return (dispatch) => {
    const url = config.HostURL + "/part/update";

    FetchAPI.putFormData(url, formData)
      .then((response) => {
        const PartURL = config.HostURL + "/part/getpartbyid";
        if (response.data && response.data.fields.id) {
          const id = {
            id: response.data.fields.id,
          };
          FetchAPI.postData(PartURL, id)
            .then((part) => {
              historyData.push("/");
              const newPart = part.Items.shift();
              newPart.signedUrls = newPart.signedUrls[0].url;
              dispatch(updatepart(newPart));
              dispatch(processInProgress(false));
              dispatch(
                notification({
                  variant: "success",
                  message: newPart.name + " part updated Successfully",
                  autoHideDuration: 3000,
                })
              );
            })
            .catch((error) => {
              console.error(error);
              dispatch(processInProgress(false));
            });
        } else {
          historyData.push("/");
          let messsage = "part update failed";
          if (response.message === "Same name exist")
            messsage = response.message;

          dispatch(
            notification({
              variant: "warning",
              message: messsage,
              autoHideDuration: 3000,
            })
          );
          console.error(response.message);
        }
      })
      .catch((error) => {
        console.error(error);
        dispatch(processInProgress(false));
      });
  };
};

export const deletePart = (partID) => {
  return (dispatch) => {
    const url = config.HostURL + "/part/delete";
    FetchAPI.postData(url, {
      id: partID,
    })
      .then((data) => {
        dispatch(removePart({ id: partID }));
        dispatch(processInProgress(false));
        dispatch(
          notification({
            variant: "success",
            message: "Part deleted Successfully",
            autoHideDuration: 3000,
          })
        );
        dispatch(getTotalPartsCount());
      })
      .catch((error) => {
        console.error(error);
        dispatch(processInProgress(false));
      });
  };
};

export const removePartFromList = (partID, organization) => {
  return (dispatch) => {
    dispatch(removePart({ id: partID }));
    dispatch(getTotalPartsCount(organization));
    dispatch(processInProgress(false));
  };
};

export const getTotalPartsCount = (organization) => {
  return (dispatch) => {
    const url = config.HostURL + "/part/getPartsCount";
    if (organization) {
      FetchAPI.postData(url, { organization: organization })
        .then((data) => {
        console.log(data);
          dispatch(totalPartsCount(data.counter));//data.Count.Count
        })
        .catch((error) => {
          console.error(error);
        });
    }
  };
};

export const getChartsDatax = (organization) => {
  return (dispatch) => {
    let partDataAvailable = store.getState().parts
      ? store.getState().parts
      : undefined;
    let body = {};
    const url = config.HostURL + "/part/getPartData";
    if (
      partDataAvailable.Items === undefined ||
      partDataAvailable.Items.length < partDataAvailable.totalPartsCount
    ) {
      if (organization) {
        body = {
          organization: organization,
          limit: 0,
        };
        FetchAPI.postData(url, body)
          .then((data) => {
            data["setNewParts"] = true;
            dispatch(setSelectedClient(organization));
            if (data.Count > 0) {
              dispatch(getTotalPartsCount(organization));
            } else {
              dispatch(totalPartsCount(0));
            }
            dispatch(partsData(data));
            dispatch(processInProgress(false));
          })
          .catch((error) => {
            console.error(error);
            dispatch(processInProgress(false));
          });
      }
    } else dispatch(processInProgress(false));
  };
};


export const getChartsData = (organization) => {
  
  return (dispatch) => {
    let partDataAvailable = store.getState().parts
      ? store.getState().parts
      : undefined;
    let body = {};
    const url = config.HostURL + "/part/getPartsCat";
    
      if (organization) {
        body = {
          organization: organization,
          limit: 0,
        };
        FetchAPI.postData(url, body)
          .then((data) => {
            dispatch(processInProgress(false));
            console.log("MESSAGE",data);
            dispatch(partsData2(data));

            
            
          })
          .catch((error) => {
            console.error(error);
            dispatch(processInProgress(false));
          });
      }
    
  };
};


//get Top 9 Categories Data
export const getChartsDataTop = (organization) => {
  return (dispatch) => {
    let body = {};
    const url = config.HostURL + "/part/gettop9cats";

      if (organization) {body = {organization: organization};

        FetchAPI.postData(url, body).then((data) => {
            dispatch(processInProgress(false));
            dispatch(graphpartsData(data));   
          })
          .catch((error) => {
            console.error(error);
            dispatch(processInProgress(false));
          });
      }
  };
};


//get Pyramid Data 
export const getPyrmidData = () => {
  return (dispatch) => {
    let body = {};
    const url = config.HostURL + "/part/getpyramiddata";
        FetchAPI.postData(url, body).then((data) => {
            dispatch(processInProgress(false));
            dispatch(pyrmiddata(data));   
          
          })
          .catch((error) => {
            console.error(error);
            dispatch(processInProgress(false));
          });
  };
};



//get Top 9 Categories Data
export const getMaterialsParts = (organization) => {
  return (dispatch) => {
    let body = {};
    const url = config.HostURL + "/part/materialsparts";

      if (organization) {body = {organization: organization};

        FetchAPI.postData(url, body).then((data) => {

     
            dispatch(processInProgress(false));
            dispatch(materialspartsData(data));   
          })
          .catch((error) => {
            console.error(error);
            dispatch(processInProgress(false));
          });
      }
  };
};




//Get all Categories
export const getAllCategoriesList = (organization) => {
  return async dispatch => {
      var params = {};
      const url = config.HostURL + '/part/getallcats';
      FetchAPI.postData(url, params)
          .then(data => {
              dispatch(getAllCategories(data.Items));
              //dispatch(processInProgress(false));
            
          })
          .catch(error => {
              //dispatch(processInProgress(false));
              console.error(error);

          });
  }
}



export const getCategoriesList = (organization) => {

  return async dispatch => {
      var params = {};
      const url = config.HostURL + '/part/getcats';
      FetchAPI.postData(url, params)
          .then(data => {
              dispatch(getCategories(data));
              //dispatch(processInProgress(false));
            
          })
          .catch(error => {
              //dispatch(processInProgress(false));
              console.error(error);

          });
  }
}

export const setCommentAdd = (userComment,UserID,PartID) => {

  return dispatch => {
      let CommentData = {"UserComment": userComment,"UserID":UserID,"PartID":PartID};
      FetchAPI.postData(config.HostURL + "/part/setComment", CommentData)
          .then(data => {
              
          }).catch(err => {
              console.log(err);
          })
  }
}



//get Comments by PartID
export const getComments = (partID) => {
  
  console.log("Part IDxxx",partID);
  return dispatch => {
      const url = config.HostURL + '/part/getComments';
      FetchAPI.postData(url, {"id": partID})
          .then(data => {
   if(data.Count > 0)
   {
              dispatch(getCommentsData(data.Items));
   }
   else
   {
     var y = [];
     y.push({"CommentID":"0", "CommentText":"No Comments avilable on this Part.","UserID":"System","AddDate":"..."});
     dispatch(getCommentsData(y));
   }
         
       
          })
          .catch(error => {
              console.log("error");
          });
  }
}



