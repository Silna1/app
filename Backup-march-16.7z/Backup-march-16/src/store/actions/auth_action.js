import { FetchAPI } from "../../fetch.js";
import { config } from "../../config.js";
import { processInProgress } from './misc_action'

let GoogleAuth;

export const authInitialized = (isInitialized) => {
    return {
        type: 'AUTH_INITIALIZED',
        value: isInitialized
    };
};

export const updateUserAuth = user => {
    return {
        type: 'UPDATE_USER_AUTH',
        value: user
    };
};

export const setUser = (user) => {
    return {
        type: 'SET_USER',
        value: user
    };
};

export const signIn = () => {
    return async dispatch => {
        initAuth(dispatch).then(() => {
            GoogleAuth.signIn({ prompt: "select_account" }).then(async googleUser => {
                const userData = getUserFromGoogleUser(GoogleAuth.currentUser.get());
                dispatch(authInitialized(true));
                let loggedInUser = await verifyUser(userData);
                dispatch(setUser(loggedInUser));
            }).catch(err => {
                dispatch(authInitialized(false));
            })
        });
    }
}

export const signOut = () => {
    return async dispatch => {
        initAuth(dispatch).then(() => {
            GoogleAuth.signOut().then(() => {
                dispatch(setUser());
                dispatch(authInitialized(false));
            }).catch((err) => {
                Promise.reject(err);
            })
        });
    }
};

const initAuth = (dispatch) => {
    if (GoogleAuth)
        Promise.resolve(GoogleAuth);

    return loadGapi().then(() => {
        return window.gapi.client
            .init({
                // Put your client ID here. See https://developers.google.com/identity/protocols/OAuth2UserAgent
                // for how to create one.
                clientId:
                    "1091043831841-i19kmj5tn9204pnvrff03lt1irm8f58l.apps.googleusercontent.com",
                scope:
                    "https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile"
            })
            .then(() => {
                GoogleAuth = window.gapi.auth2.getAuthInstance();

                Promise.resolve(GoogleAuth);
            });
    });
}


const verifyUser = (googleUser) => {

    return new Promise((resolve, reject) => {

        const url = config.HostURL + "/auth/google/token";
        return fetch(url, {
            method: "POST", // *GET, POST, PUT, DELETE, etc.
            mode: "cors", // no-cors, cors, *same-origin
            cache: "no-cache", // *default, no-cache, reload, force-cache, only-if-cached
            credentials: "same-origin", // include, *same-origin, omit
            headers: {
                "Content-Type": "application/json; charset=utf-8"
            },
            redirect: "follow", // manual, *follow, error
            referrer: "no-referrer", // no-referrer, *client
            body: JSON.stringify({ token: googleUser.token }) // body data type must match "Content-Type" header
        }).then(response => {
            if (response.ok) return response.json();
            else {
                console.error(
                    "Error in : " + url + " - Status Code : " + response.status
                );
                return undefined;
            }
        }).then(data => {
            if (!data) {
                console.error("Error in authorizing token");
                //dispatch(updateSnackbarMessage("Only immensalabs.com users are allowed."));
                //dispatch(navigate(decodeURIComponent("/not-authenticated")));
            }
            else if (data.privilege) {
                FetchAPI.postData(config.HostURL + "/user/privilege", {
                    role: data.privilege
                })
                    .then(userData => {
                        googleUser.access = userData.Items[0];
                        googleUser.privilege = data.privilege;
                        googleUser.token = data.token;
                        resolve(googleUser)
                        // googleUser.refreshToken = data.refreshToken;
                    })
                    .catch(err => {
                        console.log(err);
                    });
            }
        }).catch(error => console.error(error))
    })
}

export const fetchUser = () => {
    return async dispatch => {
        initAuth(dispatch).then(async () => {
            if (GoogleAuth.isSignedIn.get()) {
                const userData = getUserFromGoogleUser(GoogleAuth.currentUser.get());
                let googleUser = await verifyUser(userData);
                // dispatch(updateUserAuth(googleUser));
                dispatch(setUser(googleUser));
                dispatch(authInitialized(true));
                dispatch(processInProgress(false));
            } else
                dispatch(authInitialized(false));
        }); 
    }
};

const getUserFromGoogleUser = googleUser => {
    const profile = googleUser.getBasicProfile();
    const id_token = googleUser.getAuthResponse().id_token;
    return {
        id: profile.getId(),
        token: id_token,
        fullName: profile.getName(),
        email: profile.getEmail(),
        imageUrl: profile.getImageUrl()
    };
};

let initCalled;
const callbackPromise = new Promise(r => (window.__gapiCallback = r));
const loadGapi = () => {
    if (!initCalled) {
        const script = document.createElement("script");
        script.src =
            "https://apis.google.com/js/api:client.js?onload=__gapiCallback";
        script.setAttribute("async", "");
        document.head.appendChild(script);
        initCalled = true;
    }
    return callbackPromise;
};