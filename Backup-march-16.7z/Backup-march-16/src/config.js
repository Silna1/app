const env = "local";

const hostURL = {
  //dev server link - http://devpartdigiserver-env.awyyxzym37.ap-south-1.elasticbeanstalk.com
  local: "http://localhost:8083",
  development: "https://dev-apis.immensa3d.com", //"http://devpartdigiserver-env.awyyxzym37.ap-south-1.elasticbeanstalk.com",
  production: "https://apis.immensa3d.com", //"http://partdigitizerserver-env-1.bezpbbc4wz.ap-south-1.elasticbeanstalk.com"
};

const Automl = {
  local: "http://localhost:8082",
  development: "https://dev-automl.immensa3d.com",
  production: "https://automl.immensa3d.com", //"http://partdigitizerautoml-env.9pbjjdsf2f.ap-south-1.elasticbeanstalk.com"
};

const CognitoCredentials = {
  local: {
    ClientId: "3qr1gc1qpu0agdr4682m85k0qt",
    AppWebDomain: "login-dev.immensa3d.com", //'immensa.auth.ap-south-1.amazoncognito.com',
    UserPoolId: "ap-south-1_7ndZvghsN",
    TokenScopesArray: [
      "email",
      "openid",
      "profile",
      "aws.cognito.signin.user.admin",
    ], // e.g.['phone', 'email', 'profile','openid', 'aws.cognito.signin.user.admin'],
    RedirectUriSignIn: "http://localhost:3000",
    RedirectUriSignOut: "http://localhost:3000",
  },
  development: {
    ClientId: "62tnt6r7546fub45a00us4gpn2",
    AppWebDomain: "login-dev.immensa3d.com",
    UserPoolId: "ap-south-1_7ndZvghsN",
    TokenScopesArray: [
      "email",
      "openid",
      "profile",
      "aws.cognito.signin.user.admin",
    ], // e.g.['phone', 'email', 'profile','openid', 'aws.cognito.signin.user.admin'],
    RedirectUriSignIn: "https://dev.immensa3d.com",
    RedirectUriSignOut: "https://dev.immensa3d.com",
  },
  production: {
    ClientId: "11l4p18kj6au98t0pkkqvt9gt3",
    AppWebDomain: "login.immensa3d.com",
    UserPoolId: "ap-south-1_is7kjvxUB",
    TokenScopesArray: [
      "email",
      "openid",
      "profile",
      "aws.cognito.signin.user.admin",
    ], // e.g.['phone', 'email', 'profile','openid', 'aws.cognito.signin.user.admin'],
    RedirectUriSignIn: "https://immensa3d.com",
    RedirectUriSignOut: "https://immensa3d.com",
  },
};

const Privilege = ["Admin", "Engineer", "Technician", "Client"];

const ProductOwner = "ImmensaLab";

const ClientType = ["End User","OEM",'ODM']

export const config = {
  HostURL: hostURL[env],
  HostAutomlURL: Automl[env],
  CognitoCredentials: CognitoCredentials[env],
  Privilege: Privilege,
  ProductOwner: ProductOwner,
  ClientType: ClientType,
  env,
};
