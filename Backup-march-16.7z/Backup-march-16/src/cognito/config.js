const config = {
    // Backend config
    cognito: {
      REGION: 'ap-south-1',
      USER_POOL_ID: 'ap-south-1_7ndZvghsN',
      APP_CLIENT_ID: '3qr1gc1qpu0agdr4682m85k0qt',
    //   IDENTITY_POOL_ID: process.env.REACT_APP_IDENTITY_POOL_ID,
    },
};

export default config;