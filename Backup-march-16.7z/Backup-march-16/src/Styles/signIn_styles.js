import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
    '@global': {
        body: {
            backgroundColor: theme.palette.common.white,
            backgroundImage: 'url(https://www.immensalabs.com/wp-content/uploads/2018/11/backgroun-img2.jpg)',
            backgroundSize: '100% 100%'
        },
    },
    paper: {
        marginTop: theme.spacing(15),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
    appBar: {
        backgroundColor: '#272f37',//'#44afb2',//"#459194",
    },
}));