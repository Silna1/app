import PrinterCard from "../components/pd-printer-card";

PrinterCard.getTheme = muiBaseTheme => {
  return {
    MuiCard: {
      root: {
        "&.MuiProjectCard--01": {
          transition: "0.3s",
          maxWidth: 304,
          margin: "auto",
          borderRadius: 16,
          padding: muiBaseTheme.spacing(3),
          boxShadow: "0 8px 40px -12px rgba(0,0,0,0.3)",
          "&:hover": {
            boxShadow: "0 16px 70px -12.125px rgba(0,0,0,0.3)"
          },
          "& .MuiCard__head": {
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            "& .MuiAvatar-root": {
              width: 60,
              height: 60,
              backgroundColor: "#ffffff",
              transform: "translateY(50%)"
            },
            "& .MuiTypography--headLabel": {
              color: muiBaseTheme.palette.grey[500]
            }
          },
          "& .MuiDivider-root": {
            marginLeft: -muiBaseTheme.spacing(3),
            marginRight: -muiBaseTheme.spacing(3)
          },
          "& .MuiCardContent-root": {
            textAlign: "left",
            padding: 0,
            paddingTop: muiBaseTheme.spacing(6),
            "& .MuiTypography--overline": {
              fontSize: 16,
              fontWeight: "bold",
              color: muiBaseTheme.palette.grey[500]
            },
            "& .MuiTypography--heading": {
              fontWeight: 900
            },
            "& .MuiTypography--subheading": {
              lineHeight: 1.8
            }, "& .MuiButton--readMore": {
              backgroundImage: "linear-gradient(147deg, #313e48 0%, #272f37 74%)",
              boxShadow: "0px 4px 32px rgba(68, 175, 178, 0.4)",
              borderRadius: 100,
              paddingLeft: 24,
              paddingRight: 24,
              color: "#ffffff"
            }, "&.BootstrapInput-root": {
              "& .BootstrapInput-input": {
                position: "relative",
                fontSize: 14,
                width: "auto",
              }
            }
          }
        }
      }
    }
  }
}

PrinterCard.metadata = {
  name: "Prinnter Cards",
  description: "Printer information mentioned"
};

export default PrinterCard; 