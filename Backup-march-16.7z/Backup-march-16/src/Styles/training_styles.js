export const useStyles = (theme) => ({
    lr_margin: {
        marginLeft: theme.spacing(1),
        marginLRight: theme.spacing(1)
    },
    t_margin: {
        marginTop: theme.spacing(2),
    },
    list: {
        margin: 'auto',
        maxWidth: '50%',
        backgroundColor: theme.palette.grey[200],
        overflow: 'auto',
        maxHeight: 250,
    },
    listItem: {
        textAlign: "center"
    }
});