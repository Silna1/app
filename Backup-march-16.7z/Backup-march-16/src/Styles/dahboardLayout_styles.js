import { makeStyles } from '@material-ui/core/styles';

export const useStyles1 = makeStyles(theme => ({
    root: {
        flexShrink: 0,
        color: theme.palette.text.secondary,
        marginLeft: theme.spacing(2.5),
    },
}));

export const useStyles2 = makeStyles(theme => ({
    root_Thumbnail: {
        width: '100%',
        margin: theme.spacing(6),
        paddingBottom: theme.spacing(7),
        backgroundColor:'white'
    },
    root_Search: {
        width: '100%',
        margin: theme.spacing(6),
        marginBottom: theme.spacing(0),
        alignItems: 'center',
        display: 'flex',
    },
    table: {
        minWidth: 500,
    },
    tableRow: {
        float: "right"
    },
    margin: {
        margin: theme.spacing(2),
        marginLeft: theme.spacing(10),
        width: '80%'
    },
    root_search1: {
        padding: "2px 4px",
        display: "flex",
        alignItems: "center",
        // width: "100%",
        margin: theme.spacing(6),
        // marginLeft: theme.spacing(20),
        // marginRight: theme.spacing(20),
        marginBottom: theme.spacing(0),
    },
    input: {
        width: '100%',
        marginLeft: 8,
        flex: 1,
    },
    iconButton: {
        padding: 10,
        width: 50,
        height: 70,
        color:'#A0A4A7'
    },
    divider: {
        width: 1,
        height: 28,
        margin: 4,
        float: 'right'
    },
    button: {
        textAlign: 'center',
        width: '100%',
        padding: 'auto'
    },
    paginationPadding: {
        [theme.breakpoints.up('lg')]: {
            paddingLeft: "20%",
        },
        [theme.breakpoints.down('md')]: {
            paddingLeft: "6%",
        },
    },
    whiteColor:{
        color:'#000'
    },


}));
