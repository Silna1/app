import Thumbnail from "../components/pd-thumbnail"


Thumbnail.getTheme = muiBaseTheme => ({
    MuiCard: {
        root: {
            "&.MuiReviewCard--01": {
                
                maxWidth: 304,
                // height: 300,
                margin: "auto",
                marginBottom: "20px",
                transition: "0.3s cubic-bezier(.47,1.64,.41,.8)",
                boxShadow: "0 4px 20px 0 rgba(49, 62, 72, 1)",
                borderRadius: 0,
                "& button": {
                    marginLeft: 0
                },
                "&:hover": {
                    transform: "scale(1.04)",
                    boxShadow: "0 4px 20px 0 rgba(0,0,0,0.12)",
                    cursor: "pointer"
                },
                "& .MuiCardMedia-root": {
                    height: '200px',
                    //   paddingTop: "65%",
                    position: "relative",
                },
                "& .MuiCardContent-root": {
                    textAlign: "left",
                    padding: muiBaseTheme.spacing(3),
                    "& .MuiTypography--heading": {
                        fontWeight: 900,
                        lineHeight: 1.3
                    },
                    "& .MuiTypography--subheading": {
                        lineHeight: 1.8,
                        color: muiBaseTheme.palette.text.primary,
                        fontWeight: "bold"
                    }
                },
            }
        }
    },
    
});

Thumbnail.metadata = {
    name: "Review Card I",
    description: "Commonly found in traveling guide"
};

export default Thumbnail;