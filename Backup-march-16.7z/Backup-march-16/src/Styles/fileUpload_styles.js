import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
    root: {
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-around',
        overflow: 'hidden',
        backgroundColor: theme.palette.background.paper,
    },
    gridList: {
        maxHeight: 400,
    },
    gridContainer: {
        maxWidth: '20%',
        minWidth:'250px',
        margin: theme.spacing(4),
        position: 'relative'
    },
    gridImg: {
        width: '100%',
        height: '100%',
        borderRadius: '25px',
        border: '2px solid grey',
    },
    gridIcon: {
        position: 'absolute',
        bottom: '5%',
        right: '5%'
    }

}));