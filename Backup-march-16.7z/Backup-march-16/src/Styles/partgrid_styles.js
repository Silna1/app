import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
    card: {
        display: 'flex',
        margin: theme.spacing(6),
        minWidth: '',
        '&:hover': {
            transform: "translateY(-3px)",
            boxShadow: "0 4px 20px 0 rgba(255, 102, 102,0.12)"
        }
    },
    details: {

    },
    content: {
        flexDirection: 'column',
    },
    cover: {
        minWidth: '45%',
        float: "right",
        right: 0
    },
    controls: {
        display: 'flex',
        alignItems: 'center',
        paddingLeft: theme.spacing(1),
        paddingBottom: theme.spacing(1),
    },
    playIcon: {
        height: 38,
        width: 38
    },
}));



