import { makeStyles } from '@material-ui/core/styles';

export const useStyles = makeStyles(theme => ({
    root: {
        height: 180,
        width: '100%',
      
    },
    child: {
        textAlign: 'center',
    },
    inline: {
        display: 'inline-block',
        padding: theme.spacing(3),
        margin:'0',
        minHeight:'40px',
        textAlign: 'center',
    },
}));