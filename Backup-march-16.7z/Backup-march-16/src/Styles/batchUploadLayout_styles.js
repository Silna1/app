export const useStyles = (theme) => ({
    root: {
        padding: '2px 4px',
        display: 'flex',
        alignItems: 'center',
        width: '98%'
    },
    input: {
        marginLeft: 20,
        flex: 1,
        color: '#fff',
    },
    iconButton: {
        padding: 10,
    },
    divider: {
        width: 1,
        height: 28,
        margin: 4,
    },
    uploadButton: {
        paddingTop: 10,
    },
})
