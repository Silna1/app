/////////////////////////////////////////////////////////////////////
// DEVELOPMENT configuration
//
/////////////////////////////////////////////////////////////////////
const HOST_URL = 'http://localhost'
const PORT = 8083

module.exports = {

  env: 'development',

  port: PORT,

  client: {
    host: `${HOST_URL}`,
    env: 'development',
    port: PORT
  },

  tokenKey: "Y29udGVudC5jb20vLWpKS2QyRE5OTExvL0FBQUFBQUFBQUFJL0FBQUFBQU",
  tokenExpireTime: "10h",

  refreshTokenKey: "ExvL0FBQUFBQUFFBQUFBQUF",
  refreshTokenExpireTime: "7d",

  CLIENT_ID: ['1091043831841-i19kmj5tn9204pnvrff03lt1irm8f58l.apps.googleusercontent.com',
    '1091043831841-vrkrks924mut5sukhl5s2kub5747tt88.apps.googleusercontent.com',
    '1091043831841-1os0esqu56k51ritjkvnuravp89l6e68.apps.googleusercontent.com'],

  forge: {
    credentials: {
      CLIENT_ID: "ZVrmh3UnCzdinKUE5Ybo8XpFmADkzs9o",
      CLIENT_SECRET: "Xf9e4c29873cc4a4"
    },
    scopes: {
      // Required scopes for the server-side application
      internal: ['bucket:create', 'bucket:read', 'data:read', 'data:create', 'data:write'],
      // Required scope for the client-side viewer
      public: ['viewables:read']
    },
    bucketkey: "dev_immensa",
    bucketpolicy: {
      Transient: 'transient',
      Temporary: 'temporary',
      Persistent: 'persistent'
    },
    bucketlimit: 50
  },

  aws: {
    dynamodb: {
      credentials: {
        "region": "ap-south-1",
        "accessKeyId": "AKIARCFG6GEK3DUE3FH5",
        "secretAccessKey": "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",
      },
      tableInfo: {
        //"PartDatabase": "Parts-Production",
        "PartDatabase": "Immensa_Database_2",
        "UserDataBase": "User",
        "PrinterDatabase": "Printer",
        "CommentsDatabase":"Comments_Table",
        "ClientDatabase":"Clients_Table",
        "ProjectDatabase": "Project_Table",
        "SectorDatabase": "ClientSector",
        "LocationDatabase":"Location_Table",
        "ProjectDatabase":"Project_Table",
        "PartsCount":"parts_count",
        "GraphTable":"graph_tbl",
        "ImmensaDB2":"Immensa_Database_2",
        "Top9Cats":"top9cats_tbl",
        "MaterialsTable":"materials_tbl",
        "Menu_AccessTable": "Menu_Access",
        "Data_AccessTable": "Data_Access"

      }
    },
    s3: {
      "params": { "Bucket": "dev-part-digitizer-web-storage", "Data_Bucket": "dev-part-digitizer-web-storage-data" },
      "region": "ap-south-1",
      "accessKeyId": "AKIARCFG6GEK3DUE3FH5",
      "secretAccessKey": "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",
    },
    ses: {
      "region": "us-east-1",
      "accessKeyId": "AKIARCFG6GEK3DUE3FH5",
      "secretAccessKey": "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",
      emailVerificationTemplateParams: {
        'FailureRedirectionURL': 'https://dev.immensa3d.com',
        'SuccessRedirectionURL': 'https://dev.immensa3d.com',
        'FromEmailAddress': 'developer@immensalabs.com',
        'TemplateName': 'Dev_UserEmailVerification_template',
      }
    },
    cognito: {
      "region": "ap-south-1",
      "accessKeyId": "AKIARCFG6GEK3DUE3FH5",
      "secretAccessKey": "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",
    }
  }
}
