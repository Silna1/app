'use strict';
var http = require('http'); // needed to integrate with ws package for mock web socket server.
var express = require('express');
var bodyParser = require('body-parser');

var app = express();

app.use(bodyParser.json());

//Testing code for CORS

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT,DELETE");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Access-Control-Request-Method, Accept, Access-Control-Request-Headers, Authorization, authorization");
    next();
});

var httpServer = http.createServer(app);

//register services
var Dynamodb = require("./services/AwsDynamodbSvc");
var S3 = require("./services/AwsS3Svc");
var Email = require("./services/AwsEmailSvc");
var ServiceManager = require('./services/SvcManager');
var ForgeViewer = require("./services/ForgeViewerSvc");
var CognitoService = require("./services/AwsCognitoSvc");

const s3 = new S3();
const dynamodb = new Dynamodb();
const email = new Email();
const forgeViewer = new ForgeViewer();
const cognito = new CognitoService();

ServiceManager.registerService(s3);
ServiceManager.registerService(dynamodb);
ServiceManager.registerService(forgeViewer);
ServiceManager.registerService(email);
ServiceManager.registerService(cognito);

//Add routes for controllers
var PartdataController = require('./controllers/partDataController')
app.use('/part', new PartdataController());

var AuthController = require('./controllers/authController')
app.use('/auth', new AuthController())
app.get('/', (req, res) => res.status(200).send('ok'));





var UserController = require('./controllers/userController')
app.use('/user', new UserController())

var PrinterController = require('./controllers/printerController')
app.use('/printer', new PrinterController())

var SearchController = require('./controllers/searchController')
app.use('/search', new SearchController())

var PrintabilityController = require('./controllers/printabilityController')
app.use('/score', new PrintabilityController())

var ForgeViewerController = require('./controllers/forgeController')
app.use('/viewer', new ForgeViewerController())

var ClientController = require('./controllers/clientController')
app.use('/client', new ClientController())

var LocationController = require('./controllers/locationController')
app.use('/location', new LocationController())

var ProjectController = require('./controllers/projectController')
app.use('/project', new ProjectController())

var MenuAccessController = require('./controllers/menuAccessController')
app.use('/menuaccess', new MenuAccessController())

var DataAccessController = require('./controllers/dataAccessController')
app.use('/dataaccess', new DataAccessController())
// app.use(express.static(__dirname + '/../build/es5-bundled'));

httpServer.listen(process.env.VCAP_APP_PORT || 8083, function () {
    console.log('Server started on port: ' + httpServer.address().port);
});
