const express = require('express');
var ServiceManager = require('../services/SvcManager');
var forgeUtils = require('./../helpers/ForgeViewerUtils');
var utils = require('./../helpers/utils');

module.exports = function () {

    var router = express.Router();

    router.get('/token', utils.verificationByToken, async (req, res) => {
        try {
            let viewer = ServiceManager.getService('ForgeViewerSvc');
            viewer.getInternalToken()
                .then((data) => {
                    let token = {
                        access_token: data.token.access_token,
                        expires_in: data.token.expires_in
                    }
                    res.status(200).send(token);
                })
        } catch (error) {
            res.status(400).send(error);
        }
    });

    router.post('/createBucket', utils.verificationByToken, async (req, res) => {
        try {
            let viewer = ServiceManager.getService('ForgeViewerSvc');
            await viewer.createbucket();
            res.status(200).end();
        } catch (error) {
            res.status(400).send(error);
        }
    });

    router.get('/getBucketList', utils.verificationByToken, async (req, res) => {
        try {
            let viewer = ServiceManager.getService('ForgeViewerSvc');
            const buckets = await viewer.getBucketList(req);
            res.json(buckets.body.items.map((bucket) => {
                return {
                    id: bucket.bucketKey,
                    type: 'bucket',
                }
            }));
        } catch (error) {
            res.status(400).send(error);
        }
    });

    router.post('/getFilesFromBucket', utils.verificationByToken, async (req, res) => {
        try {
            let viewer = ServiceManager.getService('ForgeViewerSvc');
            const objects = await viewer.getFilesFromBucket();
            res.json(objects.body.items.map((object) => {
                return {
                    id: Buffer.from(object.objectId).toString('base64'),
                    text: object.objectKey,
                }
            }));
        } catch (error) {
            res.status(400).send(error);
        }
    });

    router.post('/translateFile', utils.verificationByToken, async (req, res) => {
        try {
            let viewer = ServiceManager.getService('ForgeViewerSvc');
            let file = await viewer.translateFile(req.body.urn);
            res.status(200).send(file);
        } catch (error) {
            res.status(400).send(error);
        }
    })

    router.post('/uploadFile', utils.verificationByToken, async (req, res) => {
        try {
            let viewer = ServiceManager.getService('ForgeViewerSvc');
            let file = await viewer.uploadFile(req.fileName, req.filePath);
            res.status(200).send(file);
        } catch (error) {
            res.status(400).send(error);
        }
    });

    router.post('/getTranslationProgress', utils.verificationByToken, async (req, res) => {
        try {
            let viewer = ServiceManager.getService('ForgeViewerSvc');
            let translationStatus = await viewer.getTranslationProgress(req.body.urn);
            res.status(200).send(translationStatus);
        } catch (error) {
            res.status(400).send(error);
        }
    });

    router.post('/downloadFile', utils.verificationByToken, async (req, res) => {
        try {
            let signedUrl = await forgeUtils.downloadFileFromS3(req.body.uid, req.body.name);
            res.status(200).send({ 'url': signedUrl });
        } catch (error) {
            res.status(500).send(error);
        }
    })

    return router;
}
