var express = require('express');
var ServiceManager = require('../services/SvcManager');
const uuid = require('uuid/v4');
var config = require('c0nfig')
var dynamodbUpdateExpression = require('dynamodb-update-expression');
var utils = require('../helpers/utils');

module.exports = function () {
    var router = express.Router();

    let AwsDynamodb = ServiceManager.getService('AwsDynamoSvc')

    router.post('/add', utils.verificationByToken,async (req, res) => {

        try {
            
            const data = req.body.location;
            console.log("inside location add",data);
            let nparams = {
                TableName: config.aws.dynamodb.tableInfo.LocationDatabase,
                FilterExpression: "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "name"
                },
                ExpressionAttributeValues: {
                    ":value": data.name
                },
            }

            let ndata = await AwsDynamodb.scanItem(nparams);
            if (ndata.Items.length > 0)
            {
                res.status(409).send({message: "Location Name already exist",statusCode:409,statuskey:"Nexist"})
            }
            else
            {
                let locationData = {
                    id: uuid(),
                    name:data.name,
                    searchname: data.name.toLowerCase(),
                    client:data.client,
                    officeName:data.officeName,
                    address1: data.address1,
                    address2:data.address2,
                    city:data.city,
                    state:data.state,
                    country:data.country,
                    pinCode:data.pinCode,
                    isDelete : "false",
                }
           
            let params = {
                TableName: config.aws.dynamodb.tableInfo.LocationDatabase,
                Item: locationData,
            }
            console.log("config.aws.dynamodb.tableInfo.LocationDatabase",params);

            //insert data to table
            AwsDynamodb.putItem(params)
                .then((data) => {
                    res.status(200).send({ 'location': params.Item });
                })
                .catch((err) => {
                    res.status(400).send(err)
                });
        }
    }
        catch (err) {
            res.status(500).send(err);
        }

    })

    router.get('/all', utils.verificationByToken, async (req, res) => {
        try {
            console.trace();
            console.log("inside location all");
            let params = {
                TableName: config.aws.dynamodb.tableInfo.LocationDatabase,
                FilterExpression: "#id = :value" ,
                ExpressionAttributeNames: {
                    "#id": "isDelete"
                },
                ExpressionAttributeValues: {
                    ":value": "false"
                },
            }
            console.log("search location" ,req.query);
            if(req.query?.searchname){
                params.FilterExpression= "#id = :value AND contains (#locname,:locvalue)";
                params.ExpressionAttributeNames=
                {
                    ...params.ExpressionAttributeNames,
                    "#locname": "searchname",

                };
                params.ExpressionAttributeValues=
                {
                    ...params.ExpressionAttributeValues,
                    ":locvalue": req.query.searchname,
                }

            }


            let data = await AwsDynamodb.scanItem(params);
            console.log("silna",data);
            res.status(200).send(data);
        }
        catch (err) {
            res.status(400).send({ 'error': err });
        }
    })

    router.get('/clientlocation', utils.verificationByToken, async (req, res) => {
        try {
            let params = {
                TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
                FilterExpression: "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "isDelete"
                },
                ExpressionAttributeValues: {
                    ":value": "false"
                },
            }

            let data = await AwsDynamodb.scanItem(params);
            console.trace();
            console.log("inside clientlocation all");
            const result = [...data.Items];
            await Promise.all(data.Items.map(async (item, i) => {
                let params = {
                    TableName: config.aws.dynamodb.tableInfo.LocationDatabase,
                    FilterExpression: "#id = :value",
                    ExpressionAttributeNames: {
                        "#id": "clientId"
                    },
                    ExpressionAttributeValues: {
                        ":value": item.id
                    },
                }
                let data = await AwsDynamodb.scanItem(params);
                console.log("silna location result",result);
                console.log('locations', i, data)
                result[i].locations=data.Items;
                console.log("silna location result items",result[i].locations
                );
            }));
            console.log("silna results ",result);
            res.status(200).send(result);
        }
        catch (err) {
            res.status(400).send({ 'error': err });
        }
    })

    router.delete('/delete', utils.verificationByToken, (req, res) => {
        try {
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');

            let params = {
                TableName: config.aws.dynamodb.tableInfo.LocationDatabase,
                Key: {
                    id: req.body.id
                }
            }
            AwsDynamoDb.deleteItem(params)
                .then((data) => {
                    res.status(200).send({ "message": "Delete request for location is executed successfully" });
                }).catch((err) => {
                    res.status(400).send(err)
                })
        }
        catch (err) {
            res.status(500).send(err);
        }

    })

    router.post("/byid", utils.verificationByToken, (req, res) => {
        let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
    
        try {
          if (req.body.id === undefined || req.body.id === null) {
            res.status(400).send("Please provide the required information");
          } else {
            let queryParams = {
              TableName: config.aws.dynamodb.tableInfo.LocationDatabase,
              KeyConditionExpression: "#id = :value",
              ExpressionAttributeNames: {
                "#id": "id",
              },
              ExpressionAttributeValues: {
                ":value": req.body.id,
              },
            };
    
            AwsDynamoDb.queryItem(queryParams)
              .then((data) => {
                if (data.Count !== 0) {
                  res.status(200).send(data.Items[0])
                } else {
                  res.status(200).send({
                    message: `Requested Item ${req.body.id} is not present in database`,
                  });
                }
              })
              .catch((err) => {
                res.status(400).send(err);
              })
          }
        } catch (err) {
          res.status(500).send(err);
        }
      });

      router.put('/update', utils.verificationByToken, async (req, res) => {
        try {
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
            let params = {
                TableName: config.aws.dynamodb.tableInfo.LocationDatabase,
                KeyConditionExpression:  "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "id"
                },
                ExpressionAttributeValues: {
                    ":value": req.body.location.id
                }
            }
            const updateParams = req.body.location;
            let data = await AwsDynamoDb.queryItem(params);
            if (data.Count !== 0) {
                const queryData = data.Items[0];
                let updateExpression = dynamodbUpdateExpression.getUpdateExpression(queryData, updateParams);
                updateExpression.Key = {
                    id: req.body.location.id
                }
                updateExpression.TableName = config.aws.dynamodb.tableInfo.LocationDatabase
                await AwsDynamoDb.updateItem(updateExpression);
                res.status(200).send({ "message": "location data is updated successfully" });
            }
            else {
                res.status(400).send({ "message": "Please provide the required information" });
            }
        } catch (err) {
            res.status(400).send(err);
        }
    })

    router.put('/deletes', utils.verificationByToken, async (req, res) => {
        try {
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
            let params = {
                TableName: config.aws.dynamodb.tableInfo.LocationDatabase,
                KeyConditionExpression:  "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "id"
                },
                ExpressionAttributeValues: {
                    ":value": req.body.location.id
                }
            }
            req.body.location.isDelete ="true";
            const updateParams = req.body.location;
            console.log("updateparams ",updateParams);
            console.log("update data",params);
            let data = await AwsDynamoDb.queryItem(params);
            console.log("update data",data);
            if (data.Count !== 0) {
                const queryData = data.Items[0];
                let updateExpression = dynamodbUpdateExpression.getUpdateExpression(queryData, updateParams);
                updateExpression.Key = {
                    id: req.body.location.id
                }
                console.log("querydata", queryData);
                updateExpression.TableName = config.aws.dynamodb.tableInfo.LocationDatabase
                await AwsDynamoDb.updateItem(updateExpression);
                res.status(200).send({ "message": "Location  deleted successfully" });
            }
            else {
                res.status(400).send({ "message": "Please provide the required information" });
            }
        } catch (err) {
            res.status(400).send(err);
        }
    })

    router.post('/dataaccesslocation', utils.verificationByToken, async (req, res) => {
        try {
            console.trace();
            console.log("inside dataaccesslocation all");
            let params = {
                TableName: config.aws.dynamodb.tableInfo.LocationDatabase,
                FilterExpression: "#id = :value AND contains (#clientid,:clientvalue)" ,
                ExpressionAttributeNames: {
                    "#id": "isDelete",
                    "#clientid": "client.id"
                },
                ExpressionAttributeValues: {
                    ":value": "false",
                    ":clientvalue": req.body.clients
                },
            }
            
            let data = await AwsDynamodb.scanItem(params);
            console.log("silna",data);
            res.status(200).send(data);
        }
        catch (err) {
            res.status(400).send({ 'error': err });
        }
    })





    return router;
}