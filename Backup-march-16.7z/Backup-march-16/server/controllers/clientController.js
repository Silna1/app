var express = require('express');
var ServiceManager = require('../services/SvcManager');
const uuid = require('uuid/v4');
var config = require('c0nfig')
var dynamodbUpdateExpression = require('dynamodb-update-expression');
var utils = require('../helpers/utils');

module.exports = function () {
    var router = express.Router();

    let AwsDynamodb = ServiceManager.getService('AwsDynamoSvc')

    router.post('/add', utils.verificationByToken, async(req, res) => {

        try {
            
            const data = req.body.client;
            // console.log("inside client add",data);
            let cparams = {
                TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
                FilterExpression: "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "email"
                },
                ExpressionAttributeValues: {
                    ":value": data.email
                },
            }

            let cdata = await AwsDynamodb.scanItem(cparams);
            if (cdata.Items.length > 0)
            {
                res.status(409).send({message: "Email Id already exist",statusCode:409,statuskey:"Eexist"})
            }
            else {
                let pparams = {
                    TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
                    FilterExpression: "#id = :value",
                    ExpressionAttributeNames: {
                        "#id": "phoneNumber"
                    },
                    ExpressionAttributeValues: {
                        ":value": data.phoneNumber
                    },
                }
    
                let cdata = await AwsDynamodb.scanItem(pparams);
                if (cdata.Items.length > 0)
                {
                    res.status(409).send({message: "Phone Number already exist",statusCode:409,statuskey:"PNexist"})
                }
                else{


                        let clientData = {
                            id: uuid(),
                            clientName: data.clientName,
                            searchname: data.clientName.toLowerCase(),
                            clientLogo: data.clientLogo,
                            phoneNumber: data.phoneNumber,
                            active: data.active,
                            email:data.email,
                            createDate: data.createDate,
                            lastUpdate: data.lastUpdate,
                            createdbyUser:data.createdbyUser,
                            updatedbyUser:data.updatedbyUser,
                            isDelete : "false",
                            address1:data.address1,
                            address2:data.address2,
                            city:data.city,
                            state:data.state,
                            country:data.country,
                            pinCode:data.pinCode,
                            sector:data.sector,
                            clientType:data.clientType
                        }
           
                        let params = {
                            TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
                            Item: clientData,
                        }
                        // console.log("config.aws.dynamodb.tableInfo.ClientDatabase",params);

                        //insert data to table
                        AwsDynamodb.putItem(params)
                            .then((data) => {
                                res.status(200).send({ 'clients': params.Item });
                            })
                            .catch((err) => {
                                res.status(400).send(err)
                            });
                }
             }
        }
        catch (err) {
            res.status(500).send(err);
        }


    })

    //api to get part data using id.
  router.post("/getclientbyid", utils.verificationByToken, (req, res) => {
    let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");

    try {
      if (req.body.id === undefined || req.body.id === null) {
        res.status(400).send("Please provide the required information");
      } else {
        let queryParams = {
          TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
          KeyConditionExpression: "#id = :value",
          ExpressionAttributeNames: {
            "#id": "id",
          },
          ExpressionAttributeValues: {
            ":value": req.body.id,
          },
        };

        AwsDynamoDb.queryItem(queryParams)
          .then((data) => {
            if (data.Count !== 0) {
              res.status(200).send(data.Items[0])
            } else {
              res.status(200).send({
                message: `Requested Item ${req.body.id} is not present in database`,
              });
            }
          })
          .catch((err) => {
            res.status(400).send(err);
          })
      }
    } catch (err) {
      res.status(500).send(err);
    }
  });

    router.get('/all',utils.verificationByToken, async (req, res) => {
        // console.trace();
        // console.log("inside client all");
        try {
            let params = {
                TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
                FilterExpression: "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "isDelete"
                },
                ExpressionAttributeValues: {
                    ":value": "false"
                },
            }

            // console.log("search ClientName" ,req.query);
            if(req.query?.searchname){
                params.FilterExpression= "#id = :value AND contains (#clientname,:clientvalue)";
                params.ExpressionAttributeNames=
                {
                    ...params.ExpressionAttributeNames,
                    "#clientname": "searchname",

                };
                params.ExpressionAttributeValues=
                {
                    ...params.ExpressionAttributeValues,
                    ":clientvalue": req.query.searchname,
                }

            }

            let data = await AwsDynamodb.scanItem(params);
            // console.log("silna",data);
            res.status(200).send(data);
        }
        catch (err) {
            res.status(400).send({ 'error': err });
        }
    })

    


    router.delete('/delete', utils.verificationByToken, (req, res) => {
        try {
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');

            let params = {
                TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
                Key: {
                    id: req.body.id
                }
            }
            AwsDynamoDb.deleteItem(params)
                .then((data) => {
                    res.status(200).send({ "message": "Delete request for clients is executed successfully" });
                }).catch((err) => {
                    res.status(400).send(err)
                })
        }
        catch (err) {
            res.status(500).send(err);
        }

    })

    router.put('/update', utils.verificationByToken, async (req, res) => {
        try {
            const data = req.body.client;
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
            let cparams = {
                TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
                FilterExpression: "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "email"
                },
                ExpressionAttributeValues: {
                    ":value": data.email
                },
            }

            let cdata = await AwsDynamodb.scanItem(cparams);
            if (cdata.Items.length > 0 && cdata.Items[0].id !== data.id )
            {
                res.status(409).send({message: "Email Id already exist",statusCode:409,statuskey:"Eexist"})
            }
            else {
                let pparams = {
                    TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
                    FilterExpression: "#id = :value",
                    ExpressionAttributeNames: {
                        "#id": "phoneNumber"
                    },
                    ExpressionAttributeValues: {
                        ":value": data.phoneNumber
                    },
                }
    
                let cdata = await AwsDynamodb.scanItem(pparams);
                if (cdata.Items.length > 0  && cdata.Items[0].id !== data.id)
                {
                    res.status(409).send({message: "Phone Number already exist",statusCode:409,statuskey:"PNexist"})
                }
                else
                {
            let params = {
                TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
                KeyConditionExpression:  "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "id"
                },
                ExpressionAttributeValues: {
                    ":value": req.body.client.id
                }
            }

            const updateParams = req.body.client;
            // console.log("updateparams ",updateParams);
            // console.log("update data",params);
            let data = await AwsDynamoDb.queryItem(params);
            // console.log("update data",data);
            if (data.Count !== 0) {
                const queryData = data.Items[0];
                let updateExpression = dynamodbUpdateExpression.getUpdateExpression(queryData, updateParams);
                updateExpression.Key = {
                    id: req.body.client.id,
                    createDate: req.body.client.createDate
                }
                // console.log("querydata", queryData);
                updateExpression.TableName = config.aws.dynamodb.tableInfo.ClientDatabase
                await AwsDynamoDb.updateItem(updateExpression);
                res.status(200).send({ "message": "clients data is updated successfully" });
            }
            else {
                res.status(400).send({ "message": "Please provide the required information" });
            }
        }
    }
}
        catch (err) {
            res.status(400).send(err);
        }
    })

    router.put('/deletes', utils.verificationByToken, async (req, res) => {
        try {
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
            let params = {
                TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
                KeyConditionExpression:  "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "id"
                },
                ExpressionAttributeValues: {
                    ":value": req.body.client.id
                }
            }
            req.body.client.isDelete ="true";
            const updateParams = req.body.client;
            // console.log("updateparams ",updateParams);
            // console.log("update data",params);
            let data = await AwsDynamoDb.queryItem(params);
            // console.log("update data",data);
            if (data.Count !== 0) {
                const queryData = data.Items[0];
                let updateExpression = dynamodbUpdateExpression.getUpdateExpression(queryData, updateParams);
                updateExpression.Key = {
                    id: req.body.client.id,
                    createDate: req.body.client.createDate
                }
                // console.log("querydata", queryData);
                updateExpression.TableName = config.aws.dynamodb.tableInfo.ClientDatabase
                await AwsDynamoDb.updateItem(updateExpression);
                res.status(200).send({ "message": "clients data is deleted successfully" });
            }
            else {
                res.status(400).send({ "message": "Please provide the required information" });
            }
        } catch (err) {
            res.status(400).send(err);
        }
    })

    router.get('/sector', utils.verificationByToken, async (req, res) => {
        try {
            // console.trace();
            // console.log("inside sector all");
            let params = {
                TableName: config.aws.dynamodb.tableInfo.SectorDatabase
            }

            let data = await AwsDynamodb.scanItem(params);
            // console.log("silna",data);
            res.status(200).send(data);
        }
        catch (err) {
            res.status(400).send({ 'error': err });
        }
    })

    return router;
}