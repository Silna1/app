const { workerData, parentPort } = require('worker_threads')
var config = require("c0nfig");
var AWS = require("aws-sdk");
AWS.config.update(config.aws.dynamodb.credentials);
let docClient = new AWS.DynamoDB.DocumentClient();

console.log(workerData);
/*let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
let params = {
  TableName: config.aws.dynamodb.tableInfo.PartsCount,
  KeyConditionExpression: "#organizationName = :organizationValue",
  ExpressionAttributeNames: {"#organizationName": "id"},
  ExpressionAttributeValues: {":organizationValue": workerData},
  Limit: 2000,
};

docClient.query(params, function(err, data) {
    if (err) {
        console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
    } else {
        console.log(data);
        //data.Items.forEach(function(item) {
        //console.log(" -", item.year + ": " + item.title);
    }
});*/


    let counter = 0;
    let isLast = false;
    let prev;
    let cure;

    //First Time
    (async () => {
        const resultFT = await partCountParser(0,workerData);
        counter = counter + Number(resultFT.ScannedCount);
       //if Last Evaluated Key Presnted 
        cure = resultFT;
        if(resultFT.LastEvaluatedKey)
        {
          isLast = true;
          while(isLast)
          { 
            prev = cure;
           
            const result = await partCountParser(prev.LastEvaluatedKey.id,workerData);
            if(result.LastEvaluatedKey)
            {
                counter = counter + Number(result.ScannedCount);
            }
            else
            {
              counter = counter + Number(result.ScannedCount);
              isLast = false;
            }
            cure = result;
           
           
          }
        }
        else
        {
        }
        console.log(counter);



        //Update Item
        var params = {
            TableName:"parts_count",
            Key:{
                "id": workerData,
            },
            UpdateExpression: "set counts = :r",
            ExpressionAttributeValues:{
                ":r":counter,
            },
        };

        ///
        docClient.update(params, function (err, datax) {
            if (err) {
                console.error("Unable to query Counter. Error:", JSON.stringify(err, null, 2));
            } else {
               
            }              
        })
                
          
        

        

      })().catch(e => console.log("Got " + e));
    
  
 




   

//Parser 
function  partCountParser(leid,orga) {
   return new Promise(resolve => {
      let params = {
        TableName: config.aws.dynamodb.tableInfo.PartDatabase,
        IndexName: "organization-index",
        KeyConditionExpression: "#organizationName = :organizationValue",
        ExpressionAttributeNames: {"#organizationName": "organization"},
        ExpressionAttributeValues: {":organizationValue": orga},
        Limit: 1000,
      };

      if(leid == 0)
      {
      }
      else
      {
        params.ExclusiveStartKey = {
          id: leid,
          organization: orga,
        };
      }
      docClient.query(params, function(err, data) {
        if (err) {
            console.error("Unable to query Counter. Error:", JSON.stringify(err, null, 2));
        } else {
            resolve(data);
        }
    });
  });
  }