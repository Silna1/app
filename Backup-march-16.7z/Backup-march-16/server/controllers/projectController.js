var express = require('express');
var ServiceManager = require('../services/SvcManager');
const uuid = require('uuid/v4');
var config = require('c0nfig')
var dynamodbUpdateExpression = require('dynamodb-update-expression');
var utils = require('../helpers/utils');

module.exports = function () {
    var router = express.Router();

    let AwsDynamodb = ServiceManager.getService('AwsDynamoSvc')

    router.post('/add', utils.verificationByToken,async (req, res) => {

        try {
            
            const data = req.body.project;
            let nparams = {
                TableName: config.aws.dynamodb.tableInfo.ProjectDatabase,
                FilterExpression: "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "name"
                },
                ExpressionAttributeValues: {
                    ":value": data.name
                },
            }

            let ndata = await AwsDynamodb.scanItem(nparams);
            if (ndata.Items.length > 0)
            {
                res.status(409).send({message: "Project Name already exist",statusCode:409,statuskey:"Nexist"})
            }
            else
            {
            // console.log("inside project add",data);
            let projectData = {
                projectId: uuid(),
                name:data.name,
                searchname: data.name.toLowerCase(),
                isDelete:"false",
                description:data.description,
                client:data.client,
                location:data.location,
                createDate: data.createDate,
                lastUpdate: data.lastUpdate,
                createdUser:data.createdUser,
                updatedUser:data.updatedUser,
                projStatus: data.projStatus,
                projOwner:data.projOwner,
                startDate:data.startDate,
                lastDate:data.lastDate,
                projPriority: data.projPriority,
                projCloseDate: data.projCloseDate,
                partsCount: data.partsCount
            }
           
            let params = {
                TableName: config.aws.dynamodb.tableInfo.ProjectDatabase,
                Item: projectData,
            }
            // console.log("config.aws.dynamodb.tableInfo.ProjectDatabase",params);

            //insert data to table
            AwsDynamodb.putItem(params)
                .then((data) => {
                    res.status(200).send({ 'project': params.Item });
                })
                .catch((err) => {
                    res.status(400).send(err)
                });
        }
    }
        catch (err) {
            res.status(500).send(err);
        }

    })


    router.get('/all',utils.verificationByToken, async (req, res) => {
        // console.trace();
        // console.log("inside project all");
        try {
            // console.trace();
            // console.log("inside project all");
            let params = {
                TableName: config.aws.dynamodb.tableInfo.ProjectDatabase,
                FilterExpression: "#id = :value" ,
                ExpressionAttributeNames: {
                    "#id": "isDelete"
                },
                ExpressionAttributeValues: {
                    ":value": "false"
                },
            }

            // console.log("search project" ,req.query);
            if(req.query?.searchname){
                params.FilterExpression= "#id = :value AND contains (#projname,:projvalue)";
                params.ExpressionAttributeNames=
                {
                    ...params.ExpressionAttributeNames,
                    "#projname": "searchname",

                };
                params.ExpressionAttributeValues=
                {
                    ...params.ExpressionAttributeValues,
                    ":projvalue": req.query.searchname,
                }

            }
            let data = await AwsDynamodb.scanItem(params);
            // console.log("silna",data);
            res.status(200).send(data);
        }
        catch (err) {
            res.status(400).send({ 'error': err });
        }
    })

    router.post("/byid", utils.verificationByToken, (req, res) => {
        let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
    
        try {
          if (req.body.id === undefined || req.body.id === null) {
            res.status(400).send("Please provide the required information");
          } else {
            let queryParams = {
              TableName: config.aws.dynamodb.tableInfo.ProjectDatabase,
              KeyConditionExpression: "#id = :value",
              ExpressionAttributeNames: {
                "#id": "projectId",
              },
              ExpressionAttributeValues: {
                ":value": req.body.id,
              },
            };
    
            AwsDynamoDb.queryItem(queryParams)
              .then((data) => {
                if (data.Count !== 0) {
                  res.status(200).send(data.Items[0])
                } else {
                  res.status(200).send({
                    message: `Requested Item ${req.body.id} is not present in database`,
                  });
                }
              })
              .catch((err) => {
                res.status(400).send(err);
              })
          }
        } catch (err) {
          res.status(500).send(err);
        }
      });

      router.put('/update', utils.verificationByToken, async (req, res) => {
        try {
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
            let params = {
                TableName: config.aws.dynamodb.tableInfo.ProjectDatabase,
                KeyConditionExpression:  "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "projectId"
                },
                ExpressionAttributeValues: {
                    ":value": req.body.project.projectId
                }
            }
            const updateParams = req.body.project;
            let data = await AwsDynamoDb.queryItem(params);
            if (data.Count !== 0) {
                const queryData = data.Items[0];
                let updateExpression = dynamodbUpdateExpression.getUpdateExpression(queryData, updateParams);
                updateExpression.Key = {
                    projectId: req.body.project.projectId
                }
                updateExpression.TableName = config.aws.dynamodb.tableInfo.ProjectDatabase
                await AwsDynamoDb.updateItem(updateExpression);
                res.status(200).send({ "message": "project data is updated successfully" });
            }
            else {
                res.status(400).send({ "message": "Please provide the required information" });
            }
        } catch (err) {
            res.status(400).send(err);
        }
    })
    
    router.delete('/delete', utils.verificationByToken, (req, res) => {
        try {
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');

            let params = {
                TableName: config.aws.dynamodb.tableInfo.ProjectDatabase,
                Key: {
                    projectId: req.body.id
                }
            }
            AwsDynamoDb.deleteItem(params)
                .then((data) => {
                    res.status(200).send({ "message": "Delete request for project is executed successfully" });
                }).catch((err) => {
                    res.status(400).send(err)
                })
        }
        catch (err) {
            res.status(500).send(err);
        }

    })

    router.put('/deletes', utils.verificationByToken, async (req, res) => {
        try {
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
            let params = {
                TableName: config.aws.dynamodb.tableInfo.ProjectDatabase,
                KeyConditionExpression:  "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "projectId"
                },
                ExpressionAttributeValues: {
                    ":value": req.body.project.projectId
                }
            }
            req.body.project.isDelete ="true";
            const updateParams = req.body.project;
            // console.log("updateparams ",updateParams);
            // console.log("update data",params);
            let data = await AwsDynamoDb.queryItem(params);
            // console.log("update data",data);
            if (data.Count !== 0) {
                const queryData = data.Items[0];
                let updateExpression = dynamodbUpdateExpression.getUpdateExpression(queryData, updateParams);
                updateExpression.Key = {
                    projectId: req.body.project.projectId
                }
                // console.log("querydata", queryData);
                updateExpression.TableName = config.aws.dynamodb.tableInfo.ProjectDatabase
                await AwsDynamoDb.updateItem(updateExpression);
                res.status(200).send({ "message": "Project deleted successfully" });
            }
            else {
                res.status(400).send({ "message": "Please provide the required information" });
            }
        } catch (err) {
            res.status(400).send(err);
        }
    })

    router.get('/clientproject', utils.verificationByToken, async (req, res) => {
        try {
            let params = {
                TableName: config.aws.dynamodb.tableInfo.ClientDatabase,
                FilterExpression: "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "isDelete"
                },
                ExpressionAttributeValues: {
                    ":value": "false"
                },
            }

            let data = await AwsDynamodb.scanItem(params);
            // console.trace();
            // console.log("inside clientlocation all");
            const result = [...data.Items];
			
			
            await Promise.all(data.Items.map(async (item, i) => {
                let params = {
                    TableName: config.aws.dynamodb.tableInfo.ProjectDatabase,
                    FilterExpression: "#id = :value",
                    ExpressionAttributeNames: {
                        "#id": "clientId"
                    },
                    ExpressionAttributeValues: {
                        ":value": item.clientName
                    },
                }
                let data = await AwsDynamodb.scanItem(params);
                // console.log('project client', i, data)
                result[i].project=data.Items;
            }));
            // console.log("silna",data);
            res.status(200).send(result);
        }
        catch (err) {
            res.status(400).send({ 'error': err });
        }
    })
	
router.get('/projectlocation', utils.verificationByToken, async (req, res) => {
        try {
            let params = {
                TableName: config.aws.dynamodb.tableInfo.LocationDatabase,
                FilterExpression: "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "isDelete"
                },
                ExpressionAttributeValues: {
                    ":value": "false"
                },
            }

            let data = await AwsDynamodb.scanItem(params);
            // console.trace();
            // console.log("inside clientlocation all");
            const result = [...data.Items];
			
			
            await Promise.all(data.Items.map(async (item, i) => {
                let params = {
                    TableName: config.aws.dynamodb.tableInfo.ProjectDatabase,
                    FilterExpression: "#id = :value",
                    ExpressionAttributeNames: {
                        "#id": "locationId"
                    },
                    ExpressionAttributeValues: {
                        ":value": item.id
                    },
                }
                let data = await AwsDynamodb.scanItem(params);
                // console.log('projects', i, data)
                result[i].project=data.Items;
            }));
            // console.log("silna",data);
            res.status(200).send(result);
        }
        catch (err) {
            res.status(400).send({ 'error': err });
        }
    })

    return router;
}