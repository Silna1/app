var express = require('express');
var utils = require('../helpers/utils')
var partUtils = require('../helpers/partUtils')

module.exports = function () {

    var router = express.Router();

    router.post('/getprintabilityScore', utils.verificationByToken, async (req, res) => {
        try {
            let params = {
                material: req.body.material,
                size: req.body.size,
                complexity: req.body.complexity
            }
            let score = await partUtils.getPrintabilityScore(params);
            res.status(200).send({ 'Score': score });
        }
        catch (ex) {
            res.status(400).send({ 'error': ex })
        }
    })

    return router;

}