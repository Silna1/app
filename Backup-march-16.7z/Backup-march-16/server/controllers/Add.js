var AWS = require('aws-sdk');
const uuid = require('uuid/v4');

var region = "ap-south-1";
var accessKeyId = 'AKIARCFG6GEK3DUE3FH5';
var secretAccessKey = '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';
var tableName = "ClientSector";

var dynamoDB = new AWS.DynamoDB.DocumentClient({
  region: region,
  accessKeyId: accessKeyId,
  secretAccessKey: secretAccessKey,
});


var params = {
  Item: {
    sectorId: uuid(),
    name: "Finance/Insurance",
  },
  TableName: tableName,
};

dynamoDB.put(params, function(err, data) {
  if (err) {
    console.error(err);
  }
  else {
    console.log(data);
  }
});


