var express = require('express');
var ServiceManager = require('../services/SvcManager');
var config = require('c0nfig')
var utils = require('./../helpers/utils');

module.exports = function () {

    var router = express.Router();

    let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
    let AwsS3Svc = ServiceManager.getService('AwsS3Svc');

    router.get('/part', utils.verificationByToken, async (req, res) => {
        try {
            let params = {
                TableName: config.aws.dynamodb.tableInfo.PartDatabase,
                ProjectionExpression: "category, #partname, notes, description, material,imagesPath, s3Key, id, #partNumber ,complexity",
                ExpressionAttributeNames: {
                    '#partname': 'name',
                    '#partNumber': 'number'
                }
            }
            let data = await AwsDynamoDb.scanItem(params);
            let AwsS3Svc = ServiceManager.getService('AwsS3Svc');

            let getSignedUrl = new Promise(async (resolve, reject) => {

                for (let i = 0; i <= data.Items.length - 1; i++) {

                    //NOTE : Below code is for old data support when we were not having compressed data.
                    let s3Keys = data.Items[i].s3Key;
                    let compressedImages = data.Items[i].imagesData;
                    let compressedImagesNew = data.Items[i].imagesPath;
                    let imagesPath = s3Keys;
                    let bucket = config.aws.s3.params.Bucket;
                    let path;
                    if (!s3Keys && compressedImages && !compressedImagesNew) {
                        bucket = config.aws.s3.params.Data_Bucket;
                        imagesPath = compressedImages.Medium;
                        let folder = "partsdata_Medium";
                        path = folder + "/" + data.Items[i].id + "/" + imagesPath[0];
                    }
                    else if (s3Keys && !compressedImagesNew)
                        path = imagesPath[0];
                    else if (compressedImagesNew) {
                        bucket = config.aws.s3.params.Data_Bucket;
                        let folder = "partsdata_Medium";
                        path = folder + "/" + data.Items[i].id + "/" + compressedImagesNew[0];
                    }

                    if (imagesPath instanceof Array)
                        data.Items[i].signedUrls = AwsS3Svc.getSignedUrlForFile(path, bucket);
                    else
                        data.Items[i].signedUrls = AwsS3Svc.getSignedUrlForFile(path, bucket);
                    if (i === data.Items.length - 1) {
                        resolve(data);
                    }
                }
                getSignedUrl.then(() => {
                    res.status(200).send(data);
                })
            })
        }
        catch (ex) {
            res.status(500).send({ 'error': ex })
        }
    })

    router.post('/searchpart', utils.verificationByToken, async (req, res) => {
        try {
            let params = {
                TableName: config.aws.dynamodb.tableInfo.PartDatabase,
                ProjectionExpression: "category, #partnameKey, #name, material, s3Key, #id, organization, complexity, imagesData, imagesPath",
                IndexName: "organization-index",
                KeyConditionExpression: "#organization=:organizationValue",
                FilterExpression: "contains (#partnameKey,:partnameValue)",
                ExpressionAttributeNames: {
                    '#partnameKey': 'searchname',
                    '#id': 'id',
                    '#name': 'name',
                    '#organization': 'organization'
                },
                ExpressionAttributeValues: {
                    ":partnameValue": req.body.name,
                    ':organizationValue': req.body.organization,
                }
            }
            let data = await AwsDynamoDb.queryItem(params);
            for (let i = 0; i < data.Items.length; i++) {
                let s3Keys = data.Items[i].s3Key;
                let compressedImages = data.Items[i].imagesData;
                let compressedImagesNew = data.Items[i].imagesPath;
                let imagesPath = s3Keys;
                let bucket = config.aws.s3.params.Bucket;
                let path;
                if (compressedImages && !compressedImagesNew) {
                    let folder = "partsdata_Medium";
                    bucket = config.aws.s3.params.Data_Bucket;
                    if (req.body.imageType && req.body.imageType === "Thumbnail") {
                        imagesPath = compressedImages.Thumbnail;
                        folder = "partsdata_Thumbnail";
                    }
                    else if (req.body.imageType && req.body.imageType === "Original") {
                        imagesPath = compressedImages.Original;
                        folder = "partsdata";
                    }
                    else {
                        imagesPath = compressedImages.Medium;
                        folder = "partsdata_Medium";
                    }
                    path = folder + "/" + data.Items[i].id + "/" + imagesPath[0];
                }
                else if (s3Keys && !compressedImagesNew) {
                    path = imagesPath[0];
                }
                else if (compressedImagesNew) {
                    bucket = config.aws.s3.params.Data_Bucket;
                    let folder = "partsdata_Medium";
                    if (req.body.imageType && req.body.imageType === "Thumbnail")
                        folder = "partsdata_Thumbnail";
                    else if (req.body.imageType && req.body.imageType === "Original")
                        folder = "partsdata";

                    path = folder + "/" + data.Items[i].id + "/" + compressedImagesNew[0];
                }

                if (imagesPath instanceof Array)
                    data.Items[i].signedUrls = await AwsS3Svc.getSignedUrlForFile(path, bucket);
                else
                    data.Items[i].signedUrls = await AwsS3Svc.getSignedUrlForFile(path, bucket);

                if (i === data.Items.length - 1) {
                    res.status(200).send(data.Items)
                    return;
                }
            }
            res.status(400).send({ 'message': "Items not found" });
        } catch (error) {
            // console.log(error);
            res.status(400).send({ 'error': error });
        }
    })

    router.post('/searchexactpart', utils.verificationByToken, async (req, res) => {
        try {
            let params = {
                TableName: config.aws.dynamodb.tableInfo.PartDatabase,
                IndexName: "organization-index",
                KeyConditionExpression: "#organization = :organizationValue",
                FilterExpression: "#partnameKey = :partnameValue",
                ExpressionAttributeNames: {
                    '#partnameKey': 'searchname',
                    '#organization': 'organization'
                },
                ExpressionAttributeValues: {
                    ':partnameValue': req.body.name,
                    ':organizationValue': req.body.organization,
                }
            }

            let data = await AwsDynamoDb.queryItem(params);
            res.status(200).send(data);
        } catch (error) {
            res.status(400).send({ 'error': error });
        }
    })

    return router;

}