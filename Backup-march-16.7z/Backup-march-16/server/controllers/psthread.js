const { workerData, parentPort } = require('worker_threads')
var config = require("c0nfig");
var AWS = require("aws-sdk");
AWS.config.update(config.aws.dynamodb.credentials);
let docClient = new AWS.DynamoDB.DocumentClient();

console.log(workerData);
    let counter = 0;
    let isLast = false;
    let prev;
    let cure;


    var xTop1 = 0;
    var xTop2 = 0;
    var xTop3 = 0;
    
    //First Time
    (async () => {
        const resultFT = await partCountParser(0,workerData);
        counter = counter + Number(resultFT.ScannedCount);
       //if Last Evaluated Key Presnted 
        cure = resultFT;
        if(resultFT.LastEvaluatedKey)
        {
          isLast = true;
          while(isLast)
          { 
            prev = cure;
          for(var i=0;i<prev.Count;i++)
          {
            if(prev.Items[i].printabilityScore >= 61){
              xTop1 ++;
            }
            if(prev.Items[i].printabilityScore >= 41 && prev.Items[i].printabilityScore <= 60 ){
              xTop2 ++;
            }
            if(prev.Items[i].printabilityScore < 41){
              xTop3 ++;
            }
            
          }
            
            const result = await partCountParser(prev.LastEvaluatedKey.id,workerData);

            
            if(result.LastEvaluatedKey)
            {
                counter = counter + Number(result.ScannedCount);
            }
            else
            {
              for(var i=0;i<result.Count;i++)
              {
                if(result.Items[i].printabilityScore >= 61){
                  xTop1 ++;
                }
                if(result.Items[i].printabilityScore >= 41 && result.Items[i].printabilityScore <= 60 ){
                  xTop2 ++;
                }
                if(result.Items[i].printabilityScore < 41){
                  xTop3 ++;
                }
                
              }
              counter = counter + Number(result.ScannedCount);
              isLast = false;
            }
            cure = result;
           
           
          }
        }
        else
        {
        }

        //Update Item
        var params1 = {
          TableName:"parts_count",
          Key:{

              "id": "Top1",
          },
          UpdateExpression: "set counts = :r",
          ExpressionAttributeValues:{
              ":r":xTop1,
          },
        };
        docClient.update(params1, function (err, datax) {
          if (err) {
              console.error("Unable to query PS1. Error:", JSON.stringify(err, null, 2));
          } else {}                             
        })


        var params2 = {
          TableName:"parts_count",
          Key:{

              "id": "Top2",
          },
          UpdateExpression: "set counts = :r",
          ExpressionAttributeValues:{
              ":r":xTop2,
          },
        };
        docClient.update(params2, function (err, datax) {
          if (err) {
              console.error("Unable to query PS2. Error:", JSON.stringify(err, null, 2));
          } else {}                             
        })


        var params3 = {
          TableName:"parts_count",
          Key:{

              "id": "Top3",
          },
          UpdateExpression: "set counts = :r",
          ExpressionAttributeValues:{
              ":r":xTop3,
          },
        };
        docClient.update(params3, function (err, datax) {
          if (err) {
              console.error("Unable to query PS3. Error:", JSON.stringify(err, null, 2));
          } else {}                             
        })


      })().catch(e => console.log("Got " + e));
    
  
 




   

//Parser 
function  partCountParser(leid,orga) {
   return new Promise(resolve => {
      let params = {
        TableName: "Parts-Production",
      };

      if(leid == 0)
      {
      }
      else
      {
        params.ExclusiveStartKey = {
          id: leid
        };
      }
      docClient.scan(params, function(err, data) {
        if (err) {
            console.error("Unable to query PS. Error:", JSON.stringify(err, null, 2));
        } else {
            resolve(data);
        }
    });
  });
  }