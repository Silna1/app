var express = require('express');
var ServiceManager = require('../services/SvcManager');
var config = require('c0nfig')
var utils = require('../helpers/utils');
var _ = require('lodash');

let AwsCognitoSvc = ServiceManager.getService('AwsCognitoSvc');
let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');


module.exports = function () {
    var router = express.Router();
    /*****************************************Cognito API's***************************************** */
    //get all the users
    router.post('/getUsers', utils.verificationByToken, (req, res) => {

        var listUserParams = {
            GroupName: req.body.organization,
            UserPoolId: req.body.userPoolId,
        };

        AwsCognitoSvc.listUser(listUserParams)
            .then(async (userDataList) => {
                let list = await utils.getUserList(userDataList, listUserParams.UserPoolId);
                list = _.uniqBy(list, 'email');
                res.status(200).send(list);
            })
            .catch(err => {
                // console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
                res.status(400).send({ message: "Unable to scan the table" });
            })

    })

    router.post('/updateUser', utils.verificationByToken, async (req, res) => {
        try {
            var listUserParams = {
                GroupName: req.body.privilege,
                UserPoolId: req.body.userPoolId,
                Username: req.body.username
            };

            var userAttributeParams = {
                UserAttributes: [
                    {
                        Name: 'name',
                        Value: req.body.name
                    },
                ],
                UserPoolId: req.body.userPoolId,
                Username: req.body.username
            };
            if (req.body.privilege) {
                await AwsCognitoSvc.updateUser(listUserParams);
                listUserParams.GroupName = req.body.privilegeToChange;
                await AwsCognitoSvc.removePrivilege(listUserParams);
            }
            await AwsCognitoSvc.updateUserAttributes(userAttributeParams);
            res.status(200).send({ "message": "user updated" });
        } catch (error) {
            res.status(400).send({ 'error': error });
        }
    })

    router.post('/createUser', utils.verificationByToken, (req, res) => {
        try {
            var params = {
                UserPoolId: req.body.userPoolId,
                Username: req.body.email,
                DesiredDeliveryMediums: ['EMAIL'],
                TemporaryPassword: utils.createUniquePassword(),
                ForceAliasCreation: true,
                UserAttributes: [
                    {
                        Name: 'email',
                        Value: req.body.email
                    },
                    {
                        Name: 'name',
                        Value: req.body.name
                    },
                    {
                        Name: 'email_verified',
                        Value: 'true'
                    }
                ],
            };

            AwsCognitoSvc.createUser(params)
                .then(async (data) => {
                    var userParams = {
                        GroupName: req.body.organization,
                        UserPoolId: req.body.userPoolId,
                        Username: data.User.Username
                    };
                    let arr = [req.body.organization, req.body.privilege];
                    for (const groupName in arr) {
                        userParams.GroupName = arr[groupName];
                        await AwsCognitoSvc.updateUser(userParams);
                    }
                    let userData = {
                        "email": req.body.email,
                        "privilege": req.body.privilege,
                        'username': data.User.Username,
                        'name': req.body.name
                    }
                    res.status(200).send(userData);
                })
                .catch(err => {
                    // console.error("Unable to create the user. Error JSON:", JSON.stringify(err, null, 2));
                    res.status(400).send({ message: err.message });
                })
        } catch (error) {
            res.status(400).send({ message: "Unable to create the user" });

        }
    });

    router.post('/createGroup', utils.verificationByToken, (req, res) => {
        try {
            var params = {
                GroupName: req.body.groupName,
                UserPoolId: req.body.userPoolId,
                Description: req.body.description
                
            };

            AwsCognitoSvc.createGroup(params)
                .then(async (data) => {
                    
                    let groupData = {
                        "groupName": req.body.groupName
                    }
                    res.status(200).send(groupData);
                })
                .catch(err => {
                    // console.error("Unable to create the group. Error JSON:", JSON.stringify(err, null, 2));
                    res.status(400).send({ message: err.message });
                })
        } catch (error) {
            res.status(400).send({ message: "Unable to create the group" });

        }
    });

    router.post('/deleteUser', utils.verificationByToken, (req, res) => {
        var params = {
            UserPoolId: req.body.userPoolId,
            Username: req.body.username
        };

        AwsCognitoSvc.deleteUser(params)
            .then(async (data) => {
                res.status(200).send({ "message": 'User deleted' });
            })
            .catch(err => {
                // console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
                res.status(400).send({ message: "Unable to delete the user" });
            })

    });

    router.post('/getClients', utils.verificationByToken, (req, res) => {
        var params = {
            UserPoolId: req.body.userPoolId,
        };

        AwsCognitoSvc.getClients(params)
            .then(data => {
                if (data.Groups === undefined)
                    res.status(400).send({ message: "Unable to get the client" });

                let list = [];
                for (const group in data.Groups) {
                    if (!utils.PrivilegeList.includes(data.Groups[group].GroupName))
                        list.push(data.Groups[group].GroupName);
                }
                res.status(200).send({ List: list });
            })
            .catch(err => {
                // console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
                res.status(400).send({ message: err });
            })

    });
    /********************************************************************************** */
    //get one user -- it is post as we need to send an email address (can send it as params).
    router.post('/userbyemail', utils.verificationByToken, (req, res) => {

        let email = req.body.email

        let quaryParams = {
            TableName: config.aws.dynamodb.tableInfo.UserDataBase,
            KeyConditionExpression: "#emailAttr = :emailValue",
            ExpressionAttributeNames: {
                "#emailAttr": "email"
            },
            ExpressionAttributeValues: {
                ":emailValue": email
            }
        };

        AwsDynamoDb.queryItem(quaryParams)
            .then((data) => {
                res.status(200).send(data);
            }).catch((err) => {
                res.status(500).send(err)
            })
    })

    //update user
    router.post('/update', utils.verificationByToken, (req, res) => {
        let params = {
            TableName: config.aws.dynamodb.tableInfo.UserDataBase,
            Item: req.body
        }

        AwsDynamoDb.putItem(params)
            .then((data) => {
                res.status(200).send({ "message": "User is updated successfully" });
            }).catch((err) => {
                res.status(500).send(err);
            })
    })

    //delete user
    router.post('/delete', utils.verificationByToken, (req, res) => {
        try {
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');

            let params = {
                TableName: config.aws.dynamodb.tableInfo.UserDataBase,
                Key: {
                    email: req.body.email
                }
            }
            AwsDynamoDb.deleteItem(params)
                .then((data) => {
                    res.status(200).send({ "message": "Delete request for user is executed successfully" });
                }).catch((err) => {
                    res.status(400).send(err)
                })
        }
        catch (err) {
            res.status(500).send(err);
        }

    })

    //for user privilege setting with respect to his role.
    router.post('/privilege', (req, res) => {
        let role = req.body.role;

        let quaryParams = {
            TableName: "Privileges",
            KeyConditionExpression: "#roleAttr = :roleValue",
            ExpressionAttributeNames: {
                "#roleAttr": "role"
            },
            ExpressionAttributeValues: {
                ":roleValue": role
            }
        };

        AwsDynamoDb.queryItem(quaryParams)
            .then((data) => {
                res.status(200).send(data);
            }).catch((err) => {
                res.status(500).send(err)
            })

    })

    router.get('/createCustomverificationTemplate', async (req, res) => {
        try {
            var params = config.aws.ses.emailVerificationTemplateParams;
            params.TemplateSubject = 'Email Verification for Part Digitizer account', /* required */
                params.TemplateContent = `<html>
                    <body>
                        <b>Click on the following link to verify your email</b>
                    <body>
                </html>`

            let AwsEmailSvc = ServiceManager.getService('AwsEmailSvc');
            AwsEmailSvc.createCustomverificationTemplate(params)
                .then((data) => {
                    res.status(200).send({ data: data })
                })
                .catch(err => {
                    res.status(400).send({ error: err })
                })

        } catch (err) {
            // console.log("error", err);
        }
    });

    router.get('/sendVerificationEmail', async (req, res) => {
        try {
            let emailParam = {
                EmailAddress: 'developer@immensalabs.com', /* required */
                TemplateName: config.aws.ses.emailVerificationTemplateParams.TemplateName, /* required */
            }
            let AwsEmailSvc = ServiceManager.getService('AwsEmailSvc');
            AwsEmailSvc.sendVerificationEmail(emailParam)
                .then((data) => {
                    res.status(200).send({ data: data })
                })
                .catch(err => {
                    res.status(400).send({ error: err })
                })

        } catch (err) {
            // console.log("error", err);
        }
    });

    return router

}