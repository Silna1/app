var express = require('express');
var ServiceManager = require('../services/SvcManager');
const uuid = require('uuid/v4');
var config = require('c0nfig')
var dynamodbUpdateExpression = require('dynamodb-update-expression');
var utils = require('../helpers/utils');

module.exports = function () {
    var router = express.Router();

    let AwsDynamodb = ServiceManager.getService('AwsDynamoSvc')

    router.post('/add', utils.verificationByToken, (req, res) => {

        try {
            // console.log("inside printer add");
            const data = req.body.printer;
            let printerData = {
                id: uuid(),
                name: data.name,
                manufacturer: data.manufacturer,
                model: data.model,
                size: {
                    length: data.size.length,
                    breadth: data.size.breadth,
                    height: data.size.height
                },
                material: data.material
            }

            let params = {
                TableName: config.aws.dynamodb.tableInfo.PrinterDatabase,
                Item: printerData,
            }
        
            //insert data to table
            AwsDynamodb.putItem(params)
                .then((data) => {
                    res.status(200).send({ 'printer': params.Item });
                })
                .catch((err) => {
                    res.status(400).send(err)
                });
        }
        catch (err) {
            res.status(500).send(err);
        }

    })

    router.get('/all', utils.verificationByToken, async (req, res) => {
        try {
            // console.trace();
            // console.log("inside printer all");
            let params = {
                TableName: config.aws.dynamodb.tableInfo.PrinterDatabase
            }

            let data = await AwsDynamodb.scanItem(params);
            // console.log("silna",data);
            res.status(200).send(data);
        }
        catch (err) {
            res.status(400).send({ 'error': err });
        }
    })

    router.delete('/delete', utils.verificationByToken, (req, res) => {
        try {
            // console.log("inside printer delete");
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');

            let params = {
                TableName: config.aws.dynamodb.tableInfo.PrinterDatabase,
                Key: {
                    id: req.body.id
                }
            }
            AwsDynamoDb.deleteItem(params)
                .then((data) => {
                    res.status(200).send({ "message": "Delete request for printer is executed successfully" });
                }).catch((err) => {
                    res.status(400).send(err)
                })
        }
        catch (err) {
            res.status(500).send(err);
        }

    })

    router.put('/update', utils.verificationByToken, async (req, res) => {
        try {
            // console.log("inside printer update");
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
            let params = {
                TableName: config.aws.dynamodb.tableInfo.PrinterDatabase,
                KeyConditionExpression: "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "id"
                },
                ExpressionAttributeValues: {
                    ":value": req.body.printer.id
                }
            }

            const updateParams = req.body.printer;
            // console.log("updateparams printer ",updateParams);
            let data = await AwsDynamoDb.queryItem(params);
            // console.log("date printer inside update",data);
            if (data.Count !== 0) {
                const queryData = data.Items[0];
                let updateExpression = dynamodbUpdateExpression.getUpdateExpression(queryData, updateParams);
                updateExpression.Key = {
                    id: req.body.printer.id
                }
                updateExpression.TableName = config.aws.dynamodb.tableInfo.PrinterDatabase
                await AwsDynamoDb.updateItem(updateExpression);
                res.status(200).send({ "message": "Printer data is updated successfully" });
            }
            else {
                res.status(400).send({ "message": "Please provide the required information" });
            }
        } catch (err) {
            res.status(400).send(err);
        }
    })

    return router;
}