/* eslint-disable no-loop-func */
var express = require("express");
var ServiceManager = require("../services/SvcManager");
const uuid = require("uuid/v4");
var config = require("c0nfig");
var dynamodbUpdateExpression = require("dynamodb-update-expression");
var utils = require("../helpers/utils");
var partsUtils = require("./../helpers/partUtils");
var forgeUtils = require("./../helpers/ForgeViewerUtils");
var xlsx = require("xlsx");
var AdmZip = require("adm-zip");
var path = require("path");
var fs = require("fs-extra");
var Jimp = require("jimp");
var request = require("request");
var os = require("os");
var _ = require("lodash");
var crypto = require("crypto");
const { exit } = require("process");
const { Console } = require("console");
const { Worker } = require('worker_threads')

module.exports = function () {
  var router = express.Router();

  //below api is used to upload the part data also it is used for updating the data.
  // adding parts
  router.post("/uploadpartdata",utils.verificationByToken,async (request, response) => {
   
      try {
        let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
        let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
        let parsedFormData = null;
        let filesPathObj = [];
        let uid;
        let tranlatedFileUrn;
        parsedFormData = await partsUtils.uploadFileParamsPromise(request);
        filesPathObj = await partsUtils.getUploadFilesArray(
          parsedFormData.files
        );
        //upload file to S3, need to implement logic for multiple file upload
        let projectNames = await partsUtils.getProjectNameList(
          parsedFormData.fields.organization
        );
        let entryData = partsUtils.validateEntries(
          parsedFormData.fields,
          projectNames
        );
        if (!entryData.status) {
          console.log(parsedFormData.fields.name + " : " + entryData.message);
          response.status(400).send({ message: entryData.message });
          return;
        }

        uid = parsedFormData.uid;
        let imagesData = await partsUtils.uploadImages(filesPathObj, uid);

        let filesPath;
        if (filesPathObj["ViewerFile"].length > 0) {
          // uploading and translating the file
          tranlatedFileUrn = await forgeUtils.uploadAndTranslateFile(
            parsedFormData.files.viewerFile.name,
            filesPathObj["ViewerFile"][0]
          );
          // uploading file to s3 bucket
          filesPath = await forgeUtils.uploadViewerFileToS3(
            filesPathObj["ViewerFile"],
            uid
          );
        }
       
        //console.log("New part added " + uid);
        //upload form data to dynamodb
        //TO DO partsData object needs to be changed, need to put validations on it.

        let partsData = {
          id: parsedFormData.uid,
          name: parsedFormData.fields.name,
          searchname: parsedFormData.fields.name.toLowerCase(),
          number: parsedFormData.fields.number,
          description: parsedFormData.fields.description,
          size: {
            length: parsedFormData.fields.length,
            breadth: parsedFormData.fields.breadth,
            height: parsedFormData.fields.height,
          },
          material: parsedFormData.fields.material,
          complexity: parsedFormData.fields.complexity,
          category: parsedFormData.fields.category,
          subcategory: parsedFormData.fields.subcategory,
          notes: parsedFormData.fields.notes,
          timeStamp: new Date().toISOString(),
          user: parsedFormData.fields.email,
          sellingPrice: parsedFormData.fields.sellingPrice,
          costPrice: parsedFormData.fields.costPrice,
        };

        if (parsedFormData.fields && parsedFormData.fields.organization)
          partsData.organization = parsedFormData.fields.organization;

        if (filesPath && filesPath.key) partsData.filesPath = filesPath.key;

        if (tranlatedFileUrn) partsData.urn = tranlatedFileUrn;

        if (parsedFormData.fields.location)
          partsData.location = JSON.parse(parsedFormData.fields.location);

        //createdBy
        if (
          parsedFormData.fields.createdBy !== undefined &&
          parsedFormData.fields.createdBy !== null
        ) {
          partsData.createdBy = parsedFormData.fields.createdBy;
        }

        //updatedBy
        if (
          parsedFormData.fields.updatedBy !== undefined &&
          parsedFormData.fields.updatedBy !== null
        ) {
          partsData.updatedBy = parsedFormData.fields.updatedBy;
        }

        //This is for new compressed images
        if (imagesData !== undefined && imagesData !== []) {
          partsData.imagesPath = imagesData;
        }

        let params = {
          TableName: config.aws.dynamodb.tableInfo.PartDatabase,
          Item: partsData,
          ReturnConsumedCapacity: "TOTAL",
          ReturnValues: "ALL_OLD",
        };

        let score = await partsUtils.getPrintabilityScore(partsData);
        if (score) partsData.printabilityScore = score;

        await AwsDynamoDb.putItem(params);


        let queryParams = {
          TableName: config.aws.dynamodb.tableInfo.PartDatabase,
          KeyConditionExpression: "#id = :value",
          ExpressionAttributeNames: {
            "#id": "id",
          },
          ExpressionAttributeValues: {
            ":value": parsedFormData.uid,
          },
        };

        let resp = await AwsDynamoDb.queryItem(queryParams);

        if (resp.Count !== 0) {
          let tempSignedUrl = AwsS3Svc.getSignedUrlForFile(
            resp.Items[0].imagesPath[0]
          );
          resp.Items[0].signedUrls = tempSignedUrl;
          console.log("part added into database : " + resp.Items[0].name);
          response.status(200).send("resp");
        } else {
          Promise.reject({
           
            message: "Requested Item is not present in database"
         });
        }
      } catch (ex) {
        response.status(400).send({ error: ex });
      }
    }
  );

  router.get(
    "/getMaterialsData",
    utils.verificationByToken,
    async (req, res) => {
      try {
        let materialsData = await partsUtils.Materials;
        res.status(200).send({ materials: materialsData });
      } catch (err) {
        res
          .status(400)
          .send({ materials: [], message: "material fetch failed" });
      }
    }
  );

  router.post(
    "/uploadForAutoml",
    utils.verificationByToken,
    async (req, res) => {
      let obj = { data: {} };

      obj.data = await getDataForAutoml();

      if (req.body.datasetId) {
        obj.data["datasetId"] = req.body.datasetId;
      }
      if (req.body.modelId) {
        obj.data["modelId"] = req.body.modelId;
        obj.data["modelTrainingTimestamp"] = new Date().toUTCString();
      }
      console.log(obj);
      let json = JSON.stringify(obj); //convert it back to json

      fs.writeFile("automlInfo.json", json, "utf8", function (err) {
        if (err) {
          console.log(err);
        }
        console.log("Saved!");
      });

      let uploadFileParams = {
        content: "./automlInfo.json",
        name: "automlInfo",
        projectName: "automldata",
      };

      let AwsS3Svc = ServiceManager.getService("AwsS3Svc");

      AwsS3Svc.uploadFile(uploadFileParams)
        .then((data) => {
          console.log("success");
          res.send({ status: "success" });
        })
        .catch((err) => {
          res.send({ status: "fail" });
        });
    }
  );

  router.post("/downloadForAutoml", async (req, res) => {
    let data = await getDataForAutoml();
    res.send(data);
  });
  
    //get Comments for this Part
    router.post('/getComments', async (req, res) => {
      try {
        let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');

        let params = {
            TableName: config.aws.dynamodb.tableInfo.CommentsDatabase,
            FilterExpression: "#id = :value",
            ExpressionAttributeNames: {
                "#id": "PartID"
            },
            ExpressionAttributeValues: {
                ":value": req.body.id
            },

        }
        AwsDynamoDb.scanItemCats(params, (err, data) => {
            if (err) {
                console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
                res.status(400).send(err);
            }
            else {
             
                res.status(200).send(data);
          
            }
        })
    }
    catch (ex) {
        res.status(500).send(ex);
    }
  })

   //Set Comment
   let AwsDynamodb = ServiceManager.getService('AwsDynamoSvc')
   router.post('/setComment',(req, res) => {
     

         console.log("new Comment Added....");
        
     try {
       const data = req.body;
       let date_ob = new Date();
       let date = ("0" + date_ob.getDate()).slice(-2);
       let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
       let year = date_ob.getFullYear();
       let hours = date_ob.getHours();
       let minutes = date_ob.getMinutes();
       let seconds = date_ob.getSeconds();
       const cTime = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":00";
       let CommentData = {
           CommentID: uuid(),
           PartID: data.PartID,
           AddDate: cTime,
           CommentText: data.UserComment,
           UserID: data.UserID
       }
     

       let params = {
           TableName: config.aws.dynamodb.tableInfo.CommentsDatabase,
           Item: CommentData,
       }

       console.log(params.Item);

       AwsDynamodb.putItem(params)
           .then((data) => {
              console.log(data);
           })
           .catch((err) => {
             console.log(err);
           });
   }
   catch (err) {
     console.log(err);
       res.status(500).send(err);
   }
 })
//////////////////
  function getDataForAutoml() {
    try {
      return new Promise((resolve, reject) => {
        let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
        let jsonPath = AwsS3Svc.getSignedUrlForFile("automldata/automlInfo");
        console.log(jsonPath);

        request.get(jsonPath, function (error, response, body) {
          if (!error && response.statusCode === 200) {
            resolve(JSON.parse(body).data);
          }
        });
      });
    } catch (err) {
      console.log(err);
    }
  }
  
  // Remove Dublicate Function
  function removeDuplicate(array, key) {
    let check = {};
    let res = [];
    for(let i=0; i<array.length; i++) {
        if(!check[array[i][key]]){
            check[array[i][key]] = true;
            res.push(array[i]);
        }
    }
    return res;
}
//Get Catrgories
router.post('/getcats', async (req, res) => {
  console.log("Pass to Server");
  try
  {
      let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
      let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');

      let params = {
          TableName: config.aws.dynamodb.tableInfo.PartDatabase,
          ProjectionExpression: "#id",
          ExpressionAttributeNames: {"#id": "subcategory"},


      }
      AwsDynamoDb.scanItemCats(params, (err, data) => {
          if (err) {
              console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
              res.status(400).send(err);
          }
          else {
              if (data.Count !== 0) {
                  const catArray = removeDuplicate(data.Items,"subcategory");
                  res.status(200).send(catArray);

              }
              else
              {
                  
              }
          }
      })
  }
  catch (ex) {
      res.status(500).send(ex);
  }
})
  //Get All Catrgories
router.post('/getallcats', async (req, res) => {
  console.log("Pass to Server to Get all Data from Cats");
  try
  {
      let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
      let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');

      let params = {
          TableName: config.aws.dynamodb.tableInfo.PartDatabase,
          ProjectionExpression: "#id",
          ExpressionAttributeNames: {"#id": "category"},


      }
      AwsDynamoDb.scanItemCats(params, (err, data) => {
          if (err) {
              console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
              res.status(400).send(err);
          }
          else {
              if (data.Count !== 0) {
                  res.status(200).send(data);
              }
              else
              {
                  
              }
          }
      })
  }
  catch (ex) {
      res.status(500).send(ex);
  }
})


//////////////////////////////////////////
//My play ground
router.get("/move2db", async (req, res) => {
  console.log("Moving Start...");
  let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
  let params = {
    TableName: config.aws.dynamodb.tableInfo.PartDatabase,
    //FilterExpression: "#organizationName = :organizationValue",
    IndexName: 'category-index',
    KeyConditionExpression: "#organizationName = :organizationValue",
    ExpressionAttributeNames: {"#organizationName": "category"},
    ExpressionAttributeValues: {":organizationValue": "Pump"},
    Limit: 2000,
  };
  let data = await AwsDynamoDb.queryItem(params);
 
 

  //set Immensa_Database_2
  try {

for(var i=0;i<=data.Count - 1;i++)
{
    let params = {
        TableName: config.aws.dynamodb.tableInfo.ImmensaDB2,
        Item: data.Items[i],
    }
    AwsDynamodb.putItem(params)
        .then((data) => {
           console.log(data);
        })
        .catch((err) => {
          console.log(err);
        });

      }
}
catch (err) {
  console.log(err);
    res.status(500).send(err);
}
res.status(200).send("Done");

 });
 //
 router.post("/materialsparts", async (req, res) => {
  try
  {
    let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
    let params = {TableName: config.aws.dynamodb.tableInfo.MaterialsTable}
    AwsDynamoDb.scanItemCats(params, (err, data) => {
      if (err) {
          console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
          res.status(400).send(err);
      }else {
        
        var numdata = [];
        var textdata = [];
        for(var i=0;i<data.Count;i++)
        {
          if(data.Items[i].counterr > 0)
          {
            numdata.push(Number(data.Items[i].counterr));
            textdata.push(data.Items[i].id);
          }
        }
        var resultx = [];
        resultx.push({"data":numdata,"backgroundColor":"DodgerBlue","names":textdata,"lbl":"Materials"});
        res.status(200).send(resultx);
      }
    });

  }catch (ex) {
    res.status(500).send(ex);
}
});


 //
 router.post("/gettop9cats", async (req, res) => {
  try
  {
      let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
      let params = {
          TableName: config.aws.dynamodb.tableInfo.Top9Cats,
      }
      AwsDynamoDb.scanItemCats(params, (err, data) => {
          if (err) {
              console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
              res.status(400).send(err);
          }
          else {
              if (data.Count !== 0) {
                var resultx = [];
              for(var x = 1;x<=10;x++)
              {
                var datax = [];
                var colorx = ['Tomato',"Orange",'MediumSeaGreen','DodgerBlue','SlateBlue','MediumSeaGreen','Violet','Gray','cyan','skyblue','red','purple'];
                var namesx = [];
                var categoryx = "";
              for(var i=0;i<data.Count;i++)
              {
                if(data.Items[i].pk == x)
                {
                datax.push(data.Items[i].counter);
                namesx.push(data.Items[i].name);
                categoryx = data.Items[i].category;
                }
              }
              if(datax.length > 0)
              {
                resultx.push({"data":datax,"backgroundColor":colorx,"names":namesx,"follow":categoryx});
              }
                
              }

                  res.status(200).send(resultx);
              }
              else
              {
                  
              }
          }
      })
  }
  catch (ex) {
      res.status(500).send(ex);
  }
 });


 //Run PS Thread
 router.post("/playps", async (req, res) => {
  console.log("in PS Ground ...");

  //
  const runService = (workerData) => {
    return new Promise((resolve, reject) => {
      const worker = new Worker('./controllers/psthread.js', { workerData });
      worker.on('message', resolve);
      worker.on('error', reject);
      worker.on('exit', (code) => {
        if (code !== 0)
          reject(new Error(`Worker stopped with exit code ${code}`));
      })
    })
  }
  
  const run = async () => { const result = await runService("PS")}
    run().catch(err => console.error(err))
    res.status(200).send("Done PS");
  }); 



 //
 router.post("/play", async (req, res) => {
  console.log("in Play Ground ...",req.body.orga);

  //
  const runService = (workerData) => {
    return new Promise((resolve, reject) => {
      const worker = new Worker('./controllers/thread.js', { workerData });
      worker.on('message', resolve);
      worker.on('error', reject);
      worker.on('exit', (code) => {
        if (code !== 0)
          reject(new Error(`Worker stopped with exit code ${code}`));
      })
    })
  }
  
  const run = async () => {
      const result = await runService(req.body.orga)
  
    }
    
    run().catch(err => console.error(err))

  //
  let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
  let params = {
    TableName: config.aws.dynamodb.tableInfo.PartsCount,
    //FilterExpression: "#organizationName = :organizationValue",
    //IndexName: 'organization-index',
    KeyConditionExpression: "#organizationName = :organizationValue",
    ExpressionAttributeNames: {"#organizationName": "id"},
    ExpressionAttributeValues: {":organizationValue": "ImmensaLab"},
    Limit: 2000,
  };
  let data = await AwsDynamoDb.queryItem(params);
  console.log(data);
  res.status(200).send("Done");
  });
 

  //Get All Catrgories
  router.post('/getPartsCat', async (req, res) => {
    console.log("Pass to Server to Get Graph");
    try
    {
        let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
        let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
  
        let params = {
            TableName: config.aws.dynamodb.tableInfo.GraphTable,
       
  
  
        }
        AwsDynamoDb.scanItemCats(params, (err, data) => {
            if (err) {
                console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
                res.status(400).send(err);
            }
            else {
                if (data.Count !== 0) {
                  console.log(data);
                    res.status(200).send(data);
                }
                else
                {
                    
                }
            }
        })
    }
    catch (ex) {
        res.status(500).send(ex);
    }
  })
 //////////////////////////////////////////
 router.post("/getPartsCatx", async (req, res) => {
  //req.body.organization = "ImmensaLab"

  /*let counter = [];
    let isLast = false;
    let prev;
    let cure;

    const resultFT = await partCountParser2(0,req.body.organization);
    counter.push(resultFT);
    cure = resultFT;
    if(resultFT.LastEvaluatedKey)
    {
      isLast = true;
      while(isLast)
      { 
        prev = cure;
        const result = await partCountParser2(prev.LastEvaluatedKey.id,req.body.organization);
        if(result.LastEvaluatedKey)
        {
          counter.push(result);
        }
        else
        {
          counter.push(result);
          isLast = false;

        }
        cure = result;
      }
      
    }
    else
    {
      //Console.log("Less than 1000 / " ,counter);
    }
    //console.log("# of Blocks ",counter.length);
    */
   /*let counter = []*/
   let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
   let params = {TableName: config.aws.dynamodb.tableInfo.GraphTable,};
     //FilterExpression: "#organizationName = :organizationValue",
     //IndexName: 'category-index',
     //KeyConditionExpression: "#organizationName = :organizationValue",
     //ExpressionAttributeNames: {"#organizationName": "category"},
     //ExpressionAttributeValues: {":organizationValue": "Cap"},
     //Limit: 2000,
   //};
   /*
   let data1 = await AwsDynamoDb.queryItem(params);
   console.log(data1);*/

  
  
  AwsDynamoDb.scanItemCats(params, (err, data) => {
     if (err) {
         console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
         //res.status(400).send(err);
     }
     else {
      
      res.status(200).send({data});
     }
 })

   //
   /* params = {
     TableName: config.aws.dynamodb.tableInfo.PartDatabase,
     //FilterExpression: "#organizationName = :organizationValue",
     IndexName: 'category-index',
     KeyConditionExpression: "#organizationName = :organizationValue",
     ExpressionAttributeNames: {"#organizationName": "category"},
     ExpressionAttributeValues: {":organizationValue": "Cap"},
     Limit: 2000,
   };
   let data2 = await AwsDynamoDb.queryItem(params);
   
    params = {
      TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      //FilterExpression: "#organizationName = :organizationValue",
      IndexName: 'category-index',
      KeyConditionExpression: "#organizationName = :organizationValue",
      ExpressionAttributeNames: {"#organizationName": "category"},
      ExpressionAttributeValues: {":organizationValue": "Bracket"},
      Limit: 1000,
    };
    let data3 = await AwsDynamoDb.queryItem(params);

    params = {
      TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      //FilterExpression: "#organizationName = :organizationValue",
      IndexName: 'category-index',
      KeyConditionExpression: "#organizationName = :organizationValue",
      ExpressionAttributeNames: {"#organizationName": "category"},
      ExpressionAttributeValues: {":organizationValue": "Internal gear"},
      Limit: 1000,
    };
    let data4 = await AwsDynamoDb.queryItem(params);

    params = {
      TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      //FilterExpression: "#organizationName = :organizationValue",
      IndexName: 'category-index',
      KeyConditionExpression: "#organizationName = :organizationValue",
      ExpressionAttributeNames: {"#organizationName": "category"},
      ExpressionAttributeValues: {":organizationValue": "heat exchangers"},
      Limit: 1000,
    };
    let data5 = await AwsDynamoDb.queryItem(params);


    params = {
      TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      //FilterExpression: "#organizationName = :organizationValue",
      IndexName: 'category-index',
      KeyConditionExpression: "#organizationName = :organizationValue",
      ExpressionAttributeNames: {"#organizationName": "category"},
      ExpressionAttributeValues: {":organizationValue": "Plug-ball valves"},
      Limit: 1000,
    };
    let data6 = await AwsDynamoDb.queryItem(params);


    params = {
      TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      //FilterExpression: "#organizationName = :organizationValue",
      IndexName: 'category-index',
      KeyConditionExpression: "#organizationName = :organizationValue",
      ExpressionAttributeNames: {"#organizationName": "category"},
      ExpressionAttributeValues: {":organizationValue": "Hydraulic check valves"},
      Limit: 1000,
    };
    let data7 = await AwsDynamoDb.queryItem(params);

    params = {
      TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      //FilterExpression: "#organizationName = :organizationValue",
      IndexName: 'category-index',
      KeyConditionExpression: "#organizationName = :organizationValue",
      ExpressionAttributeNames: {"#organizationName": "category"},
      ExpressionAttributeValues: {":organizationValue": "Spur gear"},
      Limit: 1000,
    };
    let data8= await AwsDynamoDb.queryItem(params);*/

    


   // var arr3 = [...data1.Items, ...data2.Items, ...data3.Items, ...data4.Items,...data5.Items, ...data6.Items, ...data7.Items, ...data8.Items];

       
  });

  /*
 let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
  let params = {
    TableName: config.aws.dynamodb.tableInfo.PartsCount,
    //FilterExpression: "#organizationName = :organizationValue",
    //IndexName: 'organization-index',
    KeyConditionExpression: "#organizationName = :organizationValue",
    ExpressionAttributeNames: {"#organizationName": "id"},
    ExpressionAttributeValues: {":organizationValue": "ImmensaLab"},
    Limit: 2000,
  };
  let data = await AwsDynamoDb.queryItem(params);
  console.log(data);
  res.status(200).send("Done");

  });

  */

  function partCountParser2(leid,orga) {
   return new Promise(resolve => {
      let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
      let params = {
        TableName: config.aws.dynamodb.tableInfo.PartDatabase,
        IndexName: "organization-index",
        //FilterExpression: "#organizationName = :organizationValue",
        KeyConditionExpression: "#organizationName = :organizationValue",
        ExpressionAttributeNames: {"#organizationName": "organization"},
        ExpressionAttributeValues: {":organizationValue": orga},
        Limit: 2000,
      };

      if(leid == 0)
      {
      }
      else
      {
        params.ExclusiveStartKey = {
          id: leid,
          organization: orga,
        };
      }
      let data =  AwsDynamoDb.queryItem(params);
      if (data.Count !== 0) {
        resolve(data);
       }
      //let getCount = AwsDynamoDb.scanItemCats(params);
      //return getCount;
     /*AwsDynamoDb.scanItemCats(params, (err, data) => {
        if (err) {
            console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
            //res.status(400).send(err);
        }
        else {
            if (data.Count !== 0) {
             resolve(data);
            }
            else
            {    
            }
        }
    })*/
     
    });
  }

  //////

   function partCountParser(leid,orga) {
    return new Promise(resolve => {
      let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
      let params = {
        TableName: config.aws.dynamodb.tableInfo.PartDatabase,
        IndexName: "organization-index",
        KeyConditionExpression: "#organizationName = :organizationValue",
        ExpressionAttributeNames: {"#organizationName": "organization"},
        ExpressionAttributeValues: {":organizationValue": orga},
        Limit: 1750,
      };

      if(leid == 0)
      {
      }
      else
      {
        params.ExclusiveStartKey = {
          id: leid,
          organization: orga,
        };
      }
      let getCount = AwsDynamoDb.queryItem(params);
      resolve(getCount);
    });
  }


  //Top 9 Categories Thread 

  router.post("/runtopcatsthread", async (req, res) => {
    res.status(200).send("Thread Fired UP");
    const runService = (workerData) => {
      return new Promise((resolve, reject) => {
        const worker = new Worker('./controllers/topcategoriesthread.js', { workerData });
        worker.on('message', resolve);
        worker.on('error', reject);
        worker.on('exit', (code) => {
          if (code !== 0)
            reject(new Error(`Worker stopped with exit code ${code}`));
        })
      })
    }
    
    const run = async () => {const result = await runService("Run Thread Service")}
    run().catch(err => console.error(err))
  
  });

  //Get Pyramid Data "getpyramiddata"

  router.post("/getpyramiddata", async (req, res) => {
   try{
    let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
    let params = {
      RequestItems: {},
    };
     
    params.RequestItems[config.aws.dynamodb.tableInfo.PartsCount] = {
      Keys: [{"id": "Top1"},{"id": "Top2"},{"id": "Top3"}], 
    };


    
    AwsDynamoDb.batchGetItem2(params)
      .then((data) => {
       
        var queryps = [];


        var TValue1 = 0;
        var TValue2 = 0;
        var TValue3 = 0;
        data.forEach(function(element, index, array) {
          if(element.id == "Top1"){
            TValue1 = {"stat": "High ","count": element.counts,"color": "MediumSeaGreen"};
          }

          if(element.id == "Top2"){
            TValue2 = {"stat": "Medium ","count": element.counts,"color": "Orange"};
          }

          if(element.id == "Top3"){
            TValue3 = {"stat": "Low ","count": element.counts,"color": "Tomato"};
          }  
      })

      queryps.push(TValue1,TValue2,TValue3);
        res.status(200).send(queryps);

      })
      .catch((err) => {
        res.status(400).send({ message: "batch get item failed" });
      });

    } catch (error) {
      console.log(error);
    }
  
  
  });

  //we need to send attribute that is why post is required.
  router.post("/getpartdata", utils.verificationByToken, async (req, res) => {
    try {
      let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
      let AwsS3Svc = ServiceManager.getService("AwsS3Svc");

      let params = {
        TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      };

      if (req.body.LastEvaluatedKey !== undefined) {
        params.ExclusiveStartKey = {
          id: req.body.LastEvaluatedKey,
          organization: req.body.organization,
        };
      }

      if (req.body.organization !== undefined) {
        params.KeyConditionExpression =
          "#organizationName = :organizationValue";
        params.IndexName = "organization-index";
        params.ExpressionAttributeNames = {
          "#organizationName": "organization",
        };
        params.ExpressionAttributeValues = {
          ":organizationValue": req.body.organization,
        };
      }
      if (req.body.limit === undefined) {
        //let part = await partsUtils.getPartsCount(req.body.organization);
        //if (Number(part.Count) > 16) 
        params.Limit = 100;
      } else if (req.body.limit) {
        params.Limit = req.body.limit;
      }

      let data = await AwsDynamoDb.queryItem(params);
      if (data.Count !== 0) {
        console.log(data.Count);
        //get signedUrls to show images on dashboard
        let getSignedUrl = new Promise(async (resolve, reject) => {
          for (let i = 0; i <= data.Items.length - 1; i++) {
            //TO DO - below code is for temp data in database (we dont have s3Key as an array field for some entries.Need to erase for clean data

            //NOTE : Below code is for old data support when we were not having compressed data.
            let s3Keys = data.Items[i].s3Key;
            let compressedImages = data.Items[i].imagesData;
            let compressedImagesNew = data.Items[i].imagesPath;
            let imagesPath = s3Keys;
            let bucket = config.aws.s3.params.Bucket;
            let path;
            if (compressedImages && !compressedImagesNew) {
              let folder = "partsdata_Medium";
              bucket = config.aws.s3.params.Data_Bucket;
              if (req.body.imageType && req.body.imageType === "Thumbnail") {
                imagesPath = compressedImages.Thumbnail;
                folder = "partsdata_Thumbnail";
              } else if (
                req.body.imageType &&
                req.body.imageType === "Original"
              ) {
                imagesPath = compressedImages.Original;
                folder = "partsdata";
              } else {
                imagesPath = compressedImages.Medium;
                folder = "partsdata_Medium";
              }
              path = folder + "/" + data.Items[i].id + "/" + imagesPath[0];
            } else if (s3Keys && !compressedImagesNew) path = imagesPath[0];
            else if (compressedImagesNew) {
              bucket = config.aws.s3.params.Data_Bucket;
              let folder = "partsdata_Medium";
              if (req.body.imageType && req.body.imageType === "Thumbnail")
                folder = "partsdata_Thumbnail";
              else if (req.body.imageType && req.body.imageType === "Original")
                folder = "partsdata";

              path =
                folder + "/" + data.Items[i].id + "/" + compressedImagesNew[0];
            }

            if (imagesPath instanceof Array)
              data.Items[i].signedUrls = AwsS3Svc.getSignedUrlForFile(
                path,
                bucket
              );
            else
              data.Items[i].signedUrls = AwsS3Svc.getSignedUrlForFile(
                path,
                bucket
              );
            if (i === data.Items.length - 1) {
              resolve(data);
            }
          }
        });

        getSignedUrl.then(() => {
          res.send(data);
        });
      } else {
        res.status(200).send(data);
      }
    } catch (ex) {
      res.status(500).send({ error: ex });
    }
  });

  //utility for duplicate images identification and modification
  router.post(
    "/modifyDuplicateImages",
    utils.verificationByToken,
    (req, res) => {
      try {
        let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
        let count = 0;
        let duplicateImages = [];

        if (req.body.path === undefined || req.body.path === null) {
          res
            .status(400)
            .send(
              "Please provide the required information of duplicate images"
            );
        } else {
          let dataItem = [];
          for (let i = 0; i < req.body.path.length; i++) {
            dataItem[i] = AwsS3Svc.getSignedUrlForFile(req.body.path[i].path);
          }

          dataItem.forEach((ele, index) => {
            Jimp.read(ele)
              .then((image) => {
                let newFileName = "./duplicates/duplicateImg" + index + ".jpg";
                image
                  .resize(256, 256) // resize
                  .quality(60) // set JPEG quality
                  .write(newFileName); // save

                duplicateImages.push({ fileName: newFileName, index: index });
                count++;

                if (count === dataItem.length) {
                  duplicateImages.sort(function (a, b) {
                    return a.index - b.index;
                  });

                  var uploadParams = [];
                  duplicateImages.forEach((element) => {
                    let uploadFileParams = {
                      content: element.fileName, //"./duplicates/duplicateImg" + index + ".jpg,
                      name: req.body.path[element.index].imageId,
                      projectName:
                        "partsdata/" + req.body.path[element.index].partId,
                    };

                    uploadParams.push(uploadFileParams);
                  });
                  let itemProcessed = 0;
                  uploadParams.forEach((params) => {
                    console.log("params", params);
                    AwsS3Svc.uploadFile(params)
                      .then((data) => {
                        itemProcessed++;
                        console.log("success", params.content);
                        //deleting modified duplicateImages from local storage after uploading to s3
                        fs.unlinkSync(params.content);
                        if (itemProcessed === uploadParams.length) {
                          res
                            .status(200)
                            .send({ message: "Image Modification Successful" });
                        }
                      })
                      .catch((err) => {
                        res
                          .status(400)
                          .send({ message: "Error in image Modification" });
                      });
                  });
                }
              })
              .catch((err) => {
                console.error(err);
              });
          });
        }
      } catch (error) {
        console.log(error);
      }
    }
  );

  //api to get part data using id.
  router.post("/getpartbyid", utils.verificationByToken, (req, res) => {
    let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");

    try {
      if (req.body.id === undefined || req.body.id === null) {
        res.status(400).send("Please provide the required information");
      } else {
        let queryParams = {
          TableName: config.aws.dynamodb.tableInfo.PartDatabase,
          KeyConditionExpression: "#id = :value",
          ExpressionAttributeNames: {
            "#id": "id",
          },
          ExpressionAttributeValues: {
            ":value": req.body.id,
          },
        };

        AwsDynamoDb.queryItem(queryParams)
          .then((data) => {
            if (data.Count !== 0) {
              return partsUtils.getSignedUrlForMultipleKeys(data);
            }
          })
          .catch((err) => {
            res.status(400).send(err);
          })
          .then((partdataWithSignedUrl) => {
            if (partdataWithSignedUrl === undefined) {
              res.status(200).send({
                message: `Requested Item ${req.body.id} is not present in database`,
              });
            } else {
              delete partdataWithSignedUrl.Items[0].s3Key;
              res.status(200).send(partdataWithSignedUrl);
            }
          })
          .catch((err) => {
            res.status(200).send({ message: "Error in fetching part by Id" });
          });
      }
    } catch (err) {
      res.status(500).send(err);
    }
  });

  //delete part data
  router.post("/delete", utils.verificationByToken, (req, res) => {
    let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
    let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
    let s3ObjectsTodelete;
    try {
      if (req.body.id === undefined || req.body.id === null) {
        res.send("Please send data to delete the part (id and s3 key)");
      } else {
        let queryParams = {
          TableName: config.aws.dynamodb.tableInfo.PartDatabase,
          KeyConditionExpression: "#id = :value",
          ExpressionAttributeNames: {
            "#id": "id",
          },
          ExpressionAttributeValues: {
            ":value": req.body.id,
          },
        };

        let params = {
          TableName: config.aws.dynamodb.tableInfo.PartDatabase,
          Key: {
            id: req.body.id,
          },
        };

        AwsDynamoDb.queryItem(queryParams)
          .then((data) => {
            if (data.Count !== 0) {
              s3ObjectsTodelete = data.Items[0].imagesPath;
              return AwsDynamoDb.deleteItem(params);
            } else {
              Promise.reject("Requested Item is not present in database");
            }
          })
          .then(async (data) => {
            //delete the s3 file.
            if (s3ObjectsTodelete !== undefined && s3ObjectsTodelete !== []) {
              for (let i = 0; i < s3ObjectsTodelete.length; i++) {
                let fileOriginal =
                  "partsdata/" + req.body.id + "/" + s3ObjectsTodelete[i];
                let fileThumbnail =
                  "partsdata_Thumbnail/" +
                  req.body.id +
                  "/" +
                  s3ObjectsTodelete[i];
                let fileMedium =
                  "partsdata_Medium/" +
                  req.body.id +
                  "/" +
                  s3ObjectsTodelete[i];
                let bucket = config.aws.s3.params.Data_Bucket;
                await AwsS3Svc.deleteFile(fileOriginal);
                await AwsS3Svc.deleteFile(fileThumbnail, bucket);
                await AwsS3Svc.deleteFile(fileMedium, bucket);
              }
              res.status(200).send({ message: "Part deleted successfully" });
            } else {
              res.status(200).send({ message: "No file is removed from s3" });
            }
          })
          .catch((err) => {
            res.status(400).send(err);
          });
      }
    } catch (err) {
      res.status(500).send(err);
    }
  });

  //TO DO api to update the partdata, it needs UpdateExpression according to the condition. We are using '/uploadpartdata' for now to update the data.
  //below code is working but need refactoring

  router.put("/update", utils.verificationByToken, async (req, res) => {
    try {
      let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
      let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
      let queryData;
      let imageDataTodelete = [];

      let updateParams = await partsUtils.uploadFileParamsPromise(req);

      let queryParams = {
        TableName: config.aws.dynamodb.tableInfo.PartDatabase,
        KeyConditionExpression: "#id = :value",
        ExpressionAttributeNames: {
          "#id": "id",
        },
        ExpressionAttributeValues: {
          ":value": updateParams.fields.id,
        },
      };

      let queryDBData = await AwsDynamoDb.queryItem(queryParams);
      queryData = queryDBData.Items[0];

      //remove s3 key from database if included in update request
      let dbFormData = await partsUtils.getS3KeysToRemoveArray(
        updateParams.fields
      );
      let projectNames = await partsUtils.getProjectNameList(
        dbFormData.newUpdatedParams.organization
      );

      if (
        projectNames.includes(dbFormData.newUpdatedParams.name) &&
        queryData.name !== dbFormData.newUpdatedParams.name
      ) {
        res.status(400).send({ message: "Same name exist" });
        return;
      }

      if (dbFormData.newUpdatedParams !== undefined) {
        let partsData = {
          id: dbFormData.newUpdatedParams.id,
          name: dbFormData.newUpdatedParams.name,
          searchname: dbFormData.newUpdatedParams.name.toLowerCase(),
          number: dbFormData.newUpdatedParams.number,
          description: dbFormData.newUpdatedParams.description,
          size: {
            length: dbFormData.newUpdatedParams.length,
            breadth: dbFormData.newUpdatedParams.breadth,
            height: dbFormData.newUpdatedParams.height,
          },
          material: dbFormData.newUpdatedParams.material,
          complexity: dbFormData.newUpdatedParams.complexity,
          category: dbFormData.newUpdatedParams.category,
          subcategory: dbFormData.newUpdatedParams.subcategory,
          notes: dbFormData.newUpdatedParams.notes,
          timeStamp: new Date().toISOString(),
          user: dbFormData.newUpdatedParams.email,
          organization: dbFormData.newUpdatedParams.organization,
          sellingPrice: dbFormData.newUpdatedParams.sellingPrice,
          costPrice: dbFormData.newUpdatedParams.costPrice,
          printabilityScore: dbFormData.newUpdatedParams.printabilityScore,
          //s3Key: data.key
        };
        updateParams.fields = partsData;
      }

      let dbData;
      if (dbFormData.s3KeysToRemove.length !== 0) {
        let keys = dbFormData.s3KeysToRemove;
        for (let i = 0; i < keys.length; i++) {
          imageDataTodelete.push(keys[i].split("/")[2]);
        }
        let removeS3KeysParams = {
          imagesPath: imageDataTodelete,
        };
        let removeExpression = dynamodbUpdateExpression.getRemoveExpression(
          queryData,
          removeS3KeysParams
        );
        removeExpression.Key = {
          id: updateParams.fields.id,
        };
        removeExpression.TableName = config.aws.dynamodb.tableInfo.PartDatabase;
        removeExpression.ReturnValues = "ALL_NEW";
        dbData = await AwsDynamoDb.updateItem(removeExpression);
      }

      //remove s3 file from s3 bucket if included in update request for removal.
      if (dbData && dbData.Attributes !== undefined) {
        queryData = dbData.Attributes;
      }

      //delete the s3 file.
      if (imageDataTodelete !== undefined && imageDataTodelete !== []) {
        for (let i = 0; i < imageDataTodelete.length; i++) {
          let fileOriginal =
            "partsdata/" + queryData.id + "/" + imageDataTodelete[i];
          let fileThumbnail =
            "partsdata_Thumbnail/" + queryData.id + "/" + imageDataTodelete[i];
          let fileMedium =
            "partsdata_Medium/" + queryData.id + "/" + imageDataTodelete[i];
          let bucket = config.aws.s3.params.Data_Bucket;
          await AwsS3Svc.deleteFile(fileOriginal);
          await AwsS3Svc.deleteFile(fileThumbnail, bucket);
          await AwsS3Svc.deleteFile(fileMedium, bucket);
        }
      }

      //upload the file if present in the update request
      let filesPathObj = await partsUtils.getUploadFilesArray(
        updateParams.files
      );
      let imagesData = await partsUtils.uploadImages(
        filesPathObj,
        updateParams.uid
      );
      if (imagesData && imagesData.length > 0)
        updateParams.fields.imagesPath = imagesData;

      let tranlatedFileUrn;
      let filesPath;
      if (filesPathObj && filesPathObj["ViewerFile"].length > 0) {
        // uploading and translating the file
        tranlatedFileUrn = await forgeUtils.uploadAndTranslateFile(
          updateParams.files.viewerFile.name,
          filesPathObj["ViewerFile"][0]
        );

        //delete the unecessary bucket file
        await forgeUtils.deleteViewerFileFromS3(updateParams.uid);

        // uploading viewer files to s3
        filesPath = await forgeUtils.uploadViewerFileToS3(
          filesPathObj["ViewerFile"],
          updateParams.uid
        );
      }

      if (filesPath && filesPath.key)
        updateParams.fields.filesPath = filesPath.key;

      if (tranlatedFileUrn) updateParams.fields.urn = tranlatedFileUrn;

      let updateExpression = dynamodbUpdateExpression.getUpdateExpression(
        queryData,
        updateParams.fields
      );
      updateExpression.Key = {
        id: updateParams.fields.id,
      };
      updateExpression.ReturnValues = "ALL_NEW";
      updateExpression.TableName = config.aws.dynamodb.tableInfo.PartDatabase;
      //update database
      await AwsDynamoDb.updateItem(updateExpression);
      console.log("part updated Successfully");
      res
        .status(200)
        .send({ message: "part updated Successfully", data: updateParams });
    } catch (err) {
      console.log(err.message);
      res.status(500).send(err);
    }
  });

  router.get("/getitemcount", utils.verificationByToken, async (req, res) => {
    try {
      let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");

      let params = {
        TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      };
      let data = await AwsDynamoDb.scanItem(params);
      res.status(200).send({ Count: data.Count });
    } catch (ex) {
      res.status(500).send({ error: ex });
    }
  });

 /* router.post("/getPartsCount", utils.verificationByToken, (req, res) => {
    try {
      if (req.body.organization) {
        partsUtils
          .getPartsCount(req.body.organization)
          .then((data) => {
            console.log(">>>", data);
            res.status(200).send({
               data,
            });
          })
          .catch((error) => {
            console.log(error);
            res.status(400).send({ Message: error });
          });
      }
    } catch (ex) {
      res.status(500).send(ex);
    }
  });*/
  //
  router.post("/getPartsCount", utils.verificationByToken, async (req, res) => {

  let counter = 0;
    let isLast = false;
    let prev;
    let cure;

    //const resultFT = await partCountParser(0,req.body.organization);
    //counter = counter + Number(resultFT.ScannedCount);
    //cure = resultFT;
    /*if(resultFT.LastEvaluatedKey)
    {
      isLast = true;
      while(isLast)
      { 
        prev = cure;
        const result = await partCountParser(prev.LastEvaluatedKey.id,req.body.organization);
        if(result.LastEvaluatedKey)
        {
            counter = counter + Number(result.ScannedCount);
        }
        else
        {
          counter = counter + Number(result.ScannedCount);
          isLast = false;
        }
        cure = result;
      }
    }
    else
    {
    }*/
    let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
    let params = {
      TableName: config.aws.dynamodb.tableInfo.PartsCount,
      //FilterExpression: "#organizationName = :organizationValue",
      //IndexName: 'organization-index',
      KeyConditionExpression: "#organizationName = :organizationValue",
      ExpressionAttributeNames: {"#organizationName": "id"},
      ExpressionAttributeValues: {":organizationValue": req.body.organization},
      Limit: 2000,
    };
    let data = await AwsDynamoDb.queryItem(params);
    counter = Number(data.Items[0]?.counts);
    res.status(200).send({
      counter,
    });
  });


  //

  router.post(
    "/importParts",
    utils.verificationByToken,
    async (req, response) => {
      //Search Here
      try {
        let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
        let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");

        let formdata = await partsUtils.uploadFileParamsPromise(req);
        let filesToUpload = await partsUtils.getUploadFilesArray(
          formdata.files
        );

        //upload file to S3, need to implement logic for multiple file upload
        if (
          filesToUpload["Images"].length > 0 &&
          filesToUpload["Images"] !== undefined
        ) {
          let file = filesToUpload["Images"][0];
          var zip = new AdmZip(file);

          var randomString = Math.random().toString(36).substring(2);
          var extractPath = file.split(".")[0] + randomString;
          if (!fs.existsSync(extractPath)) {
            fs.mkdirSync(extractPath);
          }
          // zip.extractAllTo(/*target path*/ extractPath, /*overwrite*/ true);

          // let dirCont = fs.readdirSync(extractPath);
          // extractPath = extractPath + "/" + dirCont[0];
          // dirCont = fs.readdirSync(extractPath);
          // //find xlsx file type in folder
          // let excelfiles = dirCont.filter(function (elm) {
          //   return elm.match(/.*\.(xlsx)/gi);
          // });

          console.log("extractPath    ", extractPath);

          zip.extractAllTo(/*target path*/ extractPath, /*overwrite*/ true);

          const zipDir = fs.readdirSync(extractPath);

          console.log("zipDir      ", zipDir);
          // extractPath = extractPath + "/" + zipDir[0];
          // const dirCont = fs.readdirSync(extractPath);
          // console.log('SSSSS : ',dirCont);
          //find xlsx file type in folder
          let excelfiles = zipDir.filter(function (elm) {
            console.log("elm      ", elm);
            return elm.match(/.*\.(xlsx)/gi);
          });

        
          var excelFilePath = extractPath + path.sep + excelfiles[0];


          console.log("excelFilePath      ", excelFilePath);
          var workbook = xlsx.readFile(excelFilePath);
          var sheet_name_list = workbook.SheetNames;
          //only for one sheet
          var entries = xlsx.utils.sheet_to_json(
            workbook.Sheets[sheet_name_list[0]]
          );

          var itmesPushed = 0;
          // add organization to the partsUtils.getProjectNameList;
          //currently organization name is hard coded as it was decided that for now batch upload
          //option is only for Immensa lab
          //If we want to give it to every organization admin then we have take input from UI
          //By providing drop down in UI
          const organizationName = "ImmensaLab";
          let projectNames = await partsUtils.getProjectNameList(
            organizationName
          );
          console.log("Parts upload started...", entries);
          for (let i = 0; i < entries.length; i++) {
            let entry = entries[i];
            let entryData = partsUtils.validateEntries(entry, projectNames);
            console.log(" entryData" + entryData.status); //Here must make search for this entry in folders
            if (!entryData.status) {
              console.log(entry.Name + " : " + entryData.message);
              continue;
            } else {
              projectNames.push(entry.Name);
            }
            var imagesPath = entry.Name;
            let filesData = [];
            let viewerfilesData = [];
            var folder = extractPath + path.sep + imagesPath;

            // Search entry name in folders
            if (!fs.existsSync(folder)) {
              console.log(
                " Folder is missing ------------------> " + entry.Name
              );
              continue;
            } else {
              console.log(" Folder is not missing ------------------> ");
              //excel entry name matches with folder name
              itmesPushed = itmesPushed + 1;

              fs.readdirSync(folder).forEach((file) => {
                let randomText = crypto.randomBytes(5).toString("hex");
                let s3Key = randomText + path.extname(file);
                let extname = path.extname(file).toUpperCase();

                let types = [".JPG", ".JPEG", ".PNG", ".BMP"];
                if (types.indexOf(extname) > -1)
                  filesData.push({
                    file: folder + path.sep + file,
                    s3Key: s3Key,
                  });
                else if (
                  forgeUtils.ViewerExtensionList.includes(extname.toLowerCase())
                )
                  viewerfilesData.push({
                    file: folder + path.sep + file,
                    name: file,
                  });
              });
              let id = uuid();
              //this to remove - from uuid
              id = id.replace(/-/g, "");

              let data;
              if (filesData.length > 0)
                data = await AwsS3Svc.uploadDir(filesData, id);

              let tranlatedFileUrn;
              let filesPath;
              if (viewerfilesData.length > 0) {
                // uploading and translating the file
                tranlatedFileUrn = await forgeUtils.uploadAndTranslateFile(
                  viewerfilesData[0].name,
                  viewerfilesData[0].file
                );
                // uploading viewer files to s3
                filesPath = await forgeUtils.uploadViewerFileToS3(
                  [viewerfilesData[0].file],
                  id
                );
              }

              let imagesData = [];
              for (let j = 0; j < filesData.length; j++) {
                var res = await utils.compressImage(filesData[j].file);
                let folderThumbnail = "partsdata_Thumbnail";
                let folderMedium = "partsdata_Medium";
                let uploadFileParams = {
                  content: res.files[0],
                  name: filesData[j].s3Key,
                  projectName: folderThumbnail + "/" + id,
                  bucketName: config.aws.s3.params.Data_Bucket,
                };

                let dataThumbnail = await AwsS3Svc.uploadFile(uploadFileParams);
                let uploadFileParamsMedium = {
                  content: res.files[1],
                  name: filesData[j].s3Key,
                  projectName: folderMedium + "/" + id,
                  bucketName: config.aws.s3.params.Data_Bucket,
                };

                let dataMedium = await AwsS3Svc.uploadFile(
                  uploadFileParamsMedium
                );

                if (
                  dataMedium.Key.split("/")[2] !==
                  dataThumbnail.Key.split("/")[2]
                ) {
                  if (projectNames.includes(entry.Name)) {
                    let index = projectNames.indexOf(entry.Name);
                    projectNames.splice(index, 1);
                  }
                  console.err("Could not upload compressed images.");
                }

                imagesData.push(data[j].split("/")[2]);
                fs.removeSync(res.tempFolderpath);
              }

              //calculation for random sp, cp and printability score
              let cp = Math.floor(Math.random() * 10) + 1;
              let margin = Math.floor(Math.random() * 10) + 1;
              let sp = cp + margin;
              let parameters = {
                material: entry.Material,
                size: {
                  length: entry.Length,
                  breadth: entry.Breadth,
                  height: entry.Height,
                },
                complexity: entry.Complexity,
              };
              let score = await partsUtils.getPrintabilityScore(parameters);

              //TO DO partsData object needs to be changed, need to put validations on it.
              let partsData = {
                id: id,
                name: entry.Name,

                searchname: entry.Name.toLowerCase(),
                number: entry.Number,
                description: entry.Description,
                size: {
                  length: entry.Length,
                  breadth: entry.Breadth,
                  height: entry.Height,
                },
                material: entry.Material,
                complexity: entry.Complexity,
                category: entry.Category,
                subcategory: entry.SubCategory,
                notes: entry.Notes,
                timeStamp: new Date().toISOString(),
                costPrice: cp,
                sellingPrice: sp,
                organization: organizationName,
                printabilityScore: score,
              };

              if (entry.Email) partsData.user = entry.Email;

              if (tranlatedFileUrn) partsData.urn = tranlatedFileUrn;

              if (filesPath && filesPath.key)
                partsData.filesPath = filesPath.key;

              //createdBy
              if (entry.createdBy !== undefined && entry.createdBy !== null) {
                partsData.createdBy = entry.createdBy;
              }

              //updatedBy
              if (entry.updatedBy !== undefined && entry.updatedBy !== null) {
                partsData.updatedBy = entry.updatedBy;
              }

              if (data !== undefined) {
                partsData.imagesPath = imagesData;
              }

              let params = {
                TableName: config.aws.dynamodb.tableInfo.PartDatabase,
                Item: partsData,
                ReturnConsumedCapacity: "TOTAL",
                ReturnValues: "ALL_OLD",
              };

              await AwsDynamoDb.putItem(params);
              console.log(
                " Item put successfully ------------------> " +
                  entry.Name +
                  " | id: " +
                  partsData.id
              );
            }
          }
          console.log("All parts uploaded successfully");
          response
            .status(200)
            .send({ message: itmesPushed + " items pushed successfully." });
          fs.removeSync(excelFilePath);
          fs.removeSync(extractPath);
        }
      } catch (err) {
        response.status(500).send(err);
        console.log("errrr", err);
      }
    }
  );

  router.post("/exportData", utils.verificationByToken, async (req, res) => {
    try {
      let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
      let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
      let itmesPushed = 0;
      let params = {
        TableName: config.aws.dynamodb.tableInfo.PartDatabase,
        Limit: 600,
      };

      let count = 0;
      let data = await AwsDynamoDb.scanItem(params);
      let imageBucket = config.aws.s3.params.Bucket;
      let fileBucket = config.aws.s3.params.Data_Bucket;

      var tmpdir = os.tmpdir();
      var appPath = tmpdir + path.sep + "exportdata";

      if (!fs.existsSync(appPath)) {
        fs.mkdirSync(appPath);
      }

      data.Items.forEach(async (element) => {
        console.log(count);
        if (element.filesPath) {
          let viewerFille =
            "partsdata_Viewer/" + element.id + "/" + element.filesPath;
          const fileUrl = AwsS3Svc.getSignedUrlForFile(viewerFille, fileBucket);
          let ext = path.extname(viewerFille);
          await partsUtils.downloadFiles(
            fileUrl,
            appPath + "/" + element.name + "/" + element.name + ext
          );
        }

        for (const key in element.imagesPath) {
          if (element.imagesPath.hasOwnProperty(key)) {
            let imagePath =
              "partsdata/" + element.id + "/" + element.imagesPath[key];
            const imageUrl = AwsS3Svc.getSignedUrlForFile(
              imagePath,
              imageBucket
            );
            await partsUtils.downloadFiles(
              imageUrl,
              appPath + "/" + element.name + "/" + element.imagesPath[key]
            );
          }
        }
        ++count;
        delete element.imagesPath;
        if (element.user) delete element.user;

        if (element.timeStamp) delete element.timeStamp;

        if (element.size) delete element.size;
      });

      let worksheet = xlsx.utils.json_to_sheet(data.Items);
      let wb = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(wb, worksheet, "exportSheet");
      xlsx.writeFile(wb, appPath + "/sheet.xlsx");

      if (data.Count === count) {
        //var zip = new AdmZip();
        // zip.addLocalFolder(appPath, tmpdir, true);
        res
          .status(200)
          .send({ message: itmesPushed + " items pushed successfully." });
      }
    } catch (error) {
      res.status(400).send({ error: error });
    }
  });

  router.post("/upload3dFiles", utils.verificationByToken, async (req, res) => {
    try {
      let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");

      let formdata = await partsUtils.uploadFileParamsPromise(req);
      let filesToUpload = await partsUtils.getUpload3dFilesArray(
        formdata.files
      );

      //upload file to S3, need to implement logic for multiple file upload
      if (
        filesToUpload !== undefined &&
        filesToUpload["ViewerFile"].length > 0
      ) {
        let params = {
          TableName: config.aws.dynamodb.tableInfo.PartDatabase,
          Limit: 600,
        };

        let nameList = [];
        let namePathMap = [];
        let itmesPushed = 0;
        AwsDynamoDb.scanItem(params, async (err, data) => {
          data.Items.forEach((element) => {
            if (element.name) {
              let data = [element.name, element];
              namePathMap.push(data);
              nameList.push(element.name);
            }
          });

          var tmpdir = os.tmpdir();
          var randomString = Math.random().toString(36).substring(2);
          var appPath = tmpdir + path.sep + "ViewerFileLog";

          if (!fs.existsSync(appPath)) {
            fs.mkdirSync(appPath);
          }

          let log = fs.createWriteStream(
            appPath + path.sep + randomString + ".txt",
            { flags: "a" }
          );
          for (let i = 0; i < filesToUpload["ViewerFile"].length; ++i) {
            let file = filesToUpload["ViewerFile"][i];
            let name = file.name.split(".")[0];
            if (!nameList.includes(name)) {
              log.write(name + " - failed \n");
              console.log(name + " - failed \n");
            } else {
              let tranlatedFileUrn;
              let filesPath;
              var id = Math.random().toString(36).substring(2);
              tranlatedFileUrn = await forgeUtils.uploadAndTranslateFile(
                file.name,
                file.path
              );
              let filesList = [];
              filesList.push(file.path);
              filesPath = await forgeUtils.uploadViewerFileToS3(filesList, id);

              let fileData = new Map(namePathMap);
              let elementData = fileData.get(name);
              let partsData = {
                id: elementData.id,
                name: elementData.name,
                number: elementData.number,
                description: elementData.description,
                size: {
                  length: elementData.size.length,
                  breadth: elementData.size.breadth,
                  height: elementData.size.height,
                },
                material: elementData.material,
                complexity: elementData.complexity,
                category: elementData.category,
                subcategory: elementData.subcategory,
                notes: elementData.notes,
                timeStamp: new Date().toISOString(),
              };

              if (tranlatedFileUrn) partsData.urn = tranlatedFileUrn;

              if (filesPath && filesPath.key)
                partsData.filesPath = filesPath.key;

              let updateExpression = dynamodbUpdateExpression.getUpdateExpression(
                elementData,
                partsData
              );
              updateExpression.TableName =
                config.aws.dynamodb.tableInfo.PartDatabase;
              updateExpression.Key = {
                id: elementData.id,
              };
              await AwsDynamoDb.updateItem(updateExpression);
              log.write(name + " - success \n");
              console.log(name + " - success \n");
              ++itmesPushed;
            }
          }
          log.end();
          console.log(itmesPushed + " items pushed successfully.");
          res
            .status(200)
            .send({ message: itmesPushed + " items pushed successfully." });
        });
      }
    } catch (error) {
      console.log(error);
    }
  });

  router.post("/awsBucketImageCount", utils.verificationByToken, (req, res) => {
    try {
      let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
      let imageCount = 0;
      let params = {
        TableName: config.aws.dynamodb.tableInfo.PartDatabase,
        ProjectionExpression: "imagesPath, s3Key",
      };

      AwsDynamoDb.scanItem(params)
        .then((result) => {
          for (let i = 0; i < result.Items.length; i++) {
            if (result.Items[i].imagesPath) {
              imageCount += result.Items[i].imagesPath
                ? result.Items[i].imagesPath.length
                : 0;
            } else {
              imageCount += result.Items[i].s3Key
                ? result.Items[i].s3Key.length
                : 0;
            }
          }
          res.send({ imageCount: imageCount });
        })
        .catch((err) => {
          res.status(400).send(err);
        });
    } catch (err) {
      console.log(err);
    }
  });

  router.post(
    "/copyFromDatabase",
    utils.verificationByToken,
    async (req, res) => {
      let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
      try {
        let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");

        let params = {
          TableName: config.aws.dynamodb.tableInfo.PartDatabase,
        };
        let result = await AwsDynamoDb.scanItem(params);
        for (let i = 220; i < 332; i++) {
          var tmpdir = os.tmpdir();
          var folder =
            tmpdir + path.sep + "partsdata" + path.sep + result.Items[i].id;
          var files = [];
          // eslint-disable-next-line no-loop-func
          fs.readdirSync(folder).forEach((file) => {
            if (path.extname(file) === ".JPG" || path.extname(file) === ".PNG")
              files.push({ path: folder + path.sep + file });
          });
          let id = uuid();
          //this to remove - from uuid
          id = id.replace(/-/g, "");
          let entry = result.Items[i];
          var uploadDirPromise = AwsS3Svc.uploadDir(files, id);
          uploadDirPromise.then((data) => {
            //TO DO partsData object needs to be changed, need to put validations on it.
            let partsData = {
              id: id,
              name: entry.name,
              number: entry.number,
              description: entry.description,
              size: {
                length: entry.size.length,
                breadth: entry.size.breadth,
                height: entry.size.height,
              },
              material: entry.material,
              complexity: entry.complexity,
              category: entry.category,
              subcategory: entry.subcategory,
              notes: entry.notes,
            };

            //createdBy
            if (entry.createdBy !== undefined && entry.createdBy !== null) {
              partsData.createdBy = entry.createdBy;
            }

            //updatedBy
            if (entry.updatedBy !== undefined && entry.updatedBy !== null) {
              partsData.updatedBy = entry.updatedBy;
            }

            if (data !== undefined) {
              partsData.s3Key = data;
            }

            let params = {
              TableName: "Parts-Production",
              Item: partsData,
              ReturnConsumedCapacity: "TOTAL",
              ReturnValues: "ALL_OLD",
            };

            var putItemPromise = AwsDynamoDb.putItem(params);
            putItemPromise.then(() => {
              console.log(
                " Item put successfully ------------------> " + entry.Name
              );
            });
          });
        }
        console.log(result.Count);
      } catch (ex) {
        res.status(400).send({ error: ex });
      }
    }
  );

  router.post(
    "/sendEmailForPrinting",
    utils.verificationByToken,
    async (req, res) => {
      try {
        let PrintingData;
        var formidable = require("formidable");
        let form = new formidable.IncomingForm();

        form.parse(req, async function (err, fields, files) {
          PrintingData = fields;

          const params = {
            Destination: {
              ToAddresses: ["developer@immensalabs.com"], // Email address/addresses that you want to send your email
            },
            ConfigurationSetName: "TestConfig",
            Message: {
              Body: {
                Html: {
                  // HTML Format of the email
                  Charset: "UTF-8",
                  Data:
                    "<html><body><h2>Printing Request</h2><p>The user " +
                    PrintingData.fromemail +
                    " has requested the below part for printing.</p><table style='border-collapse: collapse;width: 100%;'><tr ><th style='padding: 8px; text-align: left;border-bottom: 1px solid #ddd;'>User Name</th><th style='padding: 8px; text-align: left;border-bottom: 1px solid #ddd;'>Part Name</th><th style='padding: 8px; text-align: left;border-bottom: 1px solid #ddd;'>Quantity</th><th style='padding: 8px; text-align: left;border-bottom: 1px solid #ddd;'>User Type</th></tr><tr><td style='padding: 8px; text-align: left;border-bottom: 1px solid #ddd;'>" +
                    PrintingData.fromemail +
                    "</td><td style='padding: 8px; text-align: left;border-bottom: 1px solid #ddd;'>" +
                    PrintingData.partname +
                    "</td><td style='padding: 8px; text-align: left;border-bottom: 1px solid #ddd;'>" +
                    PrintingData.qty +
                    "</td><td style='padding: 8px; text-align: left;border-bottom: 1px solid #ddd;'>" +
                    PrintingData.usertype +
                    "</td></tr></table><br /><img src='https://www.thebig5.ae/media/2743/immnesa-banner.png' style='height:100px;width:300px' /></body></html>",
                },
                Text: {
                  Charset: "UTF-8",
                  Data:
                    "The user " +
                    PrintingData.fromemail +
                    " has requested " +
                    PrintingData.qty +
                    "parts of " +
                    PrintingData.partname +
                    " for printing.",
                },
              },
              Subject: {
                Charset: "UTF-8",
                Data: "Printing Request",
              },
            },
            Source: PrintingData.fromemail,
          };
          let AwsEmailSvc = ServiceManager.getService("AwsEmailSvc");

          let data = await AwsEmailSvc.sendEmail(params);

          //data is undefined if the email is not verified
          if (!data) {
            let verificationEmailParams = {
              EmailAddress: params.Source /* required */,
              TemplateName:
                config.aws.ses.emailVerificationTemplateParams
                  .TemplateName /* required */,
            };
            //verify email for AWS SES
            let verifyMail = await AwsEmailSvc.sendVerificationEmail(
              verificationEmailParams
            );
            if (verifyMail.ResponseMetadata.RequestId) {
              //This Email is not verified to use this service. Please verify your email to place your request.
              res.send({
                status:
                  "Your email is not verified, we have sent an email for verification, Please verify it to place your request.",
                variant: "error",
              });
            }
          } else {
            res.send({
              status: "order has been placed successfully",
              variant: "success",
            });
          }
        });
      } catch (err) {
        console.log("error", err);
      }
    }
  );

  router.post(
    "/sendEmailAfterTraining",
    utils.verificationByToken,
    async (req, res) => {
      try {
        let AwsEmailSvc = ServiceManager.getService("AwsEmailSvc");
        let PrintingData = req.body;

        const params = {
          Destination: {
            ToAddresses: [PrintingData.toemail], // Email address/addresses that you want to send your email
          },
          ConfigurationSetName: "TestConfig",
          Message: {
            Body: {
              Html: {
                // HTML Format of the email
                Charset: "UTF-8",
                Data:
                  "<html><body><h2>Training Status</h2><h3>The Training of new Parts is completed.</h3><br /><img src='https://www.thebig5.ae/media/2743/immnesa-banner.png' style='height:100px;width:300px' /></body></html>",
              },
              Text: {
                Charset: "UTF-8",
                Data: "The Printing of new parts is finished.",
              },
            },
            Subject: {
              Charset: "UTF-8",
              Data: "Training Notification",
            },
          },
          Source: PrintingData.fromemail,
        };

        let data = await AwsEmailSvc.sendEmail(params);

        //data is undefined if the email is not verified
        //in production i.e out of aws sandbox verification will not be needed.
        if (!data) {
          var email = { EmailAddress: params.Source };

          //verify email for AWS SES
          let verifyMail = await AwsEmailSvc.verifyEmail(email);

          console.log(verifyMail);
          if (verifyMail.ResponseMetadata.RequestId) {
            res.send({
              status:
                "This Email is not verified to use this service. Please verify your email to place your request.",
            });
          }
        }
      } catch (err) {
        console.log("error", err);
      }
    }
  );

  router.post(
    "/sendTemplateEmail",
    utils.verificationByToken,
    async (req, res) => {
      try {
        var formidable = require("formidable");
        let form = new formidable.IncomingForm();

        let uploadFilePromise = new Promise((resolve, reject) => {
          form.parse(req, function (err, fields, files) {
            resolve(fields);
          });
        });
        uploadFilePromise.then(async (printingData) => {
          console.log("printingData", printingData);

          const params = {
            Source: printingData.fromemail,
            Template: "PrintingRequest_2",
            ConfigurationSetName: "TestConfig",
            Destination: {
              ToAddresses: ["prakhar.nigam@cctech.co.in"],
            },
            TemplateData:
              '{ "username":"' +
              printingData.username +
              '", "qty": "' +
              printingData.qty +
              '", "partname": "' +
              printingData.partname +
              '", "usertype": "' +
              printingData.usertype +
              '" }',
          };

          let AwsEmailSvc = ServiceManager.getService("AwsEmailSvc");

          let data = await AwsEmailSvc.sendTemplateEmail(params);
          console.log("data", data);
        });
      } catch (ex) {
        console.log(ex);
      }
    }
  );

  router.post(
    "/createTemplate",
    utils.verificationByToken,
    async (req, res) => {
      try {
        const params = {
          Template: {
            TemplateName: "Custom_verification_template",
            SubjectPart: "Email Verfication",
            HtmlPart:
              "<h2>The user {{username}}, has requested {{partname}} for printing.<h2><h3>Quantity :{{qty}}</h3><h3>User type:{{usertype}}</h3>",
            TextPart:
              "The user {{username}} has requested {{partname}} for Printing. \r\n Quantity:{{qty}} \n User type: {{usertype}}",
          },
        };

        let AwsEmailSvc = ServiceManager.getService("AwsEmailSvc");
        let data = await AwsEmailSvc.createTemplate(params);
        console.log("data", data);
      } catch (ex) {
        console.log(ex);
      }
    }
  );

  router.post("/batchget", utils.verificationByToken, async (req, res) => {
    try {
      let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");

      let params = {
        RequestItems: {},
      };
      /* req.body
             * [
                {
                    "id": "48a07bf16d694a459e87a49f6b549a8f"
                },
                {
                    "id": "9fdda1e72d3d4631bd54837a067070e3"
                }
            ]*/
      params.RequestItems[config.aws.dynamodb.tableInfo.PartDatabase] = {
        Keys: req.body, //should be array of objects of part ids like above
      };

      AwsDynamoDb.batchGetItem(params)
        .then((data) => {
          res.status(200).send(data);
        })
        .catch((err) => {
          res.status(400).send({ message: "batch get item failed" });
        });
    } catch (error) {
      console.log(error);
    }
  });

  router.get("/batchWrite", utils.verificationByToken, async (req, res) => {
    try {
      let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");

      let params = {
        TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      };

      let data = await AwsDynamoDb.scanItem(params);
      for (let i = 0; i < data.Items.length; i++) {
        if (data.Items[i] && data.Items[i].name) {
          data.Item[i]["searchname"] = data.Items[i].name.toLowerCase();
        }
      }

      var configData = {
        TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      };

      AwsDynamoDb.batchWrite(configData, data.Items)
        .then((data) => {
          res
            .status(200)
            .send({ message: "batch write completed successfully" });
        })
        .catch((err) => {
          res.status(400).send({ message: "batch write failed" });
        });
    } catch (error) {
      console.error(error);
    }
  });



  router.get("/save2",  async (req, res) => {
    let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
    //Get Data from Parts Table
    let params = {
      TableName: "PartsTable",
      IndexName: "category-index",
      KeyConditionExpression: "#categoryName = :categoryValue",
      ExpressionAttributeNames: {"#categoryName": "category"},
      ExpressionAttributeValues: {":categoryValue": "Cap"},
    };

    AwsDynamodb.queryItem(params)
          .then((data) => {
            //Move it to the Immensa Database 2

         data.Items.forEach(function(element) {
              let val = element;
              val.subcategory =  element.category;
              val.category = "Valves";
              let paramst = {
                TableName: config.aws.dynamodb.tableInfo.PartDatabase,
                Item:val 
            }
          
            AwsDynamodb.putItem(paramst)
                .then((data) => {
                   console.log(data);
                }).catch((err) => {
                  console.log(err);
                });
            });
         

           
         
          })
          .catch((err) => {
            console.log(err);
          });
    



  });


/*
  //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  
  router.get("/saveMaterials",  async (req, res) => {
    try {
      let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");


      
    
      
      MaterialsData.forEach(function(element) {
        let params = {
          TableName: config.aws.dynamodb.tableInfo.MaterialsTable,
          Item: {"id":element,"counterr":"0"},
      }
      AwsDynamodb.putItem(params)
          .then((data) => {
             console.log(data);
          })
          .catch((err) => {
            console.log(err);
          });
      });

  
    } catch (error) {
      console.error(error);
    }
  });


  MaterialsData = [
    "ABS",
    "Aluminium (AlSi10Mg)",
    "Aluminium AlSi10Mg",
    "Carbon Fiber",
    "Cobalt Chrome",
    "Durable Resin",
    "Flexible Resin",
    "Glass Filled PA 12",
    "HDPE",
    "Inconel (IN625)",
    "Inconel (IN718)",
    "Maraging Steel (MS-1)",
    "Nylon",
    "PA 11",
    "PA 12",
    "PEEK",
    "PET-G",
    "PLA",
    "Polycarbonate",
    "Polyurethane",
    "ProHT",
    "Rubber",
    "Stainless Steel (SS 316L)",
    "Teflon",
    "Titanium (Ti6Al4V)",
    "Tough Resin",
    "TPU",
    "Ultem",
    "Cast Iron",
    "C45 material (1.0503 steel)",
    "Brass",
    "Bronze",
    "Duroplast",
    "Unalloyed steel 1.0577",
    "Unalloyed steel 1.1730",
    "Case hardening steel 1.2162",
    "Case hardening steel 1.7131",
    "Toughened steel 1.2311",
    "Toughened steel 1.2312",
    "Toughened steel 1.2714HH",
    "Toughened steel 1.2738",
    "Toughened steel 1.2316",
    "Toughened steel 1.2738TSHH",
    "Steel 1.2083",
    "Steel 1.2083ESU",
    "Steel 1.2085",
    "Steel 1.2316",
    "HSS 1.3344 PM",
    "HSS MV10PM",
    "HSS MW10PM",
    "Duplex SS 2101",
    "Duplex SS 2304",
    "Duplex SS 3304",
    "Duplex SS 2404",
    "Super Duplex 2507",
    "Super Duplex 4501",
    "SS301",
    "SS302",
    "SS303",
    "SS304",
    "SS309",
    "SS321",
    "SS408",
    "SS409",
    "SS410",
    "SS416",
    "SS420",
    "SS430",
    "SS440",
    "Al Alloy - 6082",
    "Al Alloy - 6022",
    "Al Alloy - 6061",
    "Al Alloy - 7075",
    "Al Alloy 356",
    "Al Alloy 355",
    "Al Alloy A354",
    "Al Alloy A356",
    "Al Alloy A357",
    "Al Alloy C355",
    "Al Alloy D712",
    "Al Alloy 1100",
    "Al Alloy 2014",
    "H11 Steel",
    "H13 Steel",
    "Maraging Steel 1.2709",
    "Inconel 718",
    "SS316",
    "SS316L",
    "Stainless Steel PH1",
    "Nickel alloy HX",
    "Stainless Steel 17-4PH",
    "Ti6Al4V Grade 5",
    "Ti6Al4V ELI Grade 23",
    "Aluminium AlSi7Mg",
    "Inconel 738",
  ];*/


  return router;
};
