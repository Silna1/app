const router = require("express").Router();
var ServiceManager = require("../services/SvcManager");
var jwt = require("jsonwebtoken");
const { OAuth2Client } = require("google-auth-library");
var dynamodbUpdateExpression = require("dynamodb-update-expression");
var config = require("c0nfig");
var utils = require('../helpers/utils');

var CLIENT_ID = config.CLIENT_ID;

const client = new OAuth2Client(CLIENT_ID);
module.exports = function () {

  router.post('/authenticateUser', async function (req, res) {
    try {
      let authToken = await utils.createToken(req);
      res.status(200).send({ 'token': authToken });
    } catch (error) {
      res.status(400).send({ 'error': error })
    }
  })
  //   router.post("/refreshtoken", function(req, res) {
  //     let refreshToken = req.body.refreshToken;

  //     jwt.verify(refreshToken, config.refreshTokenKey, (err, authdata) => {
  //       if (authdata == undefined) {
  //         res.status(401).send({ message: "Not Authorized" });
  //       } else {
  //         if (authdata.isRefreshToken) {
  //           createToken(req, res, authdata);
  //         } else {
  //           res.status(400).send({ message: "Please send valid refresh token" });
  //         }
  //       }
  //     });

  //     //let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc')
  //     //let email = req.body.email;

  //     // try {
  //     //     var quaryParams = {
  //     //         TableName: config.aws.dynamodb.tableInfo.UserDataBase,
  //     //         KeyConditionExpression: "#emailAttr = :emailValue",
  //     //         ExpressionAttributeNames: {
  //     //             "#emailAttr": "email"
  //     //         },
  //     //         ExpressionAttributeValues: {
  //     //             ":emailValue": email
  //     //         },
  //     //     };

  //     //     AwsDynamoDb.queryItem(quaryParams)
  //     //         .then((data) => {
  //     //             if (data.Count == 0) {
  //     //                 res.status(400).send({ 'message': 'Not a valid email address' })
  //     //             }
  //     //             else {

  //     //                 if (data.Items[0].refreshToken == refreshToken) {
  //     //                     createToken(req, res, data.Items[0])
  //     //                 }
  //     //                 else {
  //     //                     res.status(400).send({ 'message': 'Refresh Token is not valid' })
  //     //                 }

  //     //             }
  //     //         })
  //     //         .catch(error => console.log(error));

  //     // }
  //     // catch (ex) {
  //     //     res.status(500).send(ex)
  //     // }
  //   });

  router.post("/tokenstatus", function (req, res) {
    try {
      let token = req.body.token;
      let tokenStatus = {
        isTokenExpired: false
      };
      jwt.verify(token, config.tokenKey, (err, authdata) => {
        if (authdata === undefined) {
          tokenStatus.isTokenExpired = true;
        }
        res.status(200).send(tokenStatus);
      });
    } catch (ex) {
      res.status(500).send(ex);
    }
  });

  return router;
};

var updateUserInDatabase = function (profile, quaryParams) {
  let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");

  try {
    return new Promise((resolve, reject) => {
      let updateParams = {
        imageUrl: profile.picture,
        name: profile.name
        //lastName: profile.family_name
      };

      var updateExpression = dynamodbUpdateExpression.getUpdateExpression(
        quaryParams,
        updateParams
      );

      updateExpression.Key = {
        email: profile.email
      };
      updateExpression.TableName = config.aws.dynamodb.tableInfo.UserDataBase;
      updateExpression.ReturnValues = "ALL_NEW";

      AwsDynamoDb.updateItem(updateExpression)
        .then(data => {
          resolve(data);
          //create a token
        })
        .catch((ex) => { //res.status(500).send(ex); 
        });
    });
  } catch (ex) {
    Promise.reject();
  }
};

//create a token and refresh token

var createToken = function (req, res, profile) {
  try {
    let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
    //this query is required to get latest data
    var quaryParams = {
      TableName: config.aws.dynamodb.tableInfo.UserDataBase,
      KeyConditionExpression: "#emailAttr = :emailValue",
      ExpressionAttributeNames: {
        "#emailAttr": "email"
      },
      ExpressionAttributeValues: {
        ":emailValue": profile.email
      }
    };

    AwsDynamoDb.queryItem(quaryParams)
      .then(data => {
        let user = {
          email: data.Items[0].email,
          firstname: data.Items[0].name,
          privilege: data.Items[0].privilege
        };

        let refreshTokenData = {
          email: data.Items[0].email,
          isRefreshToken: true
        };

        const token = jwt.sign(user, config.tokenKey, {
          expiresIn: config.tokenExpireTime
        });
        const refreshToken = jwt.sign(refreshTokenData, config.refreshTokenKey, {
          expiresIn: config.refreshTokenExpireTime
        });

        let updateParams = {
          refreshToken: refreshToken
        };

        let updateExpression = dynamodbUpdateExpression.getUpdateExpression(
          data.Items[0],
          updateParams
        );
        updateExpression.Key = {
          email: profile.email
        };
        updateExpression.TableName = config.aws.dynamodb.tableInfo.UserDataBase;
        updateExpression.ReturnValues = "ALL_NEW";

        //updates the new refresh token in the database.
        AwsDynamoDb.updateItem(updateExpression)
          .then(data => {
            res.status(200).send({
              token: token,
              privilege: data.Attributes.privilege
              //   refreshToken: refreshToken
            });
          })
          .catch(err => {
            res.status(200).send({ message: err.message });
          });
      }).catch(ex => {
        res.status(500).send(ex);
      })
  } catch (ex) {
    res.status(500).send(ex);
  }
};
