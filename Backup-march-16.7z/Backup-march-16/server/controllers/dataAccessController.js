var express = require('express');
var ServiceManager = require('../services/SvcManager');
const uuid = require('uuid/v4');
var config = require('c0nfig')
var dynamodbUpdateExpression = require('dynamodb-update-expression');
var utils = require('../helpers/utils');

module.exports = function () {
    var router = express.Router();

    let AwsDynamodb = ServiceManager.getService('AwsDynamoSvc')

    router.get('/fetch', utils.verificationByToken, async (req, res) => {
        try {
           
            let params = {
                TableName: config.aws.dynamodb.tableInfo.Data_AccessTable,
                FilterExpression: "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "previlegeName"
                },
                ExpressionAttributeValues: {
                    ":value": req.query.previlegeName
                },
            }

            let data = await AwsDynamodb.scanItem(params);
            
            res.status(200).send(data);
        }
        catch (err) {
            res.status(400).send({ 'error': err });
        }
    })

    router.put('/update', utils.verificationByToken, async (req, res) => {
        try {
            let AwsDynamoDb = ServiceManager.getService('AwsDynamoSvc');
            let params = {
                TableName: config.aws.dynamodb.tableInfo.Data_AccessTable,
                KeyConditionExpression:  "#id = :value",
                ExpressionAttributeNames: {
                    "#id": "previlegeName"
                },
                ExpressionAttributeValues: {
                    ":value": req.body.accessData.previlegeName
                }
            }
            const updateParams = req.body.accessData;
            let data = await AwsDynamoDb.queryItem(params);
            if (data.Count !== 0) {
                const queryData = data.Items[0];
                let updateExpression = dynamodbUpdateExpression.getUpdateExpression(queryData, updateParams);
                updateExpression.Key = {
                    previlegeName: req.body.accessData.previlegeName
                }
                updateExpression.TableName = config.aws.dynamodb.tableInfo.Menu_AccessTable
                await AwsDynamoDb.updateItem(updateExpression);
                res.status(200).send({ "message": "Menu data is updated successfully" });
            }
            else {
                res.status(400).send({ "message": "Please provide the required information" });
            }
        } catch (err) {
            res.status(400).send(err);
        }
    })

    router.get('/all',utils.verificationByToken, async (req, res) => {
        console.trace();
        console.log("inside DataAccess all");
        try {
            console.trace();
            console.log("inside DataAccess all");
            let params = {
                TableName: config.aws.dynamodb.tableInfo.Data_AccessTable
            }

            let data = await AwsDynamodb.scanItem(params);
            res.status(200).send(data);
        }
        catch (err) {
            res.status(400).send({ 'error': err });
        }
    })
    

    return router;
}