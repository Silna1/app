var AWS = require("aws-sdk");
var config = require('c0nfig');
var BaseSvc = require('./BaseSvc');

AWS.config.update(config.aws.cognito);

const cognitoServiceProvider = new AWS.CognitoIdentityServiceProvider();

module.exports = class AwsCognitoSvc extends BaseSvc {

    name() {
        return "AwsCognitoSvc";
    }

    listUser(params) {
        try {
            return new Promise((resolve, reject) => {
                cognitoServiceProvider.listUsersInGroup(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(data);
                    }
                });
            })
        }
        catch (ex) {
            throw new Error(ex)
        }
    }

    getUserGroups(params) {
        try {
            return new Promise((resolve, reject) => {
                cognitoServiceProvider.adminListGroupsForUser(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(data);
                    }
                });
            })
        }
        catch (ex) {
            throw new Error(ex)
        }
    }

    updateUser(params) {
        try {
            return new Promise((resolve, reject) => {
                cognitoServiceProvider.adminAddUserToGroup(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(data);
                    }
                });
            })
        }
        catch (ex) {
            throw new Error(ex)
        }
    }

    removePrivilege(params) {
        try {
            return new Promise((resolve, reject) => {
                cognitoServiceProvider.adminRemoveUserFromGroup(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(data);
                    }
                });
            })
        }
        catch (ex) {
            throw new Error(ex)
        }
    }

    createUser(params) {
        try {
            return new Promise((resolve, reject) => {
                cognitoServiceProvider.adminCreateUser(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(data);
                    }
                });
            })
        }
        catch (ex) {
            throw new Error(ex)
        }
    }

    deleteUser(params) {
        return new Promise((resolve, reject) => {
            cognitoServiceProvider.adminDeleteUser(params, function (err, data) {
                if (err) {
                    reject(err);
                } else {
                    resolve(data);
                }
            });
        });
    }

    getClients(params) {
        return new Promise((resolve, reject) => {
            cognitoServiceProvider.listGroups(params, function (err, data) {
                if (err) {
                    reject(err);
                } else {
                    resolve(data);
                }
            });
        });
    }

    updateUserAttributes(params) {
        return new Promise((resolve, reject) => {
            cognitoServiceProvider.adminUpdateUserAttributes(params, function (err, data) {
                if (err) {
                    reject(err);
                } else {
                    resolve(data);
                }
            });
        });
    }

    createGroup(params) {
        try {
            return new Promise((resolve, reject) => {
                cognitoServiceProvider.createGroup(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(data);
                    }
                });
            })
        }
        catch (ex) {
            throw new Error(ex)
        }
    }
}