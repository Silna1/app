var AWS = require("aws-sdk");
var config = require('c0nfig');
var BaseSvc = require('./BaseSvc');

module.exports = class AwsEmailSvc extends BaseSvc {

    constructor() {
        super();
        AWS.config = config.aws.ses;
        this.ses = new AWS.SES({ apiVersion: "2010-12-01" });
    }


    name() {
        return "AwsEmailSvc";
    }

    sendEmail(params) {
        try {
            return new Promise((resolve, reject) => {
                this.ses.sendEmail(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(data);
                    }
                })
            }).catch(err => {
                new Promise((resolve, reject) => {
                    console.log("errorMessage", err.message);
                    reject(err);
                });
            })
        } catch (ex) {
            console.log("ex", ex);
        }
    }

    verifyEmail(email) {
        try {
            return new Promise((resolve, reject) => {
                this.ses.verifyEmailIdentity(email, function (err, data) {
                    if (err) {
                        console.log("verification failed");
                        reject(err);
                    } else {
                        console.log("verification mail send");
                        resolve(data);
                    }
                })
            }).catch(err => {
                new Promise((resolve, reject) => {
                    console.log("errorMessage", err.message);
                    reject(err);
                });
            })
        } catch (ex) {
            reject(err);
            console.log("ex", ex);
        }

    }

    sendTemplateEmail(params) {
        try {
            return new Promise((resolve, reject) => {
                this.ses.sendTemplatedEmail(params, function (err, data) {
                    if (err) {
                        reject(err, err.stack);
                    } else {
                        resolve(data);
                    }
                })
            })
        } catch (ex) {
            console.log(ex);
            throw new Error(ex);
        }
    }


    createTemplate(params) {
        try {
            return new Promise((resolve, reject) => {
                this.ses.createTemplate(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(data);
                    }
                })
            })
        } catch (ex) {
            console.log(ex);
            throw new Error(ex);
        }
    }

    createCustomverificationTemplate(params) {
        return new Promise((resolve, reject) => {
            this.ses.createCustomVerificationEmailTemplate(params, function (err, data) {
                if (err) {
                    reject(err);
                } else {
                    resolve(data);
                }
            })
        })
    }

    sendVerificationEmail(params) {
        return new Promise((resolve, reject) => {
            this.ses.sendCustomVerificationEmail(params, function (err, data) {
                if (err) {
                    reject(err);
                } else {
                    resolve(data);
                }
            })
        })
    }

}



