var AWS = require('aws-sdk');
var fs = require('fs-extra');
var path = require('path');
var https = require('https');
var config = require('c0nfig')
var BaseSvc = require('./BaseSvc');
var mkdirp = require('mkdirp');

module.exports = class AwsS3Svc extends BaseSvc {

    /////////////////////////////////////////////////////////////////
    // constructor
    /////////////////////////////////////////////////////////////////
    constructor() {
        super();
        let agent = new https.Agent({});

        // Load aws configurations.
        AWS.config = config.aws.s3;
        AWS.config.httpOptions = {
            agent: agent
        };

        this.components = [];
        this.referenceDrawings = [];
        // initialize aws s3.
        this.s3 = new AWS.S3();
        // set bucket name which will be used for all aws s3 operations.
        // this.bucket = 'cctech-research';
        this.bucket = config.aws.s3.params.Bucket;
        this.s3DataContents = [];

        console.log(this.bucket + ' initialised !!!');

    }

    /////////////////////////////////////////////////////////////////
    // service name
    /////////////////////////////////////////////////////////////////
    name() {
        return 'AwsS3Svc';
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    // @param  'String'
    // params = prefix - 'folderName/' on aws s3 where you want to perform list objects.
    //
    // @returns list of all objects inside prefix(folder).
    /////////////////////////////////////////////////////////////////////////////////////////
    listObjects(prefix, bucketKey) {
        let params = {
            Bucket: bucketKey,
            Prefix: prefix + "/",
            MaxKeys: 50
        };

        return new Promise(async (resolve, reject) => {
            try {
                this.s3.listObjects(params, function (err, data) {
                    if (err) console.log(err, err.stack); // an error occurred
                    else {
                        resolve(data);
                    }
                });
            } catch (ex) {
                console.log('ex : ', ex);
                reject(ex);
            }
        });
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    // @param  'object'
    // params = {
    //      content: 'can be file path on server or json content' , 
    //      name: 'file will be stored with this name on aws s3.',
    //      projectName: 'perticular project folder name (for folder structure) on aws s3.',
    //      res : 'responce while uploading JSON'
    // }
    //
    // @returns 'SignedUrl after successful upload'
    /////////////////////////////////////////////////////////////////////////////////////////

    uploadFile(params) {
        return new Promise(async (resolve, reject) => {

            try {
                let uploadParams = { Bucket: this.bucket, Key: '', Body: '' };
                if (params.bucketName)
                    uploadParams.Bucket = params.bucketName;

                // Check if its a file or json
                let fileContent;
                try {
                    JSON.parse(params.content);
                    fileContent = params.content;
                    console.log('!!! content is Json');
                } catch (e) {
                    //console.log('!!! Uploading content is NOT Json.');
                    if (typeof params.content === 'object') {
                        fileContent = params.content;
                    } else {
                        fileContent = fs.createReadStream(params.content);
                        fileContent.on('error', function (err) {
                            console.log('!!! File Error', err);
                        });
                    }
                }

                uploadParams.Body = fileContent;

                if (params.projectName === '') {
                    uploadParams.Key = path.basename(params.name);
                }
                else {
                    uploadParams.Key = params.projectName + '/' + path.basename(params.name);
                }

                // call S3 to upload file to specified bucket
                this.s3.upload(uploadParams, function (err, data) {
                    if (err) {
                        console.log('Error', err);
                    } else if (data) {
                        //console.log('AWSS3 Upload Success', data.Key);
                        let signedUrl = this.getSignedUrlForFile(data.Key);
                        //console.log('signedUrl : ', signedUrl);

                        // If params have responce object then send the responce else resolve it to our promise
                        try {
                            // console.log('@@@ Responding');
                            params.res.send(signedUrl);
                        }
                        catch (e) {
                            // console.log('@@@ Resolving');
                            data.signedUrl = signedUrl;
                            resolve(data);
                        }
                    }
                }.bind(this));
            } catch (ex) {
                console.log('ex : ', ex);
                reject(ex)
            }
        });
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    // @param  'string'
    // fileKey = 'file or folder path excluding bucket name eg.-> 'someProjectFolder/some.dwg' '
    //
    // @returns respose object { DeleteMarker: true or false, VersionId: 'ytlpV8x04XfCjsI5Ws1pQ0txNRXih9OX' }
    /////////////////////////////////////////////////////////////////////////////////////////
    deleteFile(objectKey, bucketName = this.bucket) {

        return new Promise(async (resolve, reject) => {

            try {
                let params = {
                    Bucket: this.bucket,
                    Key: objectKey
                };
                if (bucketName)
                    params.Bucket = bucketName;
                this.s3.deleteObject(params, function (err, data) {
                    if (err) console.log(err, err.stack); // an error occurred
                    else console.log(data);           // successful response
                    resolve(data);           // successful response
                });

            } catch (ex) {
                reject(ex)
            }
        });

    }

    deleteFolder(folderKey, bucketKey) {
        return new Promise(async (resolve, reject) => {
            try {
                if (folderKey.startsWith('/')) {
                    folderKey = folderKey.substr(1);
                }
                console.log('List Objects for folder Key : ', folderKey, folderKey.startsWith('/'));
                let list = await this.listObjects(folderKey, bucketKey);
                if (list.Contents.length !== 0) {
                    let deletParams = { Bucket: bucketKey };
                    deletParams.Delete = { Objects: [] };

                    list.Contents.forEach(function (content) {
                        deletParams.Delete.Objects.push({ Key: content.Key });
                    });
                    this.s3.deleteObjects(deletParams, function (error, dataResult) {
                        if (error) {
                            reject(error);
                        } else {
                            resolve(dataResult);
                        }
                    });
                } else {
                    resolve();
                }
            } catch (error) {
                reject(error);
            }
        });
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    // @param  'string'
    // fileKey = 'full file path excluding bucket name eg.-> 'someProjectFolder/some.dwg' '
    //
    // @returns 'requested file's Url which will be live for 1 min.'
    // In case you want to change the life of Url modify 'Expires' in params obj.
    /////////////////////////////////////////////////////////////////////////////////////////
    getSignedUrlForFile(fileKey, bucketName = this.bucket) {
        try {
            // console.log('getting SignedUrl...');
            let params = {
                Bucket: this.bucket,
                Key: fileKey,
                Expires: 60 * 60 * 4 // expires in 4 hour 
            };
            if (bucketName)
                params.Bucket = bucketName;
            let url = this.s3.getSignedUrl('getObject', params);

            // console.log('url : ', url);
            return url;

        } catch (ex) {
            console.log(ex.message);
        }

    }

    getSignedUrlForFileMultipleFiles(fileKeyArray, bucketName = this.bucket) {
        return new Promise((resolve) => {
            try {
                let params = {
                    Bucket: this.bucket,
                    Expires: 150
                };

                let url; //= this.s3.getSignedUrl('getObject', params);
                let multipleSignedUrls = []

                fileKeyArray.forEach((element, index) => {
                    params.Key = element;
                    url = this.s3.getSignedUrl('getObject', params);
                    multipleSignedUrls.push(url);

                    if (fileKeyArray.length - 1 === index) {
                        resolve(multipleSignedUrls)
                    }
                })

            } catch (ex) {
                console.log(ex.message);
            }
        })

    }

    /////////////////////////////////////////////////////////////////////////////////////////
    // @param  'String'
    // params = fileKey - object key for which we want to peform get object
    // eg. - 'folderName/text.txt' is object key for text.txt file object on AWS S3.
    //
    // @returns object URL and some data related to object ( check AWS S3 
    // documentation for more ).
    /////////////////////////////////////////////////////////////////////////////////////////
    getObject(fileKey) {
        let params = {
            Bucket: this.bucket,
            Key: fileKey
        };
        return this.s3.getObject(params, function (err, data) {
            if (err) console.log(err, err.stack); // an error occurred
            else return data;           // successful response
        });
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    // @param None
    //
    // @returns Componets manifest, metadata, f2d and png file keys.
    /////////////////////////////////////////////////////////////////////////////////////////
    getComponents() {
        return this.components;
    }

    /////////////////////////////////////////////////////////////////////////////////////////
    // Ensures the directory exists.
    // @param  'String'
    // params = filePath - Server file or directory path
    //
    // @returns None
    /////////////////////////////////////////////////////////////////////////////////////////
    ensureDirectoryExistence(filePath) {
        let dirname = path.dirname(filePath);
        if (fs.existsSync(dirname)) {
            return true;
        }
        this.ensureDirectoryExistence(dirname);
        fs.mkdirSync(dirname);
    }

    uploadDir(files, uid) {
        let uploadedS3Images = [];
        let checkForLastuploadedFile = 0;
        let _self = this;
        return new Promise((resolve, reject) => {
            try {
                files.forEach(async (item, index) => {
                    let uploadFileParams = {
                        content: item.file,
                        name: item.s3Key,
                        projectName: 'partsdata/' + uid,
                    };

                    //we can use async await here.
                    let data = await _self.uploadFile(uploadFileParams)
                    uploadedS3Images.push(data.Key);
                    if (files.length - 1 === checkForLastuploadedFile) {
                        resolve(uploadedS3Images);
                    }
                    else {
                        checkForLastuploadedFile++;
                    }
                });
            }
            catch (error) {
                reject(error);
            }
        })
    }

    /////////////////////////////////////////////////////////
    // Create directory async
    //
    /////////////////////////////////////////////////////////
    mkdirpAsync(dir) {

        return new Promise((resolve, reject) => {
            mkdirp(dir, (error) => {
                return error
                    ? reject(error)
                    : resolve()
            })
        })
    }

    checkIfObjectExists(fileKey) {
        return new Promise(async (resolve, reject) => {
            try {
                let params = {
                    Bucket: this.bucket,
                    Key: fileKey
                };
                return this.s3.headObject(params, function (err, data) {
                    if (err)
                        resolve({ err: true });
                    else
                        resolve({ err: false, data: data });           // successful response
                });
            } catch (ex) {
                console.log('checkIfObjectExists exception : ', ex);
            }
        });
    }

    s3ListObjects(params, cb) {
        var that = this;
        this.s3.listObjects(params, function (err, data) {
            if (err) {
                console.log("listS3Objects Error:", err);
            } else {
                var contents = data.Contents;
                that.s3DataContents = that.s3DataContents.concat(contents);
                if (data.IsTruncated) {
                    // Set Marker to last returned key
                    params.Marker = contents[contents.length - 1].Key;
                    that.s3ListObjects(params, cb);
                } else {
                    cb(that.s3DataContents, that.s3, that.bucket);
                }
            }
        });
    }
}