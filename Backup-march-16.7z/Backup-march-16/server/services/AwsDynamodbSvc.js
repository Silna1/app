var AWS = require("aws-sdk");
var config = require('c0nfig');
var BaseSvc = require('./BaseSvc');

AWS.config.update(config.aws.dynamodb.credentials);
let docClient = new AWS.DynamoDB.DocumentClient();
//describe table works with AWS.DynamoDB instance
let docClientDB = new AWS.DynamoDB();

module.exports = class AwsDynamodbSvc extends BaseSvc {

    name() {
        return "AwsDynamoSvc"
    }

    describe(params) {
        return new Promise((resolve, reject) => {
            docClientDB.describeTable(params, function (err, data) {
                if (err) {
                    reject(err);
                } else {
                    resolve(data);
                }
            })
        })
    }

    getItem(params) {
        try {
            return new Promise((resolve, reject) => {
                docClient.get(params, function (err, data) {
                    if (err) {
                        reject(err)
                    } else {
                        resolve(data);
                    }
                })
            })
        }
        catch (ex) {
            throw new Error(ex)
        }
    }

    putItem(params) {
        try {
            return new Promise((resolve, reject) => {
                docClient.put(params, function (err, data) {
                    if (err) {
                        console.dir(err);
                        console.dir(data);
                        reject(err);
                    } else {

                        resolve(data);
                    }
                })
            })
        }
        catch (ex) {
            throw new Error(ex)
        }

    }

    updateItem(params) {
        try {
            return new Promise((resolve, reject) => {
                docClient.update(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(data);
                    }
                })
            })
        }
        catch (ex) {
            throw new Error(ex)
        }
    }

    deleteItem(params) {
        try {
            return new Promise((resolve, reject) => {
                docClient.delete(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(data);
                    }
                })
            })
        }
        catch (ex) {
            throw new Error(ex)
        }
    }

    queryItem(params) {
        return new Promise((resolve, reject) => {
            docClient.query(params, function (err, data) {
                if (err) {
                    reject(err);
                } else {
                    resolve(data);
                }
            })
        })
    }

    batchGetItem(params) {
        return new Promise((resolve, reject) => {
            docClient.batchGet(params, function (err, data) {
                if (err) {
                    reject(err);
                } else {
                    resolve(data.Responses[config.aws.dynamodb.tableInfo.PartDatabase]);
                }
            })
        })
    }

    batchWrite(config, items) {
        try {
            var itemsToWrite = [];
            for (const item of items) {
                itemsToWrite.push({
                    PutRequest: {
                        Item: item
                    }
                });
            }

            var params = {
                RequestItems: {}
            };
            params.RequestItems[config.TableName] = itemsToWrite;
            return new Promise((resolve, reject) => {
                docClient.batchWrite(params, function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        resolve(data);
                    }
                })
            })
        }
        catch (ex) {
            throw new Error(ex)
        }
    }

    scanItemCats(params, callback) {
        docClient.scan(params, callback);
    }
    
    scanItem(params) {
        return new Promise((resolve, reject) => {
            docClient.scan(params, function (error, data) {
                if (error) {
                    reject(error);
                } else {
                    resolve(data);
                }
            });
        })
    }
}




