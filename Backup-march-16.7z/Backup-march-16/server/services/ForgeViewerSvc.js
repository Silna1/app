'use strict';
var config = require('c0nfig');
var BaseSvc = require('./BaseSvc');
const fs = require('fs');
const { BucketsApi,
    ObjectsApi,
    PostBucketsPayload,
    AuthClientTwoLegged,
    DerivativesApi,
    JobPayload,
    JobPayloadInput,
    JobPayloadOutput,
    JobSvfOutputPayload
} = require('forge-apis');

module.exports = class ForgeViewerSvc extends BaseSvc {
    
    name() {
        return 'ForgeViewerSvc';
    }

    getToken(scopes) {
        return new Promise(async (resolve, reject) => {
            try {
                let client = this.getClient(scopes);
                let credential = await client.authenticate();
                let data = {
                    token: credential,
                    client: client
                }
                resolve(data);
            } catch (error) {
                reject(error);
            }
        })
    }

    getClient(scopes) {
        try {
            const { CLIENT_ID, CLIENT_SECRET } = config.forge.credentials;
            return new AuthClientTwoLegged(CLIENT_ID, CLIENT_SECRET, scopes || config.forge.scopes.internal);
        } catch (error) {
            throw error;
        }
    }

    getPublicToken() {
        return new Promise((resolve, reject) => {
            this.getToken(config.forge.scopes.public)
                .then((data) => {
                    resolve(data);
                })
                .catch((error) => {
                    reject(error);
                });
        });
    }

    getInternalToken() {
        return new Promise((resolve, reject) => {
            this.getToken(config.forge.scopes.internal)
                .then((data) => {
                    resolve(data);
                })
                .catch((error) => {
                    reject(error);
                });
        });

    }

    createbucket() {
        return new Promise(async (resolve, reject) => {
            try {
                let payload = new PostBucketsPayload();
                payload.bucketKey = config.forge.bucketkey;
                payload.policyKey = config.forge.bucketpolicy.Persistent;
                let authData = await this.getInternalToken();
                await new BucketsApi().createBucket(payload, {}, authData.client, authData.token);
                resolve();
            } catch (error) {
                reject(error);
            }
        })
    }

    getBucketList() {
        return new Promise(async (resolve, reject) => {
            try {
                let authData = await this.getInternalToken();
                const buckets = await new BucketsApi().getBuckets({ limit: config.forge.bucketlimit }, authData.client, authData.token);
                resolve(buckets);
            } catch (error) {
                reject(error);
            }
        })
    }

    getFilesFromBucket() {
        return new Promise(async (resolve, reject) => {
            try {
                let authData = await this.getInternalToken();
                const objects = await new ObjectsApi().getObjects(config.forge.bucketkey, {}, authData.client, authData.token);
                resolve(objects);
            } catch (error) {
                reject(error);
            }
        })
    }

    translateFile(urn) {
        return new Promise(async (resolve, reject) => {
            try {
                let job = new JobPayload();
                job.input = new JobPayloadInput();
                job.input.urn = urn;
                job.output = new JobPayloadOutput([
                    new JobSvfOutputPayload()
                ]);
                job.output.formats[0].type = "svf";
                job.output.formats[0].views = ['2d', '3d'];
                let authData = await this.getInternalToken();
                let obj = await new DerivativesApi().translate(job, {}, authData.client, authData.token);
                resolve(obj);
            } catch (error) {
                reject(error);
            }
        })
    }

    uploadFile(fileName, filePath) {
        return new Promise((resolve, reject) => {
            try {
                fs.readFile(filePath, async (err, data) => {
                    if (err) {
                        reject(err);
                    }
                    let authData = await this.getInternalToken();
                    let obj = await new ObjectsApi().uploadObject(config.forge.bucketkey, fileName, data.length, data, {}, authData.client, authData.token);
                    resolve(obj);
                });
            } catch (error) {
                reject(error);
            }
        });
    }

    getTranslationProgress(urn) {
        return new Promise(async (resolve, reject) => {
            try {
                let authData = await this.getInternalToken();
                let obj = await new DerivativesApi().getManifest(urn, {}, authData.client, authData.token);
                resolve(obj);
            } catch (error) {
                reject(error);
            }
        });
    }
}
