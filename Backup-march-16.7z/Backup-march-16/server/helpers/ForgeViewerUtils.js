var ServiceManager = require('../services/SvcManager');
var config = require('c0nfig');
var crypto = require("crypto");
var path = require("path");

module.exports = {
    ViewerExtensionList: [".obj", ".stl", ".sldprt", ".sldasm", ".3ds", ".fbx"]
}

module.exports.uploadAndTranslateFile = function (fileName, viewerFile) {
    return new Promise(async (resolve, reject) => {
        try {
            let ForgeViewerSvc = ServiceManager.getService('ForgeViewerSvc');
            if (viewerFile.length > 0) {
                var file = await ForgeViewerSvc.uploadFile(fileName, viewerFile);
                let urn = Buffer.from(file.body.objectId).toString('base64');

                // translate the file to svf
                let tranlatedFile = await ForgeViewerSvc.translateFile(urn);
                resolve(tranlatedFile.body.urn);
            }
        } catch (error) {
            reject(error);
        }
    })
}

module.exports.uploadViewerFileToS3 = function (uploadFileList, uid) {
    return new Promise(async (resolve, reject) => {
        try {
            let AwsS3Svc = ServiceManager.getService('AwsS3Svc');
            let viewerFilesData = [];

            // need to do for multiple files uploads
            if (uploadFileList !== undefined) {
                for (let file of uploadFileList) {
                    let randomText = crypto.randomBytes(5).toString("hex");
                    let s3Key = randomText + path.extname(file);
                    viewerFilesData.push({ file: file, s3Key: s3Key });
                }

                let folderViewer = "partsdata_Viewer";
                let uploadViewerFileParams = {
                    content: viewerFilesData[0].file,
                    name: viewerFilesData[0].s3Key,
                    projectName: folderViewer + '/' + uid,
                    bucketName: config.aws.s3.params.Data_Bucket
                };

                await AwsS3Svc.uploadFile(uploadViewerFileParams);
                resolve({
                    key: uploadViewerFileParams.name
                });
            }
        } catch (error) {
            reject(error);
        }
    })
}

module.exports.deleteViewerFileFromS3 = function (uid) {
    return new Promise(async (resolve, reject) => {
        try {
            let AwsS3Svc = ServiceManager.getService('AwsS3Svc');
            let folderViewer = "partsdata_Viewer";
            let prefix = folderViewer + '/' + uid;
            let bucketName = config.aws.s3.params.Data_Bucket;
            await AwsS3Svc.deleteFolder(prefix, bucketName);
            resolve();
        } catch (error) {
            reject(error);
        }
    })
}

module.exports.downloadFileFromS3 = function (uid, fileName) {
    return new Promise(async (resolve, reject) => {
        try {
            let AwsS3Svc = ServiceManager.getService('AwsS3Svc');
            let bucketName = config.aws.s3.params.Data_Bucket;
            let folderViewer = "partsdata_Viewer";
            let filekey = folderViewer + "/" + uid + "/" + fileName;
            let url = AwsS3Svc.getSignedUrlForFile(filekey, bucketName);
            resolve(url);
        } catch (error) {
            reject(error);
        }
    })
}

