var formidable = require("formidable");
const uuid = require("uuid/v4");
var ServiceManager = require("../services/SvcManager");
var config = require("c0nfig");
var forgeUtils = require("./ForgeViewerUtils");
var utils = require("./utils");
var fs = require("fs-extra");
var crypto = require("crypto");
var path = require("path");
var https = require("https");

module.exports = {
  Materials: [
    "ABS",
    "Aluminium (AlSi10Mg)",
    // "Aluminium AlSi10Mg",
    "Carbon Fiber",
    "Cobalt Chrome",
    "Durable Resin",
    "Flexible Resin",
    "Glass Filled PA 12",
    "HDPE",
    "Inconel (IN625)",
    "Inconel (IN718)",
    "Maraging Steel (MS-1)",
    "Nylon",
    "PA 11",
    "PA 12",
    "PEEK",
    "PET-G",
    "PLA",
    "Polycarbonate",
    "Polyurethane",
    "ProHT",
    "Rubber",
    "Stainless Steel (SS 316L)",
    "Teflon",
    "Titanium (Ti6Al4V)",
    "Tough Resin",
    "TPU",
    "Ultem",
    "Cast Iron",
    "C45 material (1.0503 steel)",
    "Brass",
    "Bronze",
    "Duroplast",
    "Unalloyed steel 1.0577",
    "Unalloyed steel 1.1730",
    "Case hardening steel 1.2162",
    "Case hardening steel 1.7131",
    "Toughened steel 1.2311",
    "Toughened steel 1.2312",
    "Toughened steel 1.2714HH",
    "Toughened steel 1.2738",
    "Toughened steel 1.2316",
    "Toughened steel 1.2738TSHH",
    "Steel 1.2083",
    "Steel 1.2083ESU",
    "Steel 1.2085",
    "Steel 1.2316",
    "HSS 1.3344 PM",
    "HSS MV10PM",
    "HSS MW10PM",
    "Duplex SS 2101",
    "Duplex SS 2304",
    "Duplex SS 3304",
    "Duplex SS 2404",
    "Super Duplex 2507",
    "Super Duplex 4501",
    "SS301",
    "SS302",
    "SS303",
    "SS304",
    "SS309",
    "SS321",
    "SS408",
    "SS409",
    "SS410",
    "SS416",
    "SS420",
    "SS430",
    "SS440",
    "Al Alloy - 6082",
    "Al Alloy - 6022",
    "Al Alloy - 6061",
    "Al Alloy - 7075",
    "Al Alloy 356",
    "Al Alloy 355",
    "Al Alloy A354",
    "Al Alloy A356",
    "Al Alloy A357",
    "Al Alloy C355",
    "Al Alloy D712",
    "Al Alloy 1100",
    "Al Alloy 2014",
    "H11 Steel",
    "H13 Steel",
    "Maraging Steel 1.2709",
    "Inconel 718",
    "SS316",
    "SS316L",
    "Stainless Steel PH1",
    "Nickel alloy HX",
    "Stainless Steel 17-4PH",
    "Ti6Al4V Grade 5",
    "Ti6Al4V ELI Grade 23",
    "Aluminium AlSi7Mg",
    "Inconel 738",
  ],

  FormParams: [
    "name",
    "number",
    "description",
    "length",
    "breadth",
    "height",
    "material",
    "complexity",
    "category",
    "email",
    "organization",
    "sellingprice",
    "costprice",
  ],

  ImageExtension: [".jpg", ".jpeg", ".png", ".bmp", ".zip"], // .zip added for batch upload
};

module.exports.uploadFileParamsPromise = function (req) {
  let formidableForm = new formidable.IncomingForm();
  formidableForm.keepExtensions = true;
  formidableForm.maxFileSize = 2048 * 1024 * 1024;
  formidableForm.multiples = true;
  return new Promise(async (resolve, reject) => {
    formidableForm.parse(req, function (err, fields, files) {
      function removeEmptyStringElements(obj) {
        for (var prop in obj) {
          if (typeof obj[prop] === "object") {
            // dive deeper in
            removeEmptyStringElements(obj[prop]);
          } else if (obj[prop] === "") {
            // delete elements that are empty strings
            delete obj[prop];
          }
        }
        return obj;
      }
      removeEmptyStringElements(fields);
      let uid;
      if (fields.id !== undefined) {
        uid = fields.id;
      } else {
        uid = uuid();
        uid = uid.replace(/-/g, "");
      }

      let parsedFormData = {
        uid: uid,
        fields: fields,
        files: files,
      };
      resolve(parsedFormData);
    });
  });
};

module.exports.getUploadFilesArray = function (fileObj) {
  let UploadImagesArray = [];
  let UploadViewerFilesArray = [];
  let FileObject = {};
  let fileObjKeysArray = Object.keys(fileObj);
  return new Promise((resolve, reject) => {
    if (fileObjKeysArray.length === 0) {
      resolve();
    }

    fileObjKeysArray.forEach((element, index) => {
      let ext = "." + fileObj[element].path.split(".")[1].toLowerCase();
      if (forgeUtils.ViewerExtensionList.includes(ext))
        UploadViewerFilesArray.push(fileObj[element].path);
      else if (this.ImageExtension.includes(ext))
        UploadImagesArray.push(fileObj[element].path);
    });
    FileObject = {
      Images: UploadImagesArray,
      ViewerFile: UploadViewerFilesArray,
    };
    resolve(FileObject);
  });
};

module.exports.getUpload3dFilesArray = function (fileObj) {
  let UploadViewerFilesArray = [];
  let FileObject = {};
  let fileObjKeysArray = Object.keys(fileObj);
  return new Promise((resolve, reject) => {
    if (fileObjKeysArray.length === 0) {
      resolve();
    }

    fileObjKeysArray.forEach((element, index) => {
      let ext = "." + fileObj[element].path.split(".")[1].toLowerCase();
      if (forgeUtils.ViewerExtensionList.includes(ext)) {
        let fileData = {
          name: fileObj[element].name,
          path: fileObj[element].path,
        };
        UploadViewerFilesArray.push(fileData);
      }
    });

    FileObject = {
      ViewerFile: UploadViewerFilesArray,
    };
    resolve(FileObject);
  });
};

/**
 * Refer below links for printability score calculation, you will need access to these documents
 * https://docs.google.com/spreadsheets/d/1sPYSSh0Lb7RhQ63ncIKhWqLXigNlXtRkrkNFFn2_Hac/edit?ts=5d53d6e1#gid=0
 * https://docs.google.com/document/d/15pKd1dDxtPy8L2_rlXHP4ZwJix_XaQkxzfaJlDV5gi4/edit?ts=5d53d68f
 */
module.exports.getPrintabilityScore = function (params) {
  try {
    return new Promise((resolve, reject) => {
      let Obj;
      let material = params.material;
      let size = params.size;
      let complexity = params.complexity;

      let score = 5; //presume that any component will have some possibility of printing
      score += (10 - complexity) * 2;

      let SLA = {
        materials: ["Tough Resin", "Flexible Resin", "Durable Resin"],
        machineUsed: ["formlabsform2+"],
        volume: [{ length: 145, breadth: 145, height: 175 }],
      };
      let SLS = {
        materials: ["PA 11", "PA 12", "Glass Filled PA 12"],
        machineUsed: ["EOS P396"],
        volume: [{ length: 320, breadth: 320, height: 600 }],
      };
      let DMLS = {
        materials: [
          // "Titanium (Ti6Al4V)",
          // "Aluminium (AlSi10Mg)",
          // "Stainless Steel (SS 316L)",
          "Stainless Steel (17-4 PH)",
          "Maraging Steel (MS-1)",
          "Inconel (IN625)",
          // "Inconel (IN718)",
          "Cobalt Chrome",
        ],
        machineUsed: ["EOS M 290", "EOS M 300-4", "EOS M 400"],
        volume: [
          { length: 250, breadth: 250, height: 325 },
          { length: 300, breadth: 300, height: 400 },
          { length: 400, breadth: 400, height: 400 },
        ],
      };
      let FDM = {
        materials: [
          "PLA",
          "ABS",
          "Polycarbonate",
          "Nylon",
          "TPU",
          "PET-G",
          "PEEK",
          "Ultem",
          "Carbon Fiber",
        ],
        machineUsed: ["BIG rep one", "Builder extreme 1000", "Ultimaker 3"],
        volume: [
          { length: 1000, breadth: 1000, height: 1000 },
          { length: 700, breadth: 700, height: 700 },
          { length: 200, breadth: 200, height: 300 },
        ],
      };
      let VC = {
        materials: ["Rubber", "HDPE", "Polyurethane", "Teflon"],
        machineUsed: ["Vacum casting machine"],
        volume: [{ length: 500, breadth: 500, height: 500 }],
      };

      if (SLA.materials.indexOf(material) >= 0) {
        Obj = { ...SLA };
      } else if (SLS.materials.indexOf(material) >= 0) {
        Obj = { ...SLS };
      } else if (DMLS.materials.indexOf(material) >= 0) {
        Obj = { ...DMLS };
      } else if (FDM.materials.indexOf(material) >= 0) {
        Obj = { ...FDM };
      } else if (VC.materials.indexOf(material) >= 0) {
        Obj = { ...VC };
      }

      if (Obj && Obj.materials.indexOf(material) !== -1) {
        score += 20;
        let setArr = Obj.volume;
        if (setArr.length > 1) {
          setArr.sort(function (a, b) {
            return a.length - b.length;
          });
        }

        //https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/every
        setArr.every((ele) => {
          if (
            size.length <= ele.length &&
            size.breadth <= ele.breadth &&
            size.height <= ele.height
          ) {
            score += 20;
            return false;
          }
          return true;
        });
      }
      if (
        (material === "ABS" ||
          material === "Nylon" ||
          material === "Polycarbonate") &&
        (size.length > 200 || (size.breadth > 200 && size.height > 300))
      ) {
        score = 0;
      }

      if (
        material === "PET-G" &&
        (size.length > 1000 || (size.breadth > 1000 && size.height > 1000))
      ) {
        score = 0;
      }

      resolve(score);
    });
  } catch (error) {
    Promise.reject(error);
  }
};

module.exports.getS3KeysToRemoveArray = function (updateParamsFields) {
  let updateParamsKeys = Object.keys(updateParamsFields);
  let s3KeysToRemove = [];

  return new Promise((resolve, reject) => {
    updateParamsKeys.forEach((element, index) => {
      if (element.includes("removeS3key")) {
        s3KeysToRemove.push(updateParamsFields[element]);
        delete updateParamsFields[element];
      }
      if (updateParamsKeys.length - 1 == index) {
        resolve({
          s3KeysToRemove: s3KeysToRemove,
          newUpdatedParams: updateParamsFields,
        });
      }
    });
  });
};

module.exports.getSignedUrlForMultipleKeys = function (data) {
  let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
  data.Items[0].signedUrls = [];
  let tempSignedUrl;

  //NOTE : Below code is for old data support when we were not having compressed data.
  let s3Keys = data.Items[0].s3Key;
  let compressedImages = data.Items[0].imagesData;
  let compressedImagesNew = data.Items[0].imagesPath;
  let imagesPath = s3Keys;
  let bucket = config.aws.s3.params.Bucket;
  if (compressedImages) {
    bucket = config.aws.s3.params.Data_Bucket;
    imagesPath = compressedImages.Medium;
  }
  if (compressedImagesNew) {
    bucket = config.aws.s3.params.Data_Bucket;
    imagesPath = compressedImagesNew;
  }

  return new Promise((resolve, reject) => {
    if (imagesPath !== undefined) {
      for (let i = 0; i <= imagesPath.length - 1; i++) {
        let path;
        let folder = "partsdata_Medium";
        if (compressedImages || compressedImagesNew)
          path = folder + "/" + data.Items[0].id + "/" + imagesPath[i];
        else path = imagesPath[i];
        tempSignedUrl = AwsS3Svc.getSignedUrlForFile(path, bucket);
        data.Items[0].signedUrls.push({
          url: tempSignedUrl,
          s3Key: path,
        });
        if (i === data.Items.length - 1) {
          resolve(data);
        }
      }
    } else {
      resolve(data);
    }
  });
};

module.exports.validateEntries = function (partsData, projectNames) {
  let data = {
    message: "",
    status: false,
  };

  for (const entry in partsData) {
    if (this.FormParams.includes(entry.toLowerCase().trim())) {
      if (isEmpty(partsData[entry])) {
        data.message = "Empty params :" + entry;
        return data;
      }
    } else {
      let entity = entry.toLowerCase().trim();
      if (entity === "notes" || entity === "user") continue;

      data.message = "Entity not found : " + entry;
      return data;
    }
  }

  let partName = partsData.name !== undefined ? partsData.name : partsData.Name;
  if (projectNames.includes(partName)) {
    data.message = "Same name exist ";
    return data;
  }

  let partMaterial =
    partsData.material !== undefined ? partsData.material : partsData.Material;
  if (!this.Materials.includes(partMaterial)) {
    data.message = "Material not match :" + partMaterial;
    return data;
  }

  let complexity =
    partsData.complexity !== undefined
      ? partsData.complexity
      : partsData.Complexity;
  complexity = Number(complexity);
  if (complexity <= 0 && complexity >= 10) {
    data.message = " Invalid Complexity :" + complexity;
    return data;
  }

  data.status = true;
  return data;
};

module.exports.uploadImages = async function (filesPathObject, uid) {
  try {
    let imagesData = [];
    if (filesPathObject && filesPathObject["Images"] != undefined) {
      let AwsS3Svc = ServiceManager.getService("AwsS3Svc");
      //upload file to S3, need to implement logic for multiple file upload
      let data;
      let filesData = [];

      for (let file of filesPathObject["Images"]) {
        let randomText = crypto.randomBytes(5).toString("hex");
        let s3Key = randomText + path.extname(file);
        let extname = path.extname(file).toLowerCase();
        if (this.ImageExtension.includes(extname))
          filesData.push({ file: file, s3Key: s3Key });
      }

      if (filesData.length > 0) data = await AwsS3Svc.uploadDir(filesData, uid);

      //upload form data to dynamodb
      //TO DO partsData object needs to be changed, need to put validations on it.
      for (let i = 0; i < filesData.length; i++) {
        var res = await utils.compressImage(filesData[i].file);
        let folderThumbnail = "partsdata_Thumbnail";
        let folderMedium = "partsdata_Medium";
        let uploadFileParams = {
          content: res.files[0],
          name: filesData[i].s3Key,
          projectName: folderThumbnail + "/" + uid,
          bucketName: config.aws.s3.params.Data_Bucket,
        };
        let dataThumbnail = await AwsS3Svc.uploadFile(uploadFileParams);

        let uploadFileParamsMedium = {
          content: res.files[1],
          name: filesData[i].s3Key,
          projectName: folderMedium + "/" + uid,
          bucketName: config.aws.s3.params.Data_Bucket,
        };
        let dataMedium = await AwsS3Svc.uploadFile(uploadFileParamsMedium);

        if (dataMedium.Key.split("/")[2] != dataThumbnail.Key.split("/")[2]) {
          throw "Could not upload compressed images.";
        }

        imagesData.push(data[i].split("/")[2]);
        fs.removeSync(res.tempFolderpath);
      }
      return imagesData;
    }
    return imagesData;
  } catch (error) {
    console.log(error);
  }
};

module.exports.downloadFiles = async function (url, imagePath) {
  return new Promise(async (resolve, reject) => {
    try {
      var lastIndex = imagePath.lastIndexOf("/");
      var requiredPath = imagePath.slice(0, lastIndex + 1);

      if (!fs.existsSync(requiredPath)) {
        fs.mkdirSync(requiredPath);
      }
      var filepath = fs.createWriteStream(imagePath);
      let count = 0;
      https.get(url, function (file) {
        file.pipe(filepath);
        resolve(count);
      });
    } catch (error) {
      reject(error);
    }
  });
};

module.exports.getProjectNameList = async function (organization) {
  return new Promise((resolve, reject) => {
    let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");
    let params = {
      TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      FilterExpression: "#organizationName = :organizationValue",
      ProjectionExpression: "#partname",
      ExpressionAttributeNames: {
        "#partname": "name",
        "#organizationName": "organization",
      },
      ExpressionAttributeValues: {
        ":organizationValue": organization,
      },
    };
    let projectList = [];
    AwsDynamoDb.scanItem(params)
      .then((data) => {
        for (const item in data.Items) {
          projectList.push(data.Items[item].name);
        }
        resolve(projectList);
      })
      .catch((error) => {
        reject(error);
      });
  });
};

/*module.exports.getPartsCount = async function (organization) {
  return new Promise((resolve, reject) => {
    let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");

    let params = {
      TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      IndexName: "organization-index",
      KeyConditionExpression: "#organizationName = :organizationValue",
      ExpressionAttributeNames: {
        "#organizationName": "organization",
      },
      ExpressionAttributeValues: {
        ":organizationValue": organization,
      },
    };

    AwsDynamoDb.queryItem(params)
      .then((data) => {
        console.log("# of Parts : ",data.Count);
        resolve(data);
      })
      .catch((error) => {
        reject(error);
      });
  });
};*/

module.exports.getPartsCount = async function (organization) {
  return new Promise((resolve, reject) => {
    let AwsDynamoDb = ServiceManager.getService("AwsDynamoSvc");

    let params = {
      TableName: config.aws.dynamodb.tableInfo.PartDatabase,
      IndexName: "organization-index",
      KeyConditionExpression: "#organizationName = :organizationValue",
      ExpressionAttributeNames: {
        "#organizationName": "organization",
      },
      ExpressionAttributeValues: {
        ":organizationValue": organization,
      },
    };

    AwsDynamoDb.queryItem(params)
      .then((data) => {
        console.log("# of Parts : ",data.Count);
        resolve(data);
      })
      .catch((error) => {
        reject(error);
      });
  });
};


function isEmpty(entry) {
  if (entry.length === 0 && entry === undefined && entry == null) return true;

  return false;
}
