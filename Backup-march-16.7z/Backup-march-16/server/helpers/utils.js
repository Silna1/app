//please add common methods here
var ServiceManager = require('../services/SvcManager');
var config = require('c0nfig')
var jwt = require("jsonwebtoken");
var Jimp = require('jimp');
var crypto = require("crypto");

module.exports = {
    PrivilegeList: ["Admin", "Engineer", "Technician"]
}

module.exports.verificationByToken = function (req, res, next) {

    let verificationtoken = req.headers["authorization"];
    // console.log("silan verificationtoken");

    if (verificationtoken !== undefined) {
        // console.log("silan verificationtoken 1st chck");

        jwt.verify(verificationtoken, config.tokenKey, (err, authdata) => {
            if (authdata == undefined) {
                res.status(401).send({ "message": "Not Authorized" });
                // console.log("silan verificationtoken 2nd");
            }
            else {
                // console.log("silan verificationtoken 3rd");
                req.token = verificationtoken;
                // console.log("silna",req.token);
                req.userDataFromToken = authdata;
                // console.log("silna again",req.userDataFromToken);
                next();
            }
        });
    }
    else {
        // console.log("silan verificationtoken else ...");
        res.status(401).send({ "message": "Not Authorized" });
    }
}

module.exports.createToken = function (req) {
    try {
        return new Promise((resolve, reject) => {
            let user = {
                email: req.body.email,
                name: req.body.name,
                privilege: req.body.privilege
            };
            let refreshTokenData = {
                email: req.body.email,
                isRefreshToken: true
            };
            const token = jwt.sign(user, config.tokenKey, {
                expiresIn: config.tokenExpireTime
            });
            const refreshToken = jwt.sign(refreshTokenData, config.refreshTokenKey, {
                expiresIn: config.refreshTokenExpireTime
            });
            resolve(token);
        })
    } catch (error) {
        Promise.reject(error);
    }
}

function getCompressionFactor(height, width) {
    return percentage_reduction;
}

module.exports.compressImage = function (imagePath) {
    try {
        return new Promise((resolve, reject) => {

            Jimp.read(imagePath)
                .then(async image => {
                    var os = require('os');
                    var path = require("path");
                    var fs = require('fs-extra');
                    const uuid = require('uuid/v4');

                    var tmpdir = os.tmpdir();
                    var appPath = tmpdir + path.sep + uuid();
                    if (!fs.existsSync(appPath)) {
                        fs.mkdirSync(appPath);
                    }
                    let randomText = crypto.randomBytes(5).toString("hex");
                    let fileThumbnail = appPath + path.sep + randomText + '_Thu' + '.' + image.getExtension();
                    let fileMedium = appPath + path.sep + randomText + '_Med' + '.' + image.getExtension();
                    let width = image.getWidth();
                    let factor = (512 / width) * 100; // assuming we want 512 width pixels.
                    let thumbnailFactor = 0.125; // considering that thumbnail would be 64 x 64.

                    let files = [];
                    let multiplication_factor = factor / 100;
                    let reso = width * multiplication_factor;
                    let widthcompressed = Jimp.AUTO;
                    var promise = await image
                        .resize(reso, Jimp.AUTO)
                        .quality(50)            // set JPEG quality   
                        .writeAsync(fileMedium);    // save

                    var promise = await image
                        .resize(reso * thumbnailFactor, Jimp.AUTO)
                        .writeAsync(fileThumbnail);    // save
                    files.push(fileThumbnail);
                    files.push(fileMedium);
                    resolve({ "files": files, tempFolderpath: appPath });
                })
                .catch(err => {
                    reject(err);
                });
        })
    }
    catch (ex) {
        // console.log(ex);
    }
}

module.exports.getUserList = async function (userDataList, userPoolId) {
    return new Promise(async (resolve, reject) => {
        let userList = [];
        let AwsCognitoSvc = ServiceManager.getService('AwsCognitoSvc');
        if (userDataList.Users.length > 0) {
            for (const item in userDataList.Users) {
                let userObj = {};
                let attributes = userDataList.Users[item].Attributes;
                for (const objects in attributes) {
                    if (attributes[objects].Name === 'name' || attributes[objects].Name === 'email') {
                        userObj[attributes[objects].Name] = attributes[objects].Value;
                    }
                }
                let params = {
                    Username: userDataList.Users[item].Username,
                    UserPoolId: userPoolId,
                }
                userObj.username = userDataList.Users[item].Username;
                let groupList = await AwsCognitoSvc.getUserGroups(params);
                for (const key in groupList.Groups) {
                    if (this.PrivilegeList.includes(groupList.Groups[key].GroupName)) {
                        userObj.privilege = groupList.Groups[key].GroupName;
                        break;
                    }
                }
                userList.push(userObj);
            }
        }
        resolve(userList);
    })
}


module.exports.createUniquePassword = function (len = 8) {
    var text = "";
    var randomPass = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var number = '0123456789';
    var specialSymbol = '@-_';
    var lowerCaseChar = "abcdefghijklmnopqrstuvwxyz";
    for (var i = 0; i < len; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    randomPass += number.charAt(Math.floor(Math.random() * number.length))
    text += randomPass + specialSymbol.charAt(Math.floor(Math.random() * specialSymbol.length)) +
        lowerCaseChar.charAt(Math.floor(Math.random() * lowerCaseChar.length))

    return text;
}



